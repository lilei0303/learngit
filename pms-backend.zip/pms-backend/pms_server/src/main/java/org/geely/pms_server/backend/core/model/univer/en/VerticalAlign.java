package org.geely.pms_server.backend.core.model.univer.en;

public enum VerticalAlign {
    UNSPECIFIED,
    TOP, //	The text is explicitly aligned to the top of the cell.
    MIDDLE, //	The text is explicitly aligned to the middle of the cell.
    BOTTOM, //	The text is explicitly aligned to the bottom of the cell.
}
