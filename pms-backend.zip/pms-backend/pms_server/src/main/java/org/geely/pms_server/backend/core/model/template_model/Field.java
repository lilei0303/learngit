package org.geely.pms_server.backend.core.model.template_model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Field implements Serializable {

    /**
     * 是否选中
     */
    private Boolean selected;

    /**
     * 字段
     */
    private String fieldName;

    /**
     * 顺序
     */
    private Integer order;

    /**
     * 字段属性
     */
    private Attribute attribute;
}
