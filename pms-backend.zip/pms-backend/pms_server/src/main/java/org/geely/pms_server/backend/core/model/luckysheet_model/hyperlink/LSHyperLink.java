package org.geely.pms_server.backend.core.model.luckysheet_model.hyperlink;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置LSSheet类的hyperlink字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSHyperLink implements Serializable {
    /**
     * 链接类型：internal(内部)、external(外部)
     */
    private String linkType;

    /**
     * 链接地址
     */
    private String linkAddress;

    /**
     * 链接提示
     */
    private String linkTooltip;
}
