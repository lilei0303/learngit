package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 该类映射LSSheet的config字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSConfig implements Serializable {
    /**
     * 作用：合并单元格设置，key为r + '_' + c的拼接值
     */
    private Map<String, LSMerge> merge;

    /**
     * 作用：每个单元格的行高
     */
    private Map<String, Double> rowlen;

    /**
     * 作用：每个单元格的列宽
     */
    private Map<String, Integer> columnlen;

    /**
     * 作用：隐藏行信息，格式为：rowhidden[行数]: 0,
     * key指定行数即可，value总是为0
     */
    private Map<String, Integer> rowhidden;

    /**
     * 作用：隐藏列信息，格式为：colhidden[列数]: 0,
     * key指定列数即可，value总是为0
     */
    private Map<String, Integer> colhidden;

    /**
     * 作用：单元格的边框信息
     */
    private List<LSBorderInfoItem> borderInfo;

    /**
     * 作用：工作表保护
     */
    private LSAuthority authority;

    private Map<String, Integer> customHeight;

}
