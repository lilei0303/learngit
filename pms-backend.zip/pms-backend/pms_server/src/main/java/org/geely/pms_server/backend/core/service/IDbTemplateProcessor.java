package org.geely.pms_server.backend.core.service;

import org.geely.pms_server.backend.core.dto.manage_workbook.TemplateInfo;
import org.geely.pms_server.backend.core.model.template_model.Template;

import java.util.List;

/**
 * 提供对模板数据的存取接口
 */
public interface IDbTemplateProcessor {
    /**
     * 加载模板
     *
     * @param templateId
     * @return
     */
    Template loadTemplate(String templateId);

    /**
     * 保存模板
     *
     * @param template
     */
    String saveTemplate(Template template);

    /**
     * 删除模板的所有信息
     *
     * @param templateId
     */
    void deleteTemplate(String templateId);

    /**
     * 获取数据库所有模板的信息
     *
     * @return
     */
    List<TemplateInfo> getAllTemplateInfo();

    /**
     * 判断数据库是否存在模板
     *
     * @param templateId
     * @return
     */
    Boolean templateExists(String templateId);
}
