package org.geely.pms_server.backend.core.model.luckysheet_operation.images;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.image.LSImageItem;

import java.util.Map;

/**
 * 插入图片
 * t:images
 */
@Data
public class LSOperationImages {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 所有图片信息
     */
    @JSONField(name = "v")
    private Map<String, LSImageItem> value;
}
