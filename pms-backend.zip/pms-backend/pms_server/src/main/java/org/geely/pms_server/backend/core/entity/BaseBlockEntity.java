package org.geely.pms_server.backend.core.entity;


import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;

/**
 * 定义sheet_block基类
 */
@Document(collection = "sheet block")
@Data
public abstract class BaseBlockEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识唯一Id
     */
    @Id
    private String id;

    /**
     * 关联sheetId
     */
    private String sheetId;

    /**
     * 保存数据的二进制格式
     */
    private byte[] data;

    /**
     * 块合并成sheet的顺序号（从小到大）
     */
    private Integer number;

    /**
     * sheet的激活属性
     */
    private Integer status;

    /**
     * 块包含的单元格个数
     */
    private Integer size;

    /**
     * 子类设置wbId、templateId
     *
     * @param id
     */
    public abstract void setBelongsId(String id);
}
