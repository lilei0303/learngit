package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSWidth implements Serializable {

    private String value;

    private Integer cusSize;
}
