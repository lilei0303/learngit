package org.geely.pms_server.backend.core.model.luckysheet_model.pivottable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;
import org.geely.pms_server.backend.core.model.luckysheet_model.filter.LSFilter;

import java.util.List;

/**
 * 该类详细配置LSSheet类的pivotTable字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSPivotTable {
    private LSCellRangeItem pivot_select_save;

    private String pivotDataSheetIndex;

    private List<LSColumn> column;

    private List<LSColumn> row;

    //TODO 数据类型未知
    private List<LSFilter> filter;

    private List<LSValues> values;

    private String showType;

    //TODO problem?
    private List<List<Object>> pivotDatas;

    private Boolean drawPivotTable;

    private List<Integer> pivotTableBoundary;
}
