package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.CellValueType;

import java.util.Map;

public class CellData {
    /**
     * The unique key, a random string, is used for the plug-in to associate the cell. When the cell information changes,
     * the plug-in does not need to change the data, reducing the pressure on the back-end interface id.
     */
    private DocumentData p; // univer docs, set null for cell clear all

    /** style id */
    private Object s; // IStyleData | string

    /**
     * Origin value
     */
    private Object v; // string | number | boolean

    // Usually the type is automatically determined based on the data, or the user directly specifies
    private CellValueType t; // 1 string, 2 number, 3 boolean, 4 force string, green icon, set null for cell clear all

    /**
     * Raw formula string. For example `=SUM(A1:B4)`.
     */
    private String f;

    /**
     * Id of the formula.
     */
    private String si;

    /**
     * User stored custom fields
     */
    private Map<String, Object> customFields;
}