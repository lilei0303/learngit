package org.geely.pms_server.backend.utils;

import org.apache.poi.ss.formula.EvaluationWorkbook;
import org.apache.poi.ss.formula.FormulaParser;
import org.apache.poi.ss.formula.FormulaParsingWorkbook;
import org.apache.poi.ss.formula.FormulaType;
import org.apache.poi.ss.formula.ptg.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellReference;
import org.geely.pms_server.backend.core.model.calcChain.ReferencingCell;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellCT;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;

import java.util.*;
import java.util.stream.IntStream;

public class CellUtility {

    public static void LS2POI(Workbook poiWorkbook, Cell poiCell, LSCellValue lsCellValue) {
        // Guard
        if (lsCellValue == null) {
            return;
        }

        String lsCellValueString = lsCellValue.getV();
        String lsCellValueFormula = lsCellValue.getF();

        poiCell.setCellValue(lsCellValueString);
        if (!Objects.equals(lsCellValueFormula, null)) {
            poiCell.setCellFormula(lsCellValueFormula.substring(1));
        }

        CellStyle cellStyle = poiWorkbook.createCellStyle();
        DataFormat dataFormat = poiWorkbook.createDataFormat();
        cellStyle.setDataFormat(dataFormat.getFormat(lsCellValue.getCt().getFa()));
        poiCell.setCellStyle(cellStyle);
    }

    /**
     * Returns the formatted value of a cell.
     *
     * @param cell      the cell to get the value from
     * @param lsCell    the LSCell containing the cell value details, especially the format
     * @param evaluator the FormulaEvaluator to use for evaluating formulas in the cell
     * @return the formatted cell value as a String
     */
    public static String getFormattedCellValue(Cell cell, LSCell lsCell, FormulaEvaluator evaluator) {

        String cellFormat = Optional.ofNullable(lsCell.getV())
                .map(LSCellValue::getCt)
                .map(LSCellCT::getFa)
                .orElse("");

        Workbook workbook = cell.getRow().getSheet().getWorkbook();
        short dataFormat = workbook.createDataFormat().getFormat(cellFormat);

        // Use Java 8 Streams to loop through styles and find the first style that matches the data format
        // If no such style is found, a new style will be created
        // and its data format will be set to the current data format
        CellStyle cellStyle = IntStream.range(0, workbook.getNumCellStyles())
                .mapToObj(workbook::getCellStyleAt)
                .filter(style -> style.getDataFormat() == dataFormat)
                .findFirst()
                .orElseGet(() -> {
                    CellStyle newCellStyle = workbook.createCellStyle();
                    newCellStyle.setDataFormat(dataFormat);
                    return newCellStyle;
                });
        cell.setCellStyle(cellStyle);

        DataFormatter dataFormatter = new DataFormatter();
        return dataFormatter.formatCellValue(cell, evaluator);

    }

    public static String getCellValueString(Cell cell, CellType cellType) {
        switch (cellType) {
            case STRING: return cell.getStringCellValue();
            case NUMERIC : return String.valueOf(cell.getNumericCellValue());
            case BLANK: throw new IllegalStateException("Cannot get a FORMULA value from a BLANK cell");
            case ERROR:
                byte errorCellValue = cell.getErrorCellValue();
                FormulaError formulaError = FormulaError.forInt(errorCellValue);
                return switch (formulaError) {
                    case _NO_ERROR ->
                        "(no error)";
                    case NULL ->
                            "#NULL!";
                    case DIV0 ->
                            "#DIV/0!";
                    case VALUE ->
                            "#VALUE!";
                    case REF ->
                            "#REF!";
                    case NAME ->
                            "#NAME?";
                    case NUM ->
                            "#NUM!";
                    case NA ->
                            "#N/A";
                    case CIRCULAR_REF ->
                            "~CIRCULAR~REF~";
                    case FUNCTION_NOT_IMPLEMENTED ->
                            "~FUNCTION~NOT~IMPLEMENTED~";
                };
            default:return  "";
        }
    }

    public static HashSet<ReferencingCell> extractReferencingCellsInFormula(String formula, EvaluationWorkbook evalWorkbook, String sheetName, int sheetIndex) {
        Ptg[] ptgs = FormulaParser.parse(formula, (FormulaParsingWorkbook) evalWorkbook, FormulaType.CELL, sheetIndex);
        List<ReferencingCell> cellReferences = new ArrayList<>();

        for (Ptg ptg : ptgs) {
            // 处理跨工作表的单个单元格引用
            if (ptg instanceof Ref3DPtg || ptg instanceof Ref3DPxg) {
                handleRef3DPtgs(ptg, evalWorkbook, cellReferences);
            }
            // 处理跨工作表的单元格区域引用
            else if (ptg instanceof Area3DPtg || ptg instanceof Area3DPxg) {
                handleArea3DPtgs(ptg, evalWorkbook, cellReferences);
            }
            // 处理当前工作表的单元格引用
            else if (ptg instanceof RefPtg) {
                RefPtg ref = (RefPtg) ptg;

                ref.setRowRelative(true);
                ref.setColRelative(true);

                cellReferences.add(new ReferencingCell(new CellReference(ref.getRow(), ref.getColumn()).formatAsString(),sheetName));
            }
            // 处理当前工作表的单元格区域引用
            else if (ptg instanceof AreaPtg) {
                AreaPtg area = (AreaPtg) ptg;

                area.setFirstColRelative(true);
                area.setLastColRelative(true);
                area.setFirstRowRelative(true);
                area.setLastRowRelative(true);

                AreaReference areaRef = new AreaReference(area.toFormulaString(), evalWorkbook.getSpreadsheetVersion());
                cellReferences.add(new ReferencingCell(areaRef.formatAsString(), sheetName));
            }
        }

        return new HashSet<>(cellReferences);
    }
    private static void handleRef3DPtgs(Ptg ptg, EvaluationWorkbook evalWorkbook, List<ReferencingCell> cellReferences) {
        String sheetName;
        int row, column;

        if (ptg instanceof Ref3DPtg) {
            Ref3DPtg ref3d = (Ref3DPtg) ptg;

            ref3d.setColRelative(true);
            ref3d.setRowRelative(true);

            sheetName = evalWorkbook.getSheetName(ref3d.getExternSheetIndex());
            row = ref3d.getRow();
            column = ref3d.getColumn();
        } else { // Ref3DPxg
            Ref3DPxg ref3dpxg = (Ref3DPxg) ptg;

            ref3dpxg.setColRelative(true);
            ref3dpxg.setRowRelative(true);

            sheetName = ref3dpxg.getSheetName();
            row = ref3dpxg.getRow();
            column = ref3dpxg.getColumn();
        }

        CellReference cellRef = new CellReference(row, column);
        cellReferences.add(new ReferencingCell(cellRef.formatAsString(),sheetName));
    }

    private static void handleArea3DPtgs(Ptg ptg, EvaluationWorkbook evalWorkbook, List<ReferencingCell> cellReferences) {
        String sheetName;
        AreaReference areaRef;

        if (ptg instanceof Area3DPtg) {
            Area3DPtg area3d = (Area3DPtg) ptg;

            area3d.setFirstColRelative(true);
            area3d.setLastColRelative(true);
            area3d.setFirstRowRelative(true);
            area3d.setLastRowRelative(true);

            sheetName = evalWorkbook.getSheetName(area3d.getExternSheetIndex());
            areaRef = new AreaReference(area3d.toFormulaString(), evalWorkbook.getSpreadsheetVersion());
        } else { // Area3DPxg
            Area3DPxg area3dpxg = (Area3DPxg) ptg;

            area3dpxg.setFirstColRelative(true);
            area3dpxg.setLastColRelative(true);
            area3dpxg.setFirstRowRelative(true);
            area3dpxg.setLastRowRelative(true);

            sheetName = area3dpxg.getSheetName();
            // 构建区域引用
            CellReference firstCell = new CellReference(area3dpxg.getFirstRow(), area3dpxg.getFirstColumn());
            CellReference lastCell = new CellReference(area3dpxg.getLastRow(), area3dpxg.getLastColumn());
            areaRef = new AreaReference(firstCell, lastCell, evalWorkbook.getSpreadsheetVersion());
        }
        cellReferences.add(new ReferencingCell(areaRef.formatAsString(), sheetName));
    }

    public static HashSet<String> extractCellNameInFormula(String formula, EvaluationWorkbook evalWorkbook, String sheetName, int sheetOrder) {
        return null;
    }
}
