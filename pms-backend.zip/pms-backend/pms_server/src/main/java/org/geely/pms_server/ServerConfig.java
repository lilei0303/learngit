package org.geely.pms_server;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.alibaba.fastjson2.*;

import java.io.*;

public class ServerConfig {

    static final Logger logger = LogManager.getLogger(ServerConfig.class);
    public String serverVersion;
    public int backendServerPort;

    public static ServerConfig loadFromConfigFile(String filePath) {
        logger.info("Load config info from: " + filePath);
        try {
            String configJson = readFile(filePath);
            return JSON.parseObject(configJson, ServerConfig.class);
        } catch (Exception e) {
            return null;
        }
    }

    private static String readFile(String path) throws Exception {
        File f = new File(path);
        logger.debug("Config file absolute path: " + f.getAbsolutePath());
        StringBuilder configInfo = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader(f));
        String line = br.readLine();
        while (line != null) {
            configInfo.append(line);
            line = br.readLine();
        }
        br.close();
        return configInfo.toString();
    }

}
