package org.geely.pms_server.backend.core.model.template_model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Dataset implements Serializable {

    private String datasetName;

    private String sheetName;

    private Boolean mapped;

    private String location;

    private List<Field> fields;
}
