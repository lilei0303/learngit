package org.geely.pms_server.backend.core.model.univer.en;

public enum BorderType {
    TOP("top"),
    BOTTOM("bottom"),
    LEFT("left"),
    RIGHT("right"),
    NONE("none"),
    ALL("all"),
    OUTSIDE("outside"),
    INSIDE("inside"),
    HORIZONTAL("horizontal"),
    VERTICAL("vertical"),

    TLBR("tlbr"),
    TLBC_TLMR("tlbc_tlmr"),
    TLBR_TLBC_TLMR("tlbr_tlbc_tlmr"),
    BLTR("bl_tr"),
    MLTR_BCTR("mltr_bctr");

    private final String value;

    BorderType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}

