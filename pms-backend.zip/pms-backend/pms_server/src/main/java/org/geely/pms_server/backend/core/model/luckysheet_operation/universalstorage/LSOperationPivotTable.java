package org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.pivottable.LSPivotTable;

/**
 * 数据透视表
 * t:pivotTable
 */
@Data
public class LSOperationPivotTable {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 参数
     */
    @JSONField(name = "v")
    private LSPivotTable value;
}
