package org.geely.pms_server.backend.core.model.univer.en;

public enum WidthType {
    EVENLY_DISTRIBUTED,
    FIXED_WIDTH,
}
