package org.geely.pms_server.backend.core.controller;

import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson2.JSON;
import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.dto.ResponseWrapper;
import org.geely.pms_server.backend.core.dto.import_workbook.ImportWorkbookResponseDTO;
import org.geely.pms_server.backend.core.dto.manage_workbook.LSWorkbookInfo;
import org.geely.pms_server.backend.core.dto.manage_workbook.WorkbookDeletionResult;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.service.IDbProcessor;
import org.geely.pms_server.backend.core.service.IExcelToLuckyService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/api/v1/workbook")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE})
public class WorkbookManageController {

    @Resource
    IDbProcessor dbProcessor;

    @Resource
    IExcelToLuckyService excelToLuckyService;


    @GetMapping(value = "/all")
    public ResponseWrapper<List<LSWorkbookInfo>> getAllWorkbookIDs() {
        return ResponseWrapper.success(dbProcessor.getAllWorkbookInfo());
    }

    @DeleteMapping(value = "")
    public ResponseWrapper<List<WorkbookDeletionResult>> deleteWorkbooks(
            @RequestBody List<String> workbookIdList
    ) {
        List<WorkbookDeletionResult> result = workbookIdList.stream().map(id -> {
            if (dbProcessor.workbookExists(id)) {
                try {
                    dbProcessor.deleteWorkbook(id);
                } catch (Exception err) {
                    return WorkbookDeletionResult.failure(id, err.getLocalizedMessage());
                }
                return WorkbookDeletionResult.success(id);
            } else {
                return WorkbookDeletionResult.failure(id, "No such workbook.");
            }
        }).collect(Collectors.toList());

        return ResponseWrapper.success(result);
    }


    /**
     * 创建新工作表
     *
     * @return ResponseWrapper&lt;LSWorkbook&gt;
     */
    @RequestMapping(value = "/new", method = RequestMethod.POST)
    public ResponseWrapper<LSWorkBook> newWorkbook() {
        LSWorkBook wb = dbProcessor.loadNewWb();
        return ResponseWrapper.success(wb);
    }

    /**
     * 导入 Excel 文件并将其转换为 LuckySheet 格式。
     *
     * @param file 要导入的 Excel 文件。
     * @return 一个 ResponseWrapper 对象，其中包含作为字符串导入的 LuckySheet 文件。如果导入成功，则成功标志将为 true，并且错误消息将
     * 为空。如果导入失败，成功标志将为 false，并且 errorMessage 将包含错误的描述。
     */
    @PostMapping(value = "/importExcel")
    public ResponseWrapper<ImportWorkbookResponseDTO> importExcel(
            @RequestParam("file") MultipartFile file,
            @RequestParam("title") String title
    ) {
        String generatedGridKey = "Work_" + IdUtil.simpleUUID();
        try {
            CompletableFuture<String> luckyFileFuture = excelToLuckyService.convertExcelToLuckyAsync(file.getInputStream());
            CompletableFuture<Void> responseFuture = luckyFileFuture.thenApplyAsync(luckyFile -> {
                LSWorkBook lsWorkBook = JSON.parseObject(luckyFile, LSWorkBook.class);
                if (title != null) {
                    lsWorkBook.setTitle(title);
                }
                dbProcessor.importWorkbook(lsWorkBook, generatedGridKey);
                return null;
            });
            return ResponseWrapper.success(new ImportWorkbookResponseDTO(generatedGridKey));
        } catch (IOException | IExcelToLuckyService.ExcelConversionException e) {
            return ResponseWrapper.failure("Failed to import Excel file. " + e.getMessage());
        }
    }

    /**
     * 检查工作表是否存在
     *
     * @param gridKey 工作表 ID
     * @return 如果存在返回 true，否则返回 false
     */
    @GetMapping(value = "/probe")
    public ResponseWrapper<Boolean> importExcelStatus(@RequestParam("gridKey") String gridKey) {
        return ResponseWrapper.success(dbProcessor.workbookExists(gridKey));
    }
}
