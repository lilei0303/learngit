package org.geely.pms_server.backend.core.model.univer;

import lombok.Getter;


@Getter
public class BorderData {
    private BorderStyleData t;
    private BorderStyleData r;
    private BorderStyleData b;
    private BorderStyleData l;

    private BorderStyleData tl_br;
    private BorderStyleData tl_bc;
    private BorderStyleData tl_mr;

    private BorderStyleData bl_tr;
    private BorderStyleData ml_tr;
    private BorderStyleData bc_tr;
}
