package org.geely.pms_server.backend.core.repository.univer;

import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.entity.univer.UniverWorkbook;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
@Service
public class UniverDaoImpl {
    @Resource
    UniverWorkbookRepository uWbRepo;

    public void save(String minioId, String size, String name) {
        UniverWorkbook uWb = uWbRepo.findByMinioId(minioId);
        if (uWb == null) {
            UniverWorkbook workbook = new UniverWorkbook();
            workbook.setMinioId(minioId);
            workbook.setSize(size);
            workbook.setName(name);
            workbook.setCreateTime(LocalDateTime.now());
            uWbRepo.save(workbook);
        } else {
            uWb.setMinioId(minioId);
            uWb.setSize(size);
            uWb.setName(name);
            uWb.setUpdateTime(LocalDateTime.now());
            uWbRepo.save(uWb);
        }
    }

    public void deleteByMinioId(String minioId){
        System.out.println("minioId = " + minioId);
        uWbRepo.deleteById(minioId);
    }
}
