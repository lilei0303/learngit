package org.geely.pms_server.backend.core.model.univer;

public class DocumentSettings {
    private Double zoomRatio;
}
