package org.geely.pms_server.backend.core.repository.workbook;

import org.geely.pms_server.backend.core.entity.workbook.WorkBlockEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkBlockRepository extends MongoRepository<WorkBlockEntity, String> {

    /**
     * 通过sheetId获取所有块,并根据number从小到大顺序返回
     *
     * @param sheetId
     * @return
     */
    List<WorkBlockEntity> findAllBySheetId(String sheetId);

    /**
     * 更新整个工作簿时，调用下列方法删除原数据
     *
     * @param wbId
     * @param sheetId
     */
    void deleteAllByWbIdAndSheetId(String wbId, String sheetId);

    /**
     * 根据wbId删除
     *
     * @param wbId
     */
    void deleteAllByWbId(String wbId);

    WorkBlockEntity findByWbIdAndStatusAndNumber(String wbId, Integer status, Integer number);
}
