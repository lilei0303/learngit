package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.DocumentFlavor;
import org.geely.pms_server.backend.core.model.univer.en.PageOrientType;

public class DocStyleBase extends Margin{
    private Double pageNumberStart;
    private Size pageSize;
    private PageOrientType pageOrient;
    private DocumentFlavor documentFlavor;
    private Double marginHeader;
    private Double marginFooter;
    private DocumentRenderConfig renderConfig;
}
