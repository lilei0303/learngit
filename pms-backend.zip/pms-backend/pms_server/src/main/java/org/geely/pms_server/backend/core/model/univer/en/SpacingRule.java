package org.geely.pms_server.backend.core.model.univer.en;

public enum SpacingRule {
    AUTO, // Specifies that the line spacing of the parent object shall be automatically determined by the size of its contents, with no predetermined minimum or maximum size.
    AT_LEAST, // Specifies that the height of the line shall be at least the value specified, but might be expanded to fit its content as needed.
    EXACT; // Specifies that the height of the line
}
