package org.geely.pms_server.backend.core.model.univer.en;

public enum NamedStyleType {
    NAMED_STYLE_TYPE_UNSPECIFIED, // The type of named style is unspecified.
    NORMAL_TEXT, // Normal text.
    TITLE, // Title.
    SUBTITLE, // Subtitle.
    HEADING_1, // Heading 1.
    HEADING_2, // Heading 2.
    HEADING_3, // Heading 3.
    HEADING_4, // Heading 4.
    HEADING_5, // Heading 5.
    HEADING_6; // Heading 6.

}
