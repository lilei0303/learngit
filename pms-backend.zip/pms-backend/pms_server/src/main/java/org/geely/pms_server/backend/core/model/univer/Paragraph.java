package org.geely.pms_server.backend.core.model.univer;

public class Paragraph {
    private Double startIndex;
    private ParagraphStyle paragraphStyle;
    private Bullet bullet;
}
