package org.geely.pms_server.backend.core.model.univer;

import java.util.List;

public class ReferenceSource {
    private Footers footers; // footers
    private Headers headers; // headers
    private Lists lists; // lists
    private Drawings drawings; // drawings
    private List<String> drawingsOrder; // drawingsOrder
    private List<String> headerFooterDrawingsOrder;
}
