package org.geely.pms_server.backend.core.service;

import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.model.luckysheet_operation.LSOperationMv;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCell;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCellRange;
import org.geely.pms_server.backend.core.model.luckysheet_operation.config.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterClear;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterRestore;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChain;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChainAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.hyperlink.LSOperationHyperLink;
import org.geely.pms_server.backend.core.model.luckysheet_operation.images.LSOperationImages;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnDel;
import org.geely.pms_server.backend.core.model.luckysheet_operation.sheet.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.workbook.LSOperationWbName;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface IOperationProcessor {

    public LSCell calculateCell(String lsWorkbookID, String sheetIndex, Integer row, Integer col);

    /**
     * 表格操作-单个单元格刷新
     *
     * @param wbId
     * @param operation
     * @return
     */
    List<LSCell> processRefreshCell(String wbId, LSOperationRefreshCell operation) throws Exception;
//    List<LSCell> processRefreshCell(String wbId, LSOperationRefreshCell operation);

    List<LSCell> newProcessRefreshCell(String wbId, LSOperationRefreshCell operation) throws Exception;

    /**
     * 表格操作-范围单元格刷新
     *
     * @param wbId
     * @param operation
     * @return
     */
    List<List<LSCell>> processRefreshCellRange(String wbId, LSOperationRefreshCellRange operation) throws Exception;
//    List<List<LSCell>> processRefreshCellRange(String wbId, LSOperationRefreshCellRange operation);

    /**
     * 表格操作-聚焦选中(mv)
     *
     * @param wbId
     * @param operation
     */
    void processMv(String wbId, LSOperationMv operation);

    /**
     * 表格操作-列隐藏
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processConfigHideColumn(String wbId, LSOperationConfigHideColumn operation);

    /**
     * 表格操作-行隐藏
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processConfigHideRow(String wbId, LSOperationConfigHideRow operation);

    /**
     * 表格操作-设置单元格边框
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processBorderInfo(String wbId, LSOperationSetBorderInfo operation);

    /**
     * 表格操作-修改列宽
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processColWidth(String wbId, LSOperationSetColWidth operation);

    /**
     * 表格操作-修改行高
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processRowHeight(String wbId, LSOperationSetRowHeight operation);

    /**
     * 表格操作-清除筛选
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processFilterClear(String wbId, LSOperationFilterClear operation);

    /**
     * 表格操作-恢复筛选
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processFilterRestore(String wbId, LSOperationFilterRestore operation);

    /**
     * 表格操作-公式链操作
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processCalcChain(String wbId, LSOperationCalcChain operation);

    /**
     * 表格操作-公式操作（添加/更新/删除）
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processCalcChainAdd(String wbId, LSOperationCalcChainAdd operation);

    /**
     * 表格操作-插入链接操作
     *
     * @param wbId
     * @param operation
     */
    void processHyperLink(String wbId, LSOperationHyperLink operation);

    /**
     * 表格操作-插入图片操作
     *
     * @param wbId
     * @param operation
     */
    void processImages(String wbId, LSOperationImages operation);

    /**
     * 表格操作-行列增加
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processRowOrColumnAdd(String wbId, LSOperationRowOrColumnAdd operation);

    /**
     * 表格操作-行列删除
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processRowOrColumnDel(String wbId, LSOperationRowOrColumnDel operation);

    /**
     * 表格操作-新建Sheet
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processAddSheet(String wbId, LSOperationAddSheet operation);

    /**
     * 表格操作-删除Sheet
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processDelSheet(String wbId, LSOperationDelSheet operation);

    /**
     * 表格操作-调整sheet位置
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processAdjustSheet(String wbId, LSOperationAdjustSheet operation);

    /**
     * 表格操作-删除sheet后恢复操作
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processRestoreDelSheet(String wbId, LSOperationRestoreDelSheet operation);

    /**
     * 表格操作-复制Sheet
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processCopySheet(String wbId, LSOperationCopySheet operation);

    /**
     * 表格操作-切换到指定Sheet
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processSwitchSheet(String wbId, LSOperationSwitchSheet operation);

    /**
     * 表格操作-交替颜色
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processAlternate(String wbId, LSOperationAlternateFormat operation);

    /**
     * 表格操作-条件格式
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processCondition(String wbId, LSOperationConditionFormat operation);

    /**
     * 表格操作-数据验证
     *
     * @param wbId
     * @param operation
     */
    void processDataVerification(String wbId, LSOperationDataVerification operation);

    /**
     * 表格操作-动态数组
     *
     * @param wbId
     * @param operation
     */
    void processDynamicArray(String wbId, LSOperationDynamicArray operation);

    /**
     * 表格操作-筛选
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processUsFilter(String wbId, LSOperationUsFilter operation);

    /**
     * 表格操作-缩放比
     *
     * @param wbId
     * @param operation
     */
    void processZoomRatio(String wbId, LSOperationZoomRatio operation);

    /**
     * 表格操作-筛选范围
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processFilterSelect(String wbId, LSOperationFilterSelect operation);

    /**
     * 表格操作-冻结行列
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processFreeze(String wbId, LSOperationFreeze operation);

    /**
     * 表格操作-合并单元格
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processMerge(String wbId, LSOperationMerge operation);

    /**
     * 表格操作-数据透视表
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processPivotTable(String wbId, LSOperationPivotTable operation);

    /**
     * 表格操作-表格颜色
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processSheetColor(String wbId, LSOperationSetSheetColor operation);

    /**
     * 表格操作-表格名称
     *
     * @param wbId
     * @param operation
     * @return
     */
    void processSheetName(String wbId, LSOperationSetSheetName operation);

    /**
     * 表格处理-sheet隐藏或显示
     *
     * @param wbId
     * @param operation
     */
    void processSheetShow(String wbId, LSOperationSheetShow operation);

    /**
     * 表格处理-修改工作簿名称
     *
     * @param wbId
     * @param operation
     */
    void processWorkBookName(String wbId, LSOperationWbName operation);
}
