package org.geely.pms_server.backend.core.model.luckysheet_model.celldata;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置CellValue类的ct字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCellCT implements Serializable {
    /**
     * 格式名称
     */
    private String fa;

    /**
     * 格式类型
     */
    private String t;

    /**
     * 仅当 t 为 inlineString 时有效
     */
    private List<LSCellValue> s;
}