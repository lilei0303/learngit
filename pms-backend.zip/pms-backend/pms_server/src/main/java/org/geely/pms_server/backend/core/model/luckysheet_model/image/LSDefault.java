package org.geely.pms_server.backend.core.model.luckysheet_model.image;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置ImageItem的default字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSDefault implements Serializable {
    /**
     * 图片 宽度
     */
    private Integer width;

    /**
     * 图片 高度
     */
    private Integer height;

    /**
     * 图片离表格左边的 位置
     */
    private Integer left;

    /**
     * 图片离表格顶部的 位置
     */
    private Integer top;
}
