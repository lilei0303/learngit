package org.geely.pms_server.backend.core.model.univer;

public class ListData {
    private String listStyle;
    private NestingLevel nestingLevel;
}
