package org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.dynamicarray.LSDynamicArray;

import java.util.List;

/**
 * 动态数组
 * t:dynamicArray
 */
@Data
public class LSOperationDynamicArray {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 包含所有修改过高度的单元格信息 [Row : Height]
     */
    @JSONField(name = "v")
    private List<LSDynamicArray> value;
}
