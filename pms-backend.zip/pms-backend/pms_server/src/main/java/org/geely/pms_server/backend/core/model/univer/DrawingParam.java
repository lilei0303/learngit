package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;
import org.geely.pms_server.backend.core.model.univer.en.DrawingType;

public class DrawingParam {
    private DrawingType drawingType;
//    private TransformState  transform;
//    private List<TransformState> transforms;

    private BooleanNumber isMultiTransform;
    private  String groupId;
}
