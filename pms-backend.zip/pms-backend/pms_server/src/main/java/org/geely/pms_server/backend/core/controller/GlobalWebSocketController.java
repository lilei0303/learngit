package org.geely.pms_server.backend.core.controller;

import com.alibaba.fastjson2.JSON;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.geely.pms_server.backend.core.dto.WebSocketResponseDTO;
import org.geely.pms_server.backend.core.model.calculate.WorkbookInit;
import org.geely.pms_server.backend.core.model.luckysheet_operation.LSOperationMv;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCell;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCellRange;
import org.geely.pms_server.backend.core.model.luckysheet_operation.config.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterClear;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterRestore;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChain;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChainAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.hyperlink.LSOperationHyperLink;
import org.geely.pms_server.backend.core.model.luckysheet_operation.images.LSOperationImages;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnDel;
import org.geely.pms_server.backend.core.model.luckysheet_operation.sheet.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.workbook.LSOperationWbName;
import org.geely.pms_server.backend.core.service.IOperationProcessor;
import org.geely.pms_server.backend.core.service.impl.OperationProcessor;
import org.geely.pms_server.backend.utils.PakoGzipUtils;
import org.geely.pms_server.backend.utils.SpringContextUtil;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@ServerEndpoint("/ws/{user}/{workbook}")
@Component
public class GlobalWebSocketController {

    static final Logger logger = LogManager.getLogger(GlobalWebSocketController.class);

    /**
     * 二维数组
     * [WorkbookID : [UserID : WebSocketController]]
     */
    private static final ConcurrentHashMap<String, Map<String, GlobalWebSocketController>> webSocketMap =
            new ConcurrentHashMap<>();
    /**
     * 工作表 ID
     */
    private String workbookID;
    /**
     * 连接到当前工作表的用户 ID
     */
    private String userID;
    /**
     * 持有当前连接
     */
    private Session session;

    /**
     * 消息处理器
     */
    private IOperationProcessor operationProcessor() {
        return SpringContextUtil.getBean(OperationProcessor.class);
    }

    private WorkbookInit workbookInit() {
        return SpringContextUtil.getBean(WorkbookInit.class);
    }

    @SuppressWarnings("unused")
    @OnOpen
    public void onOpen(Session session, @PathParam("workbook") String workbookID, @PathParam("user") String userID) {
        logger.debug("Connection opening: " + userID + " on workbook " + workbookID);

        this.workbookID = workbookID;
        this.userID = userID;
        this.session = session;

        session.setMaxTextMessageBufferSize(999999);

        workbookInit().onUserConnect(workbookID);

        // 将当前 session 加入活跃 session 列表
        // 在所有 session 中，(UserID, WorkbookID) 元组必须唯一
        // 即一个用户不能同时开多个窗口编辑同一个工作表
        Map<String, GlobalWebSocketController> sessionMap =
                Optional.ofNullable(webSocketMap.get(workbookID)).orElseGet(ConcurrentHashMap::new);
        // 如果同一用户再次连接到当前工作表，关闭之前的连接
        Optional.ofNullable(sessionMap.get(userID)).ifPresent(GlobalWebSocketController::closeSession);
        sessionMap.put(userID, this);
        webSocketMap.put(workbookID, sessionMap);
        logger.debug("Connection opened: " + userID + " on workbook " + workbookID);
    }

    @SuppressWarnings("unused")
    @OnMessage
    public void onTextMessage(String message, Session session) throws IOException {
        // 前端发送心跳包，保持 ws 连接，直接忽略
        if (message.equals("rub")) {
            return;
        }

        // 解压 Pako.js 压缩的数据
        String decompressedMessage = PakoGzipUtils.decompressURI(message);

        // 处理消息

        processMessage(decompressedMessage);
    }

    @SuppressWarnings("unused")
    @OnClose
    public void onClose(Session session) {
        logger.debug("Connection closing: " + userID + " on workbook " + workbookID);
        // 将当前 session 移出活跃 session 列表
        if (webSocketMap.containsKey(workbookID)) {
            webSocketMap.get(workbookID).remove(userID);
            if (webSocketMap.get(workbookID).isEmpty()) {
                // 所有连接到当前工作表的用户均已退出
                workbookInit().onAllUserDisconnected(workbookID);
                webSocketMap.remove(workbookID);
            }
        }
        logger.info("Connection closed: " + userID + " on workbook " + workbookID);
    }

    private void processMessage(String message) {

        // 将消息解析为具体操作，以便后端进行同步更改
        String operationType = JSON.parseObject(message).getString("t");
        // TODO: 处理操作
        try {
            switch (operationType) {
                case "v": { // Refresh Cell Value
                    logger.info("Processing message: " + message);
                    LSOperationRefreshCell operation = JSON.parseObject(message, LSOperationRefreshCell.class);
                    List<WebSocketResponseDTO> operations = operationProcessor()
                            .newProcessRefreshCell(this.workbookID, operation)
                            .stream()
                            .map(cell -> {
                                LSOperationRefreshCell newOperation = new LSOperationRefreshCell(
                                        cell.getSheetIndex(),
                                        cell.getV(),
                                        cell.getR(),
                                        cell.getC()
                                );
                                return WebSocketResponseDTO.update(this.userID, this.userID, JSON.toJSONString(newOperation));
                            })
                            .toList();

                    this.broadcastMessage(operations, true);
                    break;
                }
                case "rv": {
                    LSOperationRefreshCellRange operationRefreshCellRange = JSON.parseObject(message,
                            LSOperationRefreshCellRange.class);
                    List<WebSocketResponseDTO> operations = operationProcessor()
                            .processRefreshCellRange(this.workbookID, operationRefreshCellRange)
                            .stream().flatMap(List::stream)
                            .map(cell -> {
                                LSOperationRefreshCell newOperation = new LSOperationRefreshCell(
                                        operationRefreshCellRange.getIndex(),
                                        cell.getV(),
                                        cell.getR(),
                                        cell.getC()
                                );
                                return WebSocketResponseDTO.update(this.userID, this.userID, JSON.toJSONString(newOperation));
                            })
                            .toList();
                    this.broadcastMessage(operations, true);
                    break;
                }
                case "rowhidden":
                    operationProcessor()
                            .processConfigHideRow(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationConfigHideRow.class)
                            );
                    break;
                case "colhidden":
                    operationProcessor()
                            .processConfigHideColumn(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationConfigHideColumn.class)
                            );
                    break;
                case "borderInfo":
                    operationProcessor()
                            .processBorderInfo(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSetBorderInfo.class)
                            );
                    break;
                case "columnlen":
                    operationProcessor()
                            .processColWidth(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSetColWidth.class)
                            );
                    break;
                case "rowlen":
                    operationProcessor()
                            .processRowHeight(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSetRowHeight.class)
                            );
                    break;
                case "fsc":
                    operationProcessor()
                            .processFilterClear(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationFilterClear.class)
                            );
                    break;
                case "fsr":
                    operationProcessor()
                            .processFilterRestore(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationFilterRestore.class)
                            );
                    break;
                case "calcChain":
                    logger.debug("message = " + message);
                    operationProcessor()
                            .processCalcChain(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationCalcChain.class)
                            );
                    break;
                case "fc":
                    operationProcessor()
                            .processCalcChainAdd(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationCalcChainAdd.class)
                            );
                    break;
                case "hyperlink":
                    operationProcessor()
                            .processHyperLink(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationHyperLink.class)
                            );
                    break;
                case "images":
                    operationProcessor()
                            .processImages(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationImages.class)
                            );
                    break;
                case "arc":
                    operationProcessor()
                            .processRowOrColumnAdd(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationRowOrColumnAdd.class)
                            );
                    break;
                case "drc":
                    operationProcessor()
                            .processRowOrColumnDel(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationRowOrColumnDel.class)
                            );
                    break;
                case "sha":
                    operationProcessor()
                            .processAddSheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationAddSheet.class)
                            );
                    break;
                case "shr":
                    operationProcessor()
                            .processAdjustSheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationAdjustSheet.class)
                            );
                    break;
                case "shre":
                    operationProcessor()
                            .processRestoreDelSheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationRestoreDelSheet.class)
                            );
                    break;
                case "shc":
                    operationProcessor()
                            .processCopySheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationCopySheet.class)
                            );
                    break;
                case "shd":
                    operationProcessor()
                            .processDelSheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationDelSheet.class)
                            );
                    break;
                case "sh":
                    operationProcessor()
                            .processSheetShow(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSheetShow.class)
                            );
                    break;
                case "shs":
                    operationProcessor()
                            .processSwitchSheet(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSwitchSheet.class)
                            );
                    break;
                case "luckysheet_alternateformat_save":
                    operationProcessor()
                            .processAlternate(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationAlternateFormat.class)
                            );
                    break;
                case "luckysheet_conditionformat_save":
                    operationProcessor()
                            .processCondition(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationConditionFormat.class)
                            );
                    break;
                case "dataVerification":
                    operationProcessor()
                            .processDataVerification(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationDataVerification.class)
                            );
                    break;
                case "dynamicArray":
                    operationProcessor()
                            .processDynamicArray(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationDynamicArray.class)
                            );
                    break;
                case "filter_select":
                    operationProcessor()
                            .processFilterSelect(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationFilterSelect.class)
                            );
                    break;
                case "frozen":
                    operationProcessor()
                            .processFreeze(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationFreeze.class)
                            );
                    break;
                case "config":
                    operationProcessor()
                            .processMerge(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationMerge.class)
                            );
                    break;
                case "pivotTable":
                    operationProcessor()
                            .processPivotTable(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationPivotTable.class)
                            );
                    break;
                case "color":
                    operationProcessor()
                            .processSheetColor(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSetSheetColor.class)
                            );
                    break;
                case "name":
                    operationProcessor()
                            .processSheetName(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationSetSheetName.class)
                            );
                    break;
                case "filter":
                    operationProcessor()
                            .processUsFilter(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationUsFilter.class)
                            );
                    break;
                case "zoomRatio":
                    operationProcessor()
                            .processZoomRatio(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationZoomRatio.class)
                            );
                    break;
                case "na":
                    operationProcessor()
                            .processWorkBookName(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationWbName.class)
                            );
                    break;
                case "mv":
                    operationProcessor()
                            .processMv(
                                    this.workbookID,
                                    JSON.parseObject(message, LSOperationMv.class)
                            );
                    break;
                default:
                    break;
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            logger.error("Error while processing message, workbook closed? Message: " + message);
        } catch (Exception error) {
            WebSocketResponseDTO errorMessage = WebSocketResponseDTO.error(this.userID, this.userID, error.getLocalizedMessage());
            this.sendMessage(List.of(errorMessage));
            error.printStackTrace();
            logger.error(error.getStackTrace());
        }

        // 多人协作 - 广播此消息给连接到当前工作表的其他用户
        // shs 表示切换 sheet 不需要广播 (?)
        if (!operationType.equals("shs")) {
            this.broadcastMessage(WebSocketResponseDTO.success(this.userID, this.userID, message), false);
        }
    }

    private void broadcastMessage(WebSocketResponseDTO message, Boolean includingThis) {
        broadcastMessage(List.of(message), includingThis);
    }

    private void broadcastMessage(List<WebSocketResponseDTO> messages, Boolean includingThis) {
        webSocketMap.get(this.workbookID).entrySet().stream()
                .filter(entry -> includingThis || !entry.getKey().equals(this.userID))
                .forEach(entry -> {
                    entry.getValue().sendMessage(messages);
                });
    }

    /**
     * 向当前 session 对端发送文本消息
     *
     * @param messages 消息内容
     */
    public void sendMessage(List<WebSocketResponseDTO> messages) {
        try {
            this.session.getBasicRemote().sendText(
                    JSON.toJSONString(messages)
            );
        } catch (IOException e) {
            logger.error(e.getLocalizedMessage());
        }
    }

    public void closeSession() {
        try {
            this.session.close();
        } catch (IOException e) {
            logger.error(e.getLocalizedMessage());
        }
    }
}
