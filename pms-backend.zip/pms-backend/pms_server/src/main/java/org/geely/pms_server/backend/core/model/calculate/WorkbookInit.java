package org.geely.pms_server.backend.core.model.calculate;

import jakarta.annotation.Resource;
import lombok.NoArgsConstructor;
import cn.hutool.core.lang.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.formula.FormulaParser;
import org.apache.poi.ss.formula.FormulaParsingWorkbook;
import org.apache.poi.ss.formula.FormulaRenderer;
import org.apache.poi.ss.formula.FormulaType;
import org.apache.poi.ss.formula.ptg.Area3DPtg;
import org.apache.poi.ss.formula.ptg.Ptg;
import org.apache.poi.ss.formula.ptg.Ref3DPtg;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.geely.pms_server.backend.core.model.formulaChain.FormulaChainManager;
import org.geely.pms_server.backend.core.model.formulaChain.FormulaNode;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.service.IDbProcessor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@NoArgsConstructor
public class WorkbookInit {
    static final Logger logger = LogManager.getLogger(WorkbookInit.class);


    //在内存中的由lsworkbook转化的workbook对象
    private static final Map<String, Workbook> _workbooks = new HashMap<>();

    //从数据库中拿过来的保存在内存中的lsWorkbooks对象
    private static final Map<String, LSWorkBook> _lsWorkbooks = new HashMap<>();
    //模板表
    private static final Map<String, LSWorkBook> _tempWorkbooks = new HashMap<>();

    private static final Map<String, FormulaChainManager> _formulaChains = new HashMap<>();

    private static final Lock lock = new ReentrantLock();

    @Resource
    IDbProcessor dbProcessor;

    //当每一个用户在连接到当前LSWorkbook时调用
    public void onUserConnect(String workbookID) {
        //如果用户在连接时传入的work book ID在内存中不存在则去数据库中获取
        if (getMyWorkBookByID(workbookID) == null) {
            //根据前端用户在连接时传入的work book ID去数据库中获取LSWorkBook
            LSWorkBook lsWorkbook = dbProcessor.loadWorkbook(workbookID);
            if (workbookID.substring(0,4).equals("Work")) {
                _lsWorkbooks.put(lsWorkbook.getGridKey(), lsWorkbook);
            } else if (workbookID.substring(0, 4).equals("Temp")) {
                _tempWorkbooks.put(lsWorkbook.getGridKey(), lsWorkbook);
            }
            WorkbookManager workbookManager = new WorkbookManager();

            // 新版公式链
            Workbook workbook = workbookManager.getPoiWorkBook(lsWorkbook);
            _workbooks.put(lsWorkbook.getGridKey(), workbook);

            // 旧版公式链
//            Pair<Workbook, FormulaChainManager> pair = workbookManager.getWorkbookAndFormulaChain(lsWorkbook);
//            Workbook workbook = pair.getKey();
//            _workbooks.put(lsWorkbook.getGridKey(), workbook);
//            FormulaChainManager formulaChainManager = pair.getValue();
//            _formulaChains.put(lsWorkbook.getGridKey(), formulaChainManager);
        }
    }

    public void onAllUserDisconnected(String workbookID) {
        lock.lock();
        try {
            LSWorkBook temp = getMyWorkBookByID(workbookID);
            dbProcessor.saveWorkbook(temp);
            _lsWorkbooks.remove(workbookID);
            _workbooks.remove(workbookID);
            _tempWorkbooks.remove(workbookID);
        } catch (Exception e) {
            logger.error("Error occurred while saving workbook", e);
        } finally {
            lock.unlock();
            System.gc();
        }
    }

    public Workbook getWorkbookByGridKey(String gridKey) {
        return _workbooks.get(gridKey);
    }

    //更新公式链时被调用
    public static Optional<Pair<CellType,Cell>> calculateInFormulaChain(String gridKey, String sheetIndex, int row, int column) {
        Workbook workbook = _workbooks.get(gridKey);
        int sheetOrder = _lsWorkbooks.get(gridKey).getLSSheetsByIndex(sheetIndex).get().getOrder();
        Sheet sheet = workbook.getSheetAt(sheetOrder);
        Row poiRow = Optional.ofNullable(sheet.getRow(row)).orElseGet(() -> {
            sheet.createRow(row);
            return sheet.getRow(row);
        });
        Cell poiCell = Optional.ofNullable(poiRow.getCell(column)).orElseGet(() -> {
            poiRow.createCell(column);
            return poiRow.getCell(column);
        });

        if (poiCell.getCellType().equals(CellType.FORMULA)) {
            LSWorkBook myWorkBook = new LSWorkBook();
            if (gridKey.substring(0, 4).equals("Work")) {
                myWorkBook = _lsWorkbooks.get(gridKey);
            } else if (gridKey.substring(0, 4).equals("Temp")) {
                myWorkBook = _tempWorkbooks.get(gridKey);
            } else {
                myWorkBook = null;
            }
            LSSheet mySheet = myWorkBook.getLSSheetsByOrder(sheetOrder);
            LSCell myCell = mySheet.getCellByRowColumn(row, column).getValue();

            CellType cellType = workbook.getCreationHelper().createFormulaEvaluator().evaluateFormulaCell(poiCell);
            //如果当前公式计算结果为数字类型
            if (cellType == CellType.NUMERIC) {
                myCell.getV().setV(String.valueOf(poiCell.getNumericCellValue()));
                myCell.getV().setM(String.valueOf(poiCell.getNumericCellValue()));
            } else if (cellType == CellType.STRING){
                myCell.getV().setV(poiCell.getStringCellValue());
                myCell.getV().setM(poiCell.getStringCellValue());
            } else if (cellType == CellType.BLANK) {
                throw new IllegalStateException("Cannot get a FORMULA value from a BLANK cell");
            }

            myCell.getV().setF("=" + poiCell.getCellFormula());
            return Optional.of(new Pair<>(cellType,poiCell));
        }else {
            return Optional.empty();
        }
    }

    //返回lsWorkBook,若无返回null
    public LSWorkBook getLSWorkBookByID(String workbookID) {
        return _lsWorkbooks.get(workbookID);
    }

    public LSWorkBook getMyWorkBookByID(String workbookID) {
        switch (workBookType(workbookID)) {
            case 1:
                return _lsWorkbooks.get(workbookID);
            case 2:
                return _tempWorkbooks.get(workbookID);
            default:
                return null;
        }
    }

    public int workBookType(String workbookID) {
        if (workbookID.substring(0, 4).equals("Work")) {
            return 1;
        } else if (workbookID.substring(0, 4).equals("Temp")) {
            return 2;
        } else {
            logger.debug("未在数据库中查询到表！");
            return 3;
        }
    }

    public FormulaChainManager getFormulaChainByID(String workbookID) {
        return _formulaChains.get(workbookID);
    }

    public Map<String, LSWorkBook> getLSWorkbooks() {
        return _lsWorkbooks;
    }

    public Lock getLock() {
        return lock;
    }

    /**
     * 判断工作表是否已经加载
     *
     * @param workbookID 要判断的工作表 ID
     * @return 如果工作表已经加载，返回 true，否则返回 false
     */
    public boolean lsWorkbookLoaded(String workbookID) {
        return _lsWorkbooks.containsKey(workbookID);
    }

    //TODO-test
    public void printPoiWbSheetName(String wbId) {
        Iterator<Sheet> poiIterator = _workbooks.get(wbId).sheetIterator();
        while (poiIterator.hasNext()) {
            String name = poiIterator.next().getSheetName();
            logger.debug("sheet:index--name:" + _workbooks.get(wbId).getSheetIndex(name) + "---" + name);
        }
    }

    private void updateNodeIfRequired(String gridKey, int sheetOrder, FormulaNode node, String oldSheetName, String newSheetName) {
        if (node.getSheetName().equals(oldSheetName)) {
            //当前所更改结点的全部后置依赖
            HashSet<FormulaNode> formulaNodes = _formulaChains.get(gridKey).formulaChain.get(node.getCellNodeName());
            for (FormulaNode formulaNode : formulaNodes) {
                Workbook workbook = _workbooks.get(gridKey);
                Sheet sheet = workbook.getSheetAt(sheetOrder);
                Row poiRow = Optional.ofNullable(sheet.getRow(formulaNode.getRow())).orElseGet(() -> {
                    sheet.createRow(formulaNode.getRow());
                    return sheet.getRow(formulaNode.getRow());
                });
                Cell poiCell = Optional.ofNullable(poiRow.getCell(node.getColumn())).orElseGet(() -> {
                    poiRow.createCell(formulaNode.getColumn());
                    return poiRow.getCell(formulaNode.getColumn());
                });
                String oldFormula = poiCell.getCellFormula();

                LSWorkBook myWorkBook = new LSWorkBook();
                if (gridKey.substring(0, 4).equals("Work")) {
                    myWorkBook = _lsWorkbooks.get(gridKey);
                } else if (gridKey.substring(0, 4).equals("Temp")) {
                    myWorkBook = _tempWorkbooks.get(gridKey);
                } else {
                    myWorkBook = null;
                }
                LSSheet mySheet = myWorkBook.getLSSheetsByOrder(sheetOrder);
                LSCell myCell = mySheet.getCellByRowColumn(formulaNode.getRow(), formulaNode.getColumn()).getValue();
            }

            node.setNewCellNodeNameByNewSheetName(newSheetName);
            System.out.println("node.getCellNodeName() = " + node.getCellNodeName());
        }
    }

    public void updateFormulaAfterSheetName(String wbId, String oldSheetName, String newSheetName) {
        LSWorkBook myWorkBook = getMyWorkBookByID(wbId);
        for (LSSheet lsSheet : myWorkBook.getSheets()) {
            for (LSCell celldatum : lsSheet.getCelldata()) {
                if (celldatum.getV().getF() != null && celldatum.getV().getF().contains(oldSheetName)) {
                    celldatum.getV().getF().replace(oldSheetName, newSheetName);
                }
            }
        }

        Workbook poiWorkBook = getWorkbookByGridKey(wbId);
        FormulaParsingWorkbook formulaParsingWorkbook =XSSFEvaluationWorkbook.create((XSSFWorkbook) poiWorkBook);

        for (Sheet sheet : poiWorkBook) {
            // 遍历所有行
            for (Row row : sheet) {
                // 遍历所有单元格
                for (Cell cell : row) {
                    if (cell.getCellType().equals(CellType.FORMULA) && cell.getCellFormula().contains(oldSheetName)) {
                        Ptg[] ptgs = FormulaParser.parse(cell.getCellFormula(), formulaParsingWorkbook, FormulaType.CELL, poiWorkBook.getSheetIndex(sheet));

                        // 更新工作表引用
                        for (Ptg ptg : ptgs) {
                            if (ptg instanceof Ref3DPtg) {
                                Ref3DPtg refPtg = (Ref3DPtg) ptg;
                                String sheetName = poiWorkBook.getSheetName(refPtg.getExternSheetIndex());
                                if (sheetName.equals(oldSheetName)) {
                                    refPtg.setExternSheetIndex(poiWorkBook.getSheetIndex(newSheetName));
                                }
                            } else if (ptg instanceof Area3DPtg) {
                                Area3DPtg areaPtg = (Area3DPtg) ptg;
                                String sheetName = poiWorkBook.getSheetName(areaPtg.getExternSheetIndex());
                                if (sheetName.equals(oldSheetName)) {
                                    areaPtg.setExternSheetIndex(poiWorkBook.getSheetIndex(newSheetName));
                                }
                            }
                        }

                        // 重新构建公式
                        String updatedFormula = FormulaRenderer.toFormulaString(XSSFEvaluationWorkbook.create((XSSFWorkbook) poiWorkBook), ptgs);
                        cell.setCellFormula(updatedFormula);

                        LSCell lsCell = getMyWorkBookByID(wbId).getLSSheetsByOrder(poiWorkBook.getSheetIndex(sheet)).getCellByRowColumn(cell.getRowIndex(), cell.getColumnIndex()).getValue();
                        lsCell.getV().setF(updatedFormula);
                    }
                }
            }
        }
    }
}
