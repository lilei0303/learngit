package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置Value类的b字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSBorderBottom implements Serializable {
    /**
     * 边框粗细
     * 1 Thin | 2 Hair | 3 Dotted | 4 Dashed | 5 DashDot | 6 DashDotDot |
     * 7 Double | 8 Medium | 9 MediumDashed | 10 MediumDashDot | 11 MediumDashDotDot | 12 SlantedDashDot | 13 Thick
     */
    private Integer style;

    /**
     * 边框颜色 16进制颜色值
     */
    private String color;
}
