package org.geely.pms_server.backend.core.model.univer;


import org.geely.pms_server.backend.core.model.univer.en.BaselineOffset;
import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

public class StyleBase {
    private String ff; // fontFamily
    private Double fs; // fontSize
    private BooleanNumber it; // italic
    private BooleanNumber bl; // bold
    private TextDecoration ul; // underline
    private TextDecoration bbl; // bottomBorderLine
    private TextDecoration st; // strikethrough
    private TextDecoration ol; // overline
    private ColorStyle bg; // background
    private BorderData bd; // border
    private ColorStyle cl; // foreground
    private BaselineOffset va; // vertical alignment
    private NumFmtPattern n; // Numfmt pattern
}
