package org.geely.pms_server.backend.core.model.univer.en;

public enum ObjectRelativeFromV {
    PAGE,
    PARAGRAPH,
    LINE,
    MARGIN,
    TOP_MARGIN,
    BOTTOM_MARGIN,
    INSIDE_MARGIN,
    OUTSIDE_MARGIN,
}
