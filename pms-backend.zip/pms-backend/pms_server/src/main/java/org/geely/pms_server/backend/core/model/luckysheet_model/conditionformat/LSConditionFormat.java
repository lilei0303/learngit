package org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置LSSheet的luckysheet_conditionformat_save字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSConditionFormat implements Serializable {

    /**
     * "default":突出显示单元格规则和项目选区规则，
     * "dataBar":数据条，
     * "icons":图标集，
     * "colorGradation":色阶
     */
    private String type;

    /**
     * 应用的范围
     */
    private List<LSCellRangeItem> cellrange;

    /**
     * type为default时，应设置文本颜色和单元格颜色
     */
    private Object format;

    /**
     * type非default时，["rgb(248, 105, 107)", "rgb(255, 235, 132)"]
     */
    private List<String> formats;

    /**
     * 类型
     */
    private String conditionName;

    /**
     * 条件值所在单元格
     */
    private List<LSCellRangeItem> conditionRange;

    /**
     * 自定义传入的条件值
     */
    private List<String> conditionValue;
}
