package org.geely.pms_server.backend.univer;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class IWorkSheetData {
    private Map<Integer, Map<Integer, ICellData>> cellData = new HashMap<>();
}
