package org.geely.pms_server.backend.core.model.univer.en;

public enum CellValueType {
    STRING,
    NUMBER,
    BOOLEAN,
    FORCE_STRING,
}
