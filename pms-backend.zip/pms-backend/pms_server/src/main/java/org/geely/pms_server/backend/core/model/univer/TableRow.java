package org.geely.pms_server.backend.core.model.univer;

public class TableRow {
    private Double st;
    private Double ed;
    private TableCell tableCell;
    private TableRowStyle tableRowStyle;
}
