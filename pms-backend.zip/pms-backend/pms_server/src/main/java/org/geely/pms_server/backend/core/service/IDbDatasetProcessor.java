package org.geely.pms_server.backend.core.service;

import org.geely.pms_server.backend.core.model.template_model.Dataset;

public interface IDbDatasetProcessor {
    void addDataset(Dataset dataset);

    void deleteDataset(String datasetId);

    Dataset queryDataset(String datasetId);

    void updateDataset(Dataset dataset);
}
