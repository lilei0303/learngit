package org.geely.pms_server.backend.core.model.luckysheet_model.dynamicarray;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 作用：动态数组。
 * 该类详细配置LSSheet类的dynamicArray字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSDynamicArray implements Serializable {
    private Integer r;

    private Integer c;

    private String f;

    private List<List<Integer>> data;
}
