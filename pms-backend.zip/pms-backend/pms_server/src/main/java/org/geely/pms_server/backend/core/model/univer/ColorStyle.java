package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.ThemeColorType;

public class ColorStyle {
    private String rgb;
    private ThemeColorType th;
}
