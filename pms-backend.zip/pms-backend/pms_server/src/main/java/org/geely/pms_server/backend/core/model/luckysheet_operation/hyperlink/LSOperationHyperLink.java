package org.geely.pms_server.backend.core.model.luckysheet_operation.hyperlink;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.hyperlink.LSHyperLink;

import java.util.Map;

/**
 * 链接操作
 * t:hyperlink
 */
@Data
public class LSOperationHyperLink {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 所有链接信息
     */
    @JSONField(name = "v")
    private Map<String, LSHyperLink> value;
}
