package org.geely.pms_server.backend.core.model.luckysheet_model.filterselect;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置LSSheet的filter_select字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSFilterSelect implements Serializable {
    /**
     * 行范围
     */
    private List<Integer> row;

    /**
     * 列范围
     */
    private List<Integer> column;

    private Integer left;

    private Integer width;

    private Integer top;

    private Integer height;

    private Integer left_move;

    private Integer width_move;

    private Integer top_move;

    private Integer height_move;

    private Integer row_focus;

    private Integer column_focus;
}
