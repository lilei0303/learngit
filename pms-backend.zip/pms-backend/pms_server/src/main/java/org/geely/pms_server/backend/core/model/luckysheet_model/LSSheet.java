package org.geely.pms_server.backend.core.model.luckysheet_model;

import cn.hutool.core.lang.Pair;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.geely.pms_server.backend.core.model.luckysheet_model.alternateformat.LSAFormat;
import org.geely.pms_server.backend.core.model.luckysheet_model.alternateformat.LSAlternateFormat;
import org.geely.pms_server.backend.core.model.luckysheet_model.calcchain.LSFormula;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;
import org.geely.pms_server.backend.core.model.luckysheet_model.chart.LSChart;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSConditionFormat;
import org.geely.pms_server.backend.core.model.luckysheet_model.config.LSConfig;
import org.geely.pms_server.backend.core.model.luckysheet_model.dataverification.LSDataVerification;
import org.geely.pms_server.backend.core.model.luckysheet_model.dynamicarray.LSDynamicArray;
import org.geely.pms_server.backend.core.model.luckysheet_model.filter.LSFilter;
import org.geely.pms_server.backend.core.model.luckysheet_model.filterselect.LSFilterSelect;
import org.geely.pms_server.backend.core.model.luckysheet_model.frozen.LSFrozen;
import org.geely.pms_server.backend.core.model.luckysheet_model.hyperlink.LSHyperLink;
import org.geely.pms_server.backend.core.model.luckysheet_model.image.LSImageItem;
import org.geely.pms_server.backend.core.model.luckysheet_model.pivottable.LSPivotTable;
import org.geely.pms_server.backend.core.service.IOperationProcessor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 该类映射一个工作表的所有属性
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSSheet implements Serializable, Cloneable {
    /**
     * 作用：工作表名称
     */
    private String name = "Sheet1";

    /**
     * 作用：工作表颜色，工作表名称下方会有一条底部边框
     */
    private String color;

    /**
     * 作用：工作表索引，作为唯一key值使用，新增工作表时会自动赋值一个随机字符串。注意index不是工作表顺序，和order区分开
     * 还可以作为工作表的Id
     */
    private String index;
    /**
     * 作用：激活状态，仅有一个激活状态的工作表，其他工作表为 0
     */
    private Integer status;

    /**
     * 作用：工作表的下标，代表工作表在底部sheet栏展示的顺序，新增工作表时会递增，从0开始
     */
    private Integer order;

    /**
     * 作用：是否隐藏，0为不隐藏，1为隐藏
     */
    private Integer hide;

    /**
     * 作用：单元格行数
     */
    private Integer row = 84;

    /**
     * 作用：单元格列数
     */
    private Integer column = 60;

    /**
     * 作用：自定义的默认行高，单位为px
     */
    private Integer defaultRowHeight;

    /**
     * 作用：自定义的默认列宽，单位为px
     */
    private Integer defaultColWidth;

    /**
     * 作用：储sheet中所有单元格中的值，是一个包含{r:0,c:0,v:{m:"value",v:"value",ct: {fa: "General", t: "g"}}}格式单元格信息的一维数组
     */
    private List<LSCell> celldata = new ArrayList<>();

    /**
     * 作用：表格行高、列宽、合并单元格、边框、隐藏行等设置
     */
    private LSConfig config;

    /**
     * 作用：左右滚动条位置
     */
    private Integer scrollLeft;

    /**
     * 作用：上下滚动条位置
     */
    private Integer scrollTop;

    /**
     * 作用：选中的区域，支持多选，是一个包含多个选区对象的一维数组
     */
    private List<LSCellRangeItem> luckysheet_select_save;

    /**
     * 作用：公式链是一个由用户指定顺序排列的公式信息数组，Luckysheet会根据此顺序来决定公式执行的顺序。
     * 注意，在初始化工作簿的时候，如果有单元格包含公式，请务必添加对应单元格位置的公式链，否则Luckysheet无法识别公式。
     */
    private List<LSFormula> calcChain = new ArrayList<>();

    /**
     * 作用：是否数据透视表
     */
    private Boolean isPivotTable;

    /**
     * 作用：数据透视表设置
     */
    private LSPivotTable pivotTable;

    /**
     * 作用：筛选范围。一个选区，一个sheet只有一个筛选范围，类似luckysheet_select_save。
     * 如果仅仅只是创建一个选区打开筛选功能，则配置这个范围即可，如果还需要进一步设置详细的筛选条件，则需要另外配置同级的 filter 属性。
     */
    private LSFilterSelect filter_select;

    /**
     * 作用：筛选的具体设置，跟filter_select筛选范围是互相搭配的。
     * filter[key]的key值，表示是列索引，从0开始，具体设置项中的cindex是从1开始，和这里的key是同一个意思
     */
    private Map<String, LSFilter> filter;

    /**
     * 作用：交替颜色配置
     */
    private List<LSAlternateFormat> luckysheet_alternateformat_save;

    /**
     * 作用：自定义交替颜色，包含多个自定义交替颜色的配置
     */
    private List<LSAFormat> luckysheet_alternateformat_save_modelCustom;

    /**
     * 作用：条件格式配置信息，包含多个条件格式配置对象的一维数组
     */
    private List<LSConditionFormat> luckysheet_conditionformat_save;

    /**
     * 作用：冻结行列设置，分为6种类型
     */
    private LSFrozen frozen;

    /**
     * 作用：图表配置，参照chartMix的配置格式，允许只设置想要的图表属性。
     */
    private List<LSChart> chart;

    /**
     * 作用：此sheet页的缩放比例，为0~1之间的二位小数数字。比如0.1、0.56
     */
    private double zoomRatio = 1;

    /**
     * 作用：插入表格中图片信息，包含图片地址、宽高、位置、裁剪等信息
     */
    private Map<String, LSImageItem> images;

    /**
     * 作用：是否显示网格线，1表示显示，0表示隐藏
     */
    private Integer showGridLines;

    /**
     * 作用：表格插入链接的详细信息
     */
    private Map<String, LSHyperLink> hyperlink;

    /**
     * 作用：动态数组
     */
    private List<LSDynamicArray> dynamicArray;

    /**
     * 作用：数据验证配置
     */
    private Map<String, LSDataVerification> dataVerification;

    //根据L名称和order创建LSSheet
    public LSSheet(String name, int order) {
        this.name = name;
        this.order = order;
    }

    @Override
    public LSSheet clone() {
        try {
            LSSheet cloned = (LSSheet) super.clone();

            // clone all non-primitive and non-immutable objects here, for example:
            // if celldata is ArrayList<LSCell>, you can clone it like this
            cloned.celldata = new ArrayList<>(this.celldata);

            // do this for all other non-primitive and non-immutable objects

            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError("Cloning not supported", e);
        }
    }

    public Pair<Integer, LSCell> getCellByRowColumn(int row, int column) {
        int size = celldata.size();
        for (int i = 0; i < size; i++) {
            if (celldata.get(i).getR() == row && celldata.get(i).getC() == column) {
                return new Pair<>(i, celldata.get(i));
                // 当查找到满足当前条件的单元格时，跳出循环
            }
        }
        LSCell lsCell = new LSCell(row, column, this.getIndex(), new LSCellValue());
        celldata.add(lsCell);
        return new Pair<>(size, lsCell);
    }

    public boolean IsLSCellInSheet(LSCell lsCell) {
        //根据传入单元格的行列在当前lsSheet中查找是否存在
        if (this.getCellByRowColumn(lsCell.getR(), lsCell.getC()) == null) {
            return false;
        } else {
//            System.out.println("所查找单元格存在于当前lsSheet中");
            return true;
        }
    }
}
