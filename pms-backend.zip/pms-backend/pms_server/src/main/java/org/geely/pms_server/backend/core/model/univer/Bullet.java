package org.geely.pms_server.backend.core.model.univer;

public class Bullet {
    String listType;
    String listId;
    Double nestingLevel;
    TextStyle textStyle;
}
