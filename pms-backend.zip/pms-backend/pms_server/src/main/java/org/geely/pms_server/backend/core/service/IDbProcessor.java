package org.geely.pms_server.backend.core.service;

import org.geely.pms_server.backend.core.dto.manage_workbook.LSWorkbookInfo;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;

import java.util.List;

/**
 * 提供对工作簿数据的存取接口
 */
public interface IDbProcessor {
    /**
     * 用户新建工作簿时调用此接口
     *
     * @return LSWorkBook 对象
     */
    LSWorkBook loadNewWb();

    /**
     * 用户打开已有工作簿调用此接口
     *
     * @param wbId
     * @return
     */
    LSWorkBook loadWorkbook(String wbId);

    /**
     * 数据导入
     *
     * @param workBook
     * @return
     */
    LSWorkBook importWorkbook(LSWorkBook workBook, String wbId);

    /**
     * 保存内存态的LSWorkBook到数据库
     *
     * @param workBook
     */
    void saveWorkbook(LSWorkBook workBook);

    /**
     * 从内存和数据库均删除该wb
     *
     * @param wbId
     */
    void deleteWorkbook(String wbId);

    /**
     * 获取数据库所有工作簿的信息
     *
     * @return
     */
    List<LSWorkbookInfo> getAllWorkbookInfo();

    /**
     * 判断 Workbook 是否存在
     *
     * @param wbId
     * @return 如果存在返回 true
     */
    Boolean workbookExists(String wbId);

    /**
     * 获取workbook第一块数据
     *
     * @param wbId
     * @return
     */
    List<LSCell> getFirstBlock(String wbId);

}
