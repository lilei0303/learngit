package org.geely.pms_server.backend.core.model.univer;

public class SectionColumnProperties {
    private Double width;
    private Double paddingEnd;
}
