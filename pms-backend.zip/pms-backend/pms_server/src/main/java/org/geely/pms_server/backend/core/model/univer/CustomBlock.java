package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BlockType;

public class CustomBlock {
    private Double startIndex;
    private BlockType blockType;
    private String blockId;
}
