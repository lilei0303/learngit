package org.geely.pms_server.backend.core.model.univer.en;

public enum HorizontalAlign {
    UNSPECIFIED, //	The horizontal alignment is not specified. Do not use this.
    LEFT, //	The text is explicitly aligned to the left of the cell.
    CENTER, //	The text is explicitly aligned to the center of the cell.
    RIGHT, //	The text is explicitly aligned to the right of the cell.
    JUSTIFIED, //	The paragraph is justified.
}
