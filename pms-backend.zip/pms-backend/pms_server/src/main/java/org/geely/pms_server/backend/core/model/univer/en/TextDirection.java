package org.geely.pms_server.backend.core.model.univer.en;

public enum TextDirection {
    UNSPECIFIED,
    LEFT_TO_RIGHT,
    RIGHT_TO_LEFT,
}
