package org.geely.pms_server.backend.core.model.calcChain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.util.CellReference;

import java.util.HashSet;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CalcNode {
    // 行
    private Integer r;

    // 列
    private Integer c;

    // sheet索引
    private String index;

   // 包含公式
    private String func;

    // 公式单元格引用的单元格数组
    private HashSet<ReferencingCell> referencingCells = new HashSet<>();

    // 当前公式链节点的单元格名称
    private String cellName;

    // 后端公式标记位
    private boolean isBackendFormula;

    public CalcNode(int row, int column, String index) {
        this.r = row;
        this.c = column;
        this.index = index;
    }

    public CalcNode(int row, int column, String index, String func) {
        this.r = row;
        this.c = column;
        this.index = index;
        this.func = func;
    }

    public boolean containsCell(String cellName) {
        for (ReferencingCell referencingCell : referencingCells) {
            String[] parts = cellName.split("!");
            //表示当前对象是范围单元格，例如A1:B2
            // 检查是否是单个单元格
            if (!referencingCell.getExpression().contains(":")) {
                //sheetName与单元格名称必须完全相同
                if (referencingCell.getSheetName().equals(parts[0]) && referencingCell.getExpression().equals(parts[1])) {
                    return true;
                }
            }else {
                // 分割范围字符串为起始和结束单元格
                String[] bounds = referencingCell.getExpression().split(":");
                String startCell = bounds[0];
                String endCell = bounds[1];
                CellReference cellReference = new CellReference(cellName);

                CellReference startRef = new CellReference(startCell);
                CellReference endRef = new CellReference(endCell);

                // 将单元格转换为数字
                int startCol = (int)startRef.getCol() + 1;
                int startRow = startRef.getRow() + 1;
                int endCol = (int)endRef.getCol() + 1;
                int endRow = endRef.getRow() + 1;

                // 将待判断的单元格转换为数字
                int testCol = (int)cellReference.getCol() + 1;
                int testRow = cellReference.getRow() + 1;

                // 判断单元格是否在范围内
                if (testCol >= startCol && testCol <= endCol && testRow >= startRow && testRow <= endRow) {
                    return true;
                }
            }
        }
        //全部遍历完仍然没有发现匹配，返回false
        return false;
    }

    // 将Excel列字母转换为数字
    public static int cellToNumber(String col) {
        int result = 0;
        for (int i = 0; i < col.length(); i++) {
            int charNum = (col.charAt(i) - 'A') + 1;
            result = result * 26 + charNum;
        }
        return result;
    }

    // 重写equals方法
    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        CalcNode other = (CalcNode) object;
        return r == other.r && c == other.c && Objects.equals(index, other.getIndex());
    }

    @Override
    public int hashCode() {
        return Objects.hash(r, c, index);
    }
}
