package org.geely.pms_server.backend.core.model.formulaChain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellReference;

import java.util.Objects;

// 定义顶点类
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FormulaNode {
    private String cellNodeName;
    private String formula;
    private int row;
    private int column;
    private String cellValue;
    private boolean _isBackendFormula;
    //与_isBackendFormula区别在于，_isBackendFormula由前端定义，含义为该单元格是否为后端公式
    //而_isBackendCalculate的含义则为，本次更新公式链时该单元格本身为后端公式或者本身前端公式但是其前置依赖中包含后端公式，那么它则需要被设置成true
    private boolean _isBackendCalculate;
    //sheetIndex作为每一个sheet得唯一标识符，可以区分不同sheet之间相同名称的单元格
    private String _sheetIndex;

    public FormulaNode(Cell cell, boolean isBackendFormula, String sheetIndex) {
        this.row = cell.getRowIndex();
        this.column = cell.getColumnIndex();
        this.formula = cell.getCellFormula();
//        this.cellNodeName = new CellReference(this.row, this.column).formatAsString();
        this.cellNodeName = new CellReference(cell).formatAsString();
        this._isBackendFormula = isBackendFormula;
        this._isBackendCalculate = isBackendFormula;
        this._sheetIndex = sheetIndex;
    }

    public FormulaNode(String cellNodeName, boolean _isBackendFormula, boolean isBackendCalculate, String sheetIndex) {
        this.cellNodeName = cellNodeName;
        this._isBackendCalculate = isBackendCalculate;
        this._isBackendFormula = _isBackendFormula;
        this._sheetIndex = sheetIndex;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        FormulaNode that = (FormulaNode) obj;
        return
//                row == that.row &&
//                column == that.column &&
//                Objects.equals(formula, that.formula) &&
//                Objects.equals(cellValue, that.cellValue) &&
//                Objects.equals(_sheetIndex, that._sheetIndex) &&
                Objects.equals(cellNodeName, that.cellNodeName);
    }

    @Override
    public int hashCode() {
//        return Objects.hash(cellNodeName, formula, row, column, cellValue);
//        return Objects.hash(cellNodeName,_sheetIndex);
        return Objects.hash(cellNodeName);
    }

    public String getSheetName() {
        int exclamationIndex = this.cellNodeName.indexOf('!');
        if (exclamationIndex != -1) {
            return this.cellNodeName.substring(0, exclamationIndex);
        } else {
            return null;
        }
    }

    public void setNewCellNodeNameByNewSheetName(String newSheetName) {
        setCellNodeName(newSheetName + this.cellNodeName.substring(this.cellNodeName.indexOf('!')));
    }
}