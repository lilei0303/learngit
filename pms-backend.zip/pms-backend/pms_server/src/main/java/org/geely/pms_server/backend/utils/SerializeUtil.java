package org.geely.pms_server.backend.utils;

import org.xerial.snappy.Snappy;

import java.io.*;

/**
 * 自定义序列化工具，方便数据存储
 */
public class SerializeUtil {

    /**
     * 对象序列化，返回字节数组
     *
     * @param object
     * @return
     */
    public static byte[] serialize(Object object) {

        ObjectOutputStream oos = null;

        ByteArrayOutputStream baos = null;

        try {
            //序列化
            baos = new ByteArrayOutputStream();

            oos = new ObjectOutputStream(baos);

            oos.writeObject(object);

            byte[] bytes = baos.toByteArray();

            //压缩
            byte[] compress = compress(bytes);
            return compress;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 字节数组反序列化，返回对象或对象列表
     *
     * @param bytes
     * @return
     */
    public static Object unSerialize(byte[] bytes) {

        ByteArrayInputStream bais = null;

        try {
            //解压缩
            byte[] uncompress = uncompress(bytes);

            //反序列化
            bais = new ByteArrayInputStream(uncompress);

            ObjectInputStream ois = new ObjectInputStream(bais);

            return ois.readObject();

        } catch (Exception ignored) {

        }
        return null;

    }

    public static byte[] compress(byte[] input) {
        try {
            return Snappy.compress(input);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static byte[] uncompress(byte[] input) {
        try {
            return Snappy.uncompress(input);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


}