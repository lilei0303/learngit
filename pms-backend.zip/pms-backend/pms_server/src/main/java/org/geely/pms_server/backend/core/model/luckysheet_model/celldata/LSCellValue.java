package org.geely.pms_server.backend.core.model.luckysheet_model.celldata;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.config.LSMerge;

import java.io.Serializable;

/**
 * 该类详细配置LSCell类的v字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCellValue implements Serializable {


    /**
     * 作用：单元格值格式：文本、时间等
     */
    private LSCellCT ct;

    /**
     * 内容的原始值
     */
    private String v;

    /**
     * 内容的显示值
     */
    private String m;

    /**
     * 背景
     */
    private String bg;

    /**
     * 字体
     */
    private String ff;

    /**
     * 字体颜色
     */
    private String fc;

    /**
     * 作用：字体加粗，0 常规 、1 加粗
     */
    private Integer bl;

    /**
     * 作用：字体斜体，0 常规 、1 斜体
     */
    private Integer it;

    /**
     * 字体大小
     */
    private Integer fs;

    /**
     * 作用：启用删除线，0 常规 、1 删除线
     */
    private Integer cl;

    /**
     * 作用：水平对齐，0 居中、1 左、2 右
     */
    private Integer ht;

    /**
     * 作用：垂直对齐，0 中间、1 上、2 下
     */
    private Integer vt;

    /**
     * 作用：合并单元格，主单元格{ r:0, c:0, rs: 2, cs:2 }，辅单元格{ r:0, c:0 }
     */
    private LSMerge mc;

    /**
     * 作用：竖排文字
     */
    private Integer tr;

    /**
     * 作用：文字旋转角度，介于0~180之间的整数，包含0和180
     */
    private Integer rt;

    /**
     * 作用：文本换行，0 截断、1 溢出、2 自动换行
     */
    private Integer tb;

    /**
     * 批注
     */
    private LSCellPS ps;

    /**
     * 公式
     */
    private String f;

    /**
     * 标记是否为后端公式
     */
    private Boolean backendFunction = false;

    /**
     * 未知功能
     */
    private Integer un;

    public LSCellValue(LSCellCT ct, String v, String m) {
        this.ct = ct;
        this.v = v;
        this.m = m;
    }

    /**
     * Returns the value of the "m" field in the LSCellValue object.
     * If the "m" field is blank or null, it returns an empty string.
     *
     * @return the value of the "m" field or an empty string
     */
    public String getM() {
        if (m == null) { return ""; }
        else { return m; }
    }
}