package org.geely.pms_server.backend.core.repository.univer;

import org.geely.pms_server.backend.core.entity.univer.UniverWorkbook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UniverWorkbookRepository extends JpaRepository<UniverWorkbook, String> {
    UniverWorkbook findByMinioId(String minioId);

    void deleteById(String minioId);
}
