package org.geely.pms_server.backend.core.service.impl;

import cn.hutool.core.lang.Pair;
import com.alibaba.fastjson2.JSON;
import jakarta.annotation.Resource;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.formula.*;
import org.apache.poi.ss.formula.ptg.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.geely.pms_server.backend.core.entity.workbook.WorkBookEntity;
import org.geely.pms_server.backend.core.model.calcChain.CalcNode;
import org.geely.pms_server.backend.core.model.calcChain.ReferencingCell;
import org.geely.pms_server.backend.core.model.calculate.LSFormulaEvaluator;
import org.geely.pms_server.backend.core.model.calculate.WorkbookInit;
import org.geely.pms_server.backend.core.model.calculate.WorkbookManager;
import org.geely.pms_server.backend.core.model.formulaChain.FormulaChainManager;
import org.geely.pms_server.backend.core.model.formulaChain.FormulaNode;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.calcchain.LSFormula;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;
import org.geely.pms_server.backend.core.model.luckysheet_model.config.LSConfig;
import org.geely.pms_server.backend.core.model.luckysheet_operation.LSOperationMv;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCell;
import org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh.LSOperationRefreshCellRange;
import org.geely.pms_server.backend.core.model.luckysheet_operation.config.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterClear;
import org.geely.pms_server.backend.core.model.luckysheet_operation.filter.LSOperationFilterRestore;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChain;
import org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains.LSOperationCalcChainAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.hyperlink.LSOperationHyperLink;
import org.geely.pms_server.backend.core.model.luckysheet_operation.images.LSOperationImages;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnAdd;
import org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn.LSOperationRowOrColumnDel;
import org.geely.pms_server.backend.core.model.luckysheet_operation.sheet.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage.*;
import org.geely.pms_server.backend.core.model.luckysheet_operation.workbook.LSOperationWbName;
import org.geely.pms_server.backend.core.repository.workbook.WorkBookRepository;
import org.geely.pms_server.backend.core.service.IOperationProcessor;
import org.geely.pms_server.backend.utils.CellUtility;
import org.springframework.stereotype.Service;
import org.springframework.util.SerializationUtils;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import static java.lang.Math.max;

@Service
@NoArgsConstructor
public class OperationProcessor implements IOperationProcessor {
    @Resource
    WorkBookRepository workBookRepository;

    static final Logger logger = LogManager.getLogger(IOperationProcessor.class);

    // 缓存删除的Sheet，撤销操作时可以找回数据--<wbId,<index,sheet>>
    @Getter
    private static final Map<String, Map<String, LSSheet>> cacheDelLSWb = new HashMap<>();
    @Resource
    WorkbookInit workbookInit;
    // 如果本次更新涉及公式链操作，则发送消息给前端，否则不发送消息

    @Override
    public LSCell calculateCell(String lsWorkbookID, String sheetIndex, Integer row, Integer col) {
        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(lsWorkbookID);
        LSSheet lsSheet = lsWorkBook.getLSSheetsByIndex(sheetIndex).orElseThrow(() -> new RuntimeException("Sheet not found"));
        Pair<Integer, LSCell> pair = lsSheet.getCellByRowColumn(row, col);
        LSCell lsCell = pair.getValue();

        // 如果当前单元格中包含公式
        LSFormulaEvaluator lsFormulaEvaluator = new LSFormulaEvaluator();
        // 传入所要计算单元格所在lsWOrkBook的ID、lsSheet的index以及要计算的lsCell本身
        lsCell.setV(lsFormulaEvaluator.LSEvaluateInLSCell(lsWorkbookID, sheetIndex, lsCell).getV());
        return lsCell;
    }

    // 用户刷新某个单元格
    @Override
//    public List<LSCell> processRefreshCell(String lsWorkbookID, LSOperationRefreshCell operation) throws Exception {
    public List<LSCell> processRefreshCell(String lsWorkbookID, LSOperationRefreshCell operation) {

        int row = operation.getRow();
        int column = operation.getColumn();
        String sheetIndex = operation.getIndex();
        String oldCellFormula;

        // 本次更新单元格操作引起的所要修改的公式链上的结点
        List<FormulaNode> nodesToUpdate = null;
        List<LSCell> lsCellsToUpdate;

        // --- 0. 获取 lsCell 和 poiCell ---

        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(lsWorkbookID);
        LSSheet lsSheet = lsWorkBook.getLSSheetsByIndex(sheetIndex).orElseThrow(() -> new RuntimeException("Sheet not found"));
        String cellName = lsSheet.getName() + "!" + new CellReference(row, column).formatAsString();
        FormulaChainManager formulaChainManager = workbookInit.getFormulaChainByID(lsWorkbookID);

        Pair<Integer, LSCell> pair = lsSheet.getCellByRowColumn(row, column);
        LSCell lsCell = pair.getValue();
        Integer lsCellPosition = pair.getKey();

        Workbook poiWorkbook = workbookInit.getWorkbookByGridKey(lsWorkbookID);
        Sheet poiSheet = poiWorkbook.getSheetAt(lsSheet.getOrder());
        EvaluationWorkbook evalWorkbook = XSSFEvaluationWorkbook.create((XSSFWorkbook) poiWorkbook);


        // 如果此次操作为删除或更新，即原单元格中有内容，则更新前置依赖
        if (lsCell.getV() != null && lsCell.getV().getV() != null) {
            Row poiRow = Optional.ofNullable(poiSheet.getRow(row)).orElseGet(() -> {
                poiSheet.createRow(row);
                return poiSheet.getRow(row);
            });
            Cell oldPoiCell = Optional.ofNullable(poiRow.getCell(column)).orElseGet(() -> {
                poiRow.createCell(column);
                return poiRow.getCell(column);
            });
            if (oldPoiCell.getCellType().equals(CellType.FORMULA)) {
                // 更新公式链
                oldCellFormula = oldPoiCell.getCellFormula();
                formulaChainManager.updateFormerDependencies(cellName, oldCellFormula, evalWorkbook, lsSheet.getName(), lsSheet.getOrder());
                //                logger.debug("\n\n此处为用户更新或删除公式单元格------------------------------------");
                //                formulaChainManager.getFormulaChain();
            }
        }

        Row poiRow = Optional.ofNullable(poiSheet.getRow(row)).orElseGet(() -> {
            poiSheet.createRow(row);
            return poiSheet.getRow(row);
        });
        Cell poiCell = Optional.ofNullable(poiRow.getCell(column)).orElseGet(() -> {
            poiRow.createCell(column);
            return poiRow.getCell(column);
        });

        // --- 1. 更新内存中 lsCell 和 poiCell 的值 ---

        // 更新 lsCell 的值
        lsCell.setV(operation.getValue());

        // 如果 CellValue 为 null，删除这个 cell
        if (operation.getValue() == null) {
            lsSheet.getCelldata().remove(lsCellPosition.intValue());
            poiRow.removeCell(poiCell);

            // 检查当前单元格结点是否存在于公式链当中
            if (formulaChainManager.formulaChain.containsKey(cellName)) {
                formulaChainManager.formulaChain.getFormulaNode(cellName).set_isBackendFormula(false);
                formulaChainManager.formulaChain.getFormulaNode(cellName).set_isBackendCalculate(false);
                // 第三个参数设置为true表示本次更新为删除操作
                // nodesToUpdate = formulaChainManager.updateCellNodeBFS(cellName, lsSheet.getOrder(), operation.getValue().getBackendFunction(),true);
                // 删除时operation.getValue().getBackendFunction()一定为false
                nodesToUpdate = formulaChainManager.updateCellNodeBFS(cellName, lsSheet.getOrder(), false, true, evalWorkbook, poiSheet.getSheetName());
                // 在公式链中将当前结点删除
                // formulaChainManager.formulaChain.removeByCellNodeName(cellName);
            }
            // 如果本次更新不涉及任何后端公式结点，则nodesToUpdate为空，不返回给前端
            if (nodesToUpdate == null) {
                return new ArrayList<>();
            } else {
                lsCellsToUpdate = getLSCellsByFormulaNodes(lsWorkbookID, sheetIndex, nodesToUpdate);
                lsCellsToUpdate.add(lsCell);
                return lsCellsToUpdate;
            }
        }

        // 如果单元格的真实值为空，则不需要给 poiCell 赋值
        // 保证后续处理，真实值 v 一定存在
        if (operation.getValue().getV() == null || operation.getValue().getV() == "") {

            // 这里要多一步操作，将poiCell中的值清除，并且需要在下面的步骤之前进行，因为updateCellNodeBFS中计算会需要使用到当前单元格的值
            poiCell.setCellValue(0);
            // 注意不仅要将值置空，公式也要清除！
            poiCell.setCellFormula(null);

            // 检查当前单元格结点是否存在于公式链当中
            if (formulaChainManager.formulaChain.containsKey(cellName)) {
                // 第三个参数设置为true表示本次更新为删除操作
                //                nodesToUpdate = formulaChainManager.updateCellNodeBFS(cellName, lsSheet.getOrder(), operation.getValue().getBackendFunction(),true);
                // 删除时operation.getValue().getBackendFunction()一定为false
                nodesToUpdate = formulaChainManager.updateCellNodeBFS(cellName, lsSheet.getOrder(), false, true, evalWorkbook, poiSheet.getSheetName());
                // 在公式链中将当前结点删除
                //                formulaChainManager.formulaChain.removeByCellNodeName(cellName);
                //                formulaChainManager.formulaChain.remove(cellName);
            }

            if (nodesToUpdate == null && !operation.getValue().getBackendFunction()) {
                return new ArrayList<>();
            } else {
                lsCellsToUpdate = getLSCellsByFormulaNodes(lsWorkbookID, sheetIndex, nodesToUpdate);
                lsCellsToUpdate.add(lsCell);
                return lsCellsToUpdate;
            }
        }

        // 如果 cell value 为数字，将其转换为 double 设置给 poi cell
        // 否则将字符串设置给 poi cell
        if (WorkbookManager.isNumeric(operation.getValue().getV())) {
            //            System.out.println("operation.getValue().getV() = " + operation.getValue().getV());
            double doubleValue = Double.parseDouble(operation.getValue().getV());
            poiCell.setCellValue(doubleValue);
        } else {
            poiCell.setCellValue(operation.getValue().getV());
        }

        // --- 2.如果该单元格为后端公式，进行计算 ---
        //        if (operation.getValue().getBackendFunction()) {
        if (operation.getValue().getF() != null && !operation.getValue().getM().equals("#NAME?") && !operation.getValue().getM().equals("#VALUE!")) {
//            try {
            poiCell.setCellFormula(operation.getValue().getF().substring(1));
            lsCell.setV(calculateCell(lsWorkbookID, operation.getIndex(), row, column).getV());
//            } catch (NotImplementedException | FormulaParseException | IllegalStateException e) {
//                logger.debug("当前单元格公式不合法！  -->  row:" + row + " column:" + column + " formula:" + operation.getValue().getF());
//                throw new Exception(e);
//            }
        } else {
            // 如果不是公式则要设置公式为空，防止更新之前的单元格poiCell中包含公式
            poiCell.setCellFormula(null);
        }

        nodesToUpdate = formulaChainManager.updateCellNode(poiCell, lsSheet.getOrder(), operation.getValue().getBackendFunction(), sheetIndex, evalWorkbook, poiSheet.getSheetName());
        if (nodesToUpdate == null && !operation.getValue().getBackendFunction()) {
            return new ArrayList<>();
        } else {
            lsCellsToUpdate = getLSCellsByFormulaNodes(lsWorkbookID, sheetIndex, nodesToUpdate);
            lsCellsToUpdate.add(lsCell);
            return lsCellsToUpdate;
        }
    }

    public List<LSCell> newProcessRefreshCell(String lsWorkbookID, LSOperationRefreshCell operation) {

        int row = operation.getRow();
        int column = operation.getColumn();
        String sheetIndex = operation.getIndex();
        // 本次跟新是否涉及后端公式，如果是则需要将更新结果返回给前端
        AtomicBoolean isBackendFormula = new AtomicBoolean(false);
        Boolean isBackend = false;

        // 本次更新单元格操作引起的所要修改的公式链上的结点
        List<LSCell> lsCellsToUpdate;

        // --- 0. 获取 lsCell 和 poiCell ---

        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(lsWorkbookID);
        LSSheet lsSheet = lsWorkBook.getLSSheetsByIndex(sheetIndex).orElseThrow(() -> new RuntimeException("Sheet not found"));
        // 前端公式链
        HashSet<CalcNode> calcChain = lsWorkBook.getCalcChains();
        CalcNode presentCalcNode = new CalcNode(operation.getRow(), operation.getColumn(), operation.getIndex());

        String cellName = lsSheet.getName() + "!" + new CellReference(row, column).formatAsString();
        FormulaChainManager formulaChainManager = workbookInit.getFormulaChainByID(lsWorkbookID);

        Pair<Integer, LSCell> pair = lsSheet.getCellByRowColumn(row, column);
        LSCell lsCell = pair.getValue();
        Integer lsCellPosition = pair.getKey();

        Workbook poiWorkbook = workbookInit.getWorkbookByGridKey(lsWorkbookID);
        Sheet poiSheet = poiWorkbook.getSheetAt(lsSheet.getOrder());
        EvaluationWorkbook evalWorkbook = XSSFEvaluationWorkbook.create((XSSFWorkbook) poiWorkbook);

        // 如果此次操作为删除或更新，即原单元格中有内容，则更新前置依赖，在新版本公式链下后端无需做任何变动

        // 获取当前改动单元格对应的poiCell
        Row poiRow = Optional.ofNullable(poiSheet.getRow(row)).orElseGet(() -> {
            poiSheet.createRow(row);
            return poiSheet.getRow(row);
        });
        Cell poiCell = Optional.ofNullable(poiRow.getCell(column)).orElseGet(() -> {
            poiRow.createCell(column);
            return poiRow.getCell(column);
        });

        // --- 更新内存中 lsCell 和 poiCell 的值 ---

        // 更新 lsCell 的值
        lsCell.setV(operation.getValue());

        // 如果 CellValue 为 null，删b除这个 cell
        if (operation.getValue() == null) {
            lsSheet.getCelldata().remove(lsCellPosition.intValue());
            poiRow.removeCell(poiCell);
        }
        // CellValue不为null
        else {
            // 如果单元格的真实值为空，则不需要给 poiCell 赋值
            // 保证后续处理，真实值 v 一定存在
            if (StringUtils.isBlank(operation.getValue().getV()) && StringUtils.isBlank(operation.getValue().getF())) {
                // 将当前单元格设置为blank
                poiCell.setBlank();
            }
            // cellValue中的值不为空
            else {
                // 公式链的建立与维护更新
//                if (operation.getValue().getF() != null || operation.getValue().getBackendFunction()) {
//                if (operation.getValue().getF() != null && !operation.getValue().getM().equals("#NAME?") && !operation.getValue().getM().equals("#VALUE!")) {
                if (operation.getValue().getF() != null) {
                    // 为poiCell的formula进行赋值
                    poiCell.setCellFormula(operation.getValue().getF().substring(1));
                    HashSet<ReferencingCell> referencingCells = CellUtility.extractReferencingCellsInFormula(operation.getValue().getF().substring(1), evalWorkbook, lsSheet.getName(), lsSheet.getOrder());
                    isBackendFormula.set(isBackendFormula.get() || operation.getValue().getBackendFunction());
                    CellType cellType = poiWorkbook.getCreationHelper().createFormulaEvaluator().evaluateFormulaCell(poiCell);
                    lsCell.getV().setV(CellUtility.getCellValueString(poiCell, cellType));
                    // 如果当前单元格不包含在公式链当中
                    if (!calcChain.contains(presentCalcNode)) {
                        presentCalcNode.setFunc(operation.getValue().getF());
                        presentCalcNode.setCellName(cellName);
                        presentCalcNode.setReferencingCells(referencingCells);
                        presentCalcNode.setBackendFormula(operation.getValue().getBackendFunction());
                        calcChain.add(presentCalcNode);
                    } else {
                        calcChain.forEach(calcNode -> {
                            // 判断当前单元格是否包含在公式链当中，如果是则更新公式链中的Func字段与referencingCells字段以及
                            // 更新lsFormula中的Func字段
                            if (calcNode.equals(presentCalcNode)) {
                                calcNode.setFunc(operation.getValue().getF());
                                // 更新lsFormula中的referencingCells字段
                                calcNode.setReferencingCells(referencingCells);
                                calcNode.setCellName(cellName);
                                // 设置后端公式标记位
                                calcNode.setBackendFormula(operation.getValue().getBackendFunction());
                            }

                        });
                    }
                }
                // operation.getValue().getF() == null则说明当前更新操作的公式为null
                else {
                    poiCell.setCellFormula(null);
                }

                // 为poiCell的cellValue进行赋值
                // 如果 cell value 为数字，将其转换为 double 设置给 poi cell
                // 否则将字符串设置给 poi cell
                if (WorkbookManager.isNumeric(operation.getValue().getV())) {
                    double doubleValue = Double.parseDouble(operation.getValue().getV());
                    poiCell.setCellValue(doubleValue);
                } else {
                    poiCell.setCellValue(operation.getValue().getV());
                }
            }
        }

        // 清除缓存后计算工作簿内所有公式
        FormulaEvaluator formulaEvaluator = poiWorkbook.getCreationHelper().createFormulaEvaluator();
        formulaEvaluator.clearAllCachedResultValues();
        formulaEvaluator.evaluateAll();

        // 修改初始单元格的显示值
        if (operation.getValue() != null)
            lsCell.getV().setM(CellUtility.getFormattedCellValue(poiCell, lsCell, formulaEvaluator));


        Set<LSCell> visited = new HashSet<>();
        visited.add(lsCell);
        AtomicReference<Boolean> isformulaInvolved = new AtomicReference<>(operation.getValue() != null && !StringUtils.isBlank(operation.getValue().getF()));

        calcChain.forEach(calcNode -> {
            int currentRow = calcNode.getR();
            int currentCol = calcNode.getC();

            LSSheet presentLsSheet = lsWorkBook.getLSSheetsByIndex(calcNode.getIndex()).orElseThrow(() -> new RuntimeException("Sheet not found"));
            LSCell presentLSCell = presentLsSheet.getCellByRowColumn(currentRow, currentCol).getValue();
            Sheet presentPoiSheet = poiWorkbook.getSheetAt(presentLsSheet.getOrder());
            Row presentPoiRow = Optional.ofNullable(presentPoiSheet.getRow(currentRow)).orElseGet(() -> {
                presentPoiSheet.createRow(currentRow);
                return presentPoiSheet.getRow(currentRow);
            });
            Cell presentPoiCell = Optional.ofNullable(presentPoiRow.getCell(currentCol)).orElseGet(() -> {
                presentPoiRow.createCell(currentCol);
                return presentPoiRow.getCell(currentCol);
            });


            // 利用公式计算器formulaEvaluator来获取当前单元格的计算结果
            CellValue cellValue = formulaEvaluator.evaluate(presentPoiCell);

            // 根据当前单元格的计算值类型获取计算结果,并将值赋给lsCell
            switch (cellValue.getCellType()) {
                case BOOLEAN:
                    presentLSCell.getV().setV(String.valueOf(cellValue.getBooleanValue()));
                    break;
                case NUMERIC:
                    presentLSCell.getV().setV(String.valueOf(cellValue.getNumberValue()));
                    break;
                case STRING:
                    presentLSCell.getV().setV(String.valueOf(cellValue.getStringValue()));
                    break;
                case ERROR:
                    byte errorCellValue = presentPoiCell.getErrorCellValue();
                    String formulaErrorString = FormulaError.forInt(errorCellValue).getString();
                    presentLSCell.getV().setV(formulaErrorString);
                    break;
            }

            presentLSCell.getV().setF("=" + presentPoiCell.getCellFormula());
            presentLSCell.getV().setM(CellUtility.getFormattedCellValue(presentPoiCell, presentLSCell, formulaEvaluator));

            visited.add(presentLSCell);

            if (calcNode.containsCell(cellName)) {
                isformulaInvolved.set(true);
            }
        });

        // contains Formula ?  True                  : False
        return isformulaInvolved.get() ? new ArrayList<>(visited) : new ArrayList<>();

        /*
        原版并行计算
         */
//        long l1 = System.currentTimeMillis();
//        Set<LSCell> visited = ConcurrentHashMap.newKeySet();
//        visited.add(lsCell);
//        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
//        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
//        queue.offer(cellName);

//        while (!queue.isEmpty() && queue.peek() != null) {
//            Future<?> future = null;
//            String tempName = queue.poll();
//            for (CalcNode node : calcChain) {
//                if (node.getReferencingCells().contains(tempName)) {
//                    future = executor.submit(() -> {
//                        Thread currentThread = Thread.currentThread();
//                        long l11 = System.currentTimeMillis();
//                        long l111 = 0;
//                        long l222 = 0;
//                        LSSheet presentLsSheet = lsWorkBook.getLSSheetsByIndex(node.getIndex()).orElseThrow(() -> new RuntimeException("Sheet not found"));
//                        LSCell presentLSCell = presentLsSheet.getCellByRowColumn(node.getR(), node.getC()).getValue();
//
//                        if (visited.contains(presentLSCell)) {
////                            continue;
//                            return;
//                        }
//
//                        visited.add(presentLSCell);
//                        queue.offer(node.getCellName());
//                        Sheet presentPoiSheet = poiWorkbook.getSheetAt(presentLsSheet.getOrder());
//                        Row presentPoiRow = Optional.ofNullable(presentPoiSheet.getRow(node.getR())).orElseGet(() -> {
//                            presentPoiSheet.createRow(node.getR());
//                            return presentPoiSheet.getRow(node.getR());
//                        });
//                        Cell presentPoiCell = Optional.ofNullable(presentPoiRow.getCell(node.getC())).orElseGet(() -> {
//                            presentPoiRow.createCell(node.getC());
//                            return presentPoiRow.getCell(node.getC());
//                        });
//
//                        if (presentPoiCell.getCellType().equals(CellType.FORMULA)) {
//                            l111 = System.currentTimeMillis();
//                            CellType cellType = poiWorkbook.getCreationHelper().createFormulaEvaluator().evaluateFormulaCell(presentPoiCell);
//                            l222 = System.currentTimeMillis();
//
//                            presentLSCell.getV().setM(CellUtility.getCellValueString(presentPoiCell, cellType));
//                            presentLSCell.getV().setV(CellUtility.getCellValueString(presentPoiCell, cellType));
//
//                            presentLSCell.getV().setF("=" + presentPoiCell.getCellFormula());
//
//                            // 由于LSCell中的equals方法已被重写，相同r，c，sheetIndex的lsCell会被视作同一元素
//                            // 所以此处不用判断visited当中是否已经包含当前节点
//                            // 如果不包含则直接加入，包含的话会将新的值进行覆盖
//                            visited.add(presentLSCell);
//
//                            // 如果公式链当中存在某一个结点为后端公式，那么本次更新就需要发送给前端
//                            if (node.isBackendFormula()) {
//                                isBackendFormula.set(true);
//                            }
//                        }
//                        long l22 = System.currentTimeMillis();
//                        System.out.println(currentThread.getName() + ": (l22 - l11) = " + (l22 - l11) + " (l222 - l111) = " + (l222 - l111));
//                    });
//                }
//            }
//
//            //等待线程执行完毕，否则有可能线程还在执行，队列queue中的元素已经出列完了，
//            // 所以需要等待线程执行完毕向队列中添加元素
//            try {
//                // 等待任务完成
//                if (future != null){
//                    future.get();
//                }
//            } catch (InterruptedException | ExecutionException e) {
//                // 处理中断或执行异常
//                e.printStackTrace();
//            }
//        }
//
//        executor.shutdown();
//        try {
//            if (!executor.awaitTermination(1, TimeUnit.HOURS)) {
//                executor.shutdownNow();
//            }
//        } catch (InterruptedException e) {
//            executor.shutdownNow();
//            Thread.currentThread().interrupt();
//        }
//
//        long l2 = System.currentTimeMillis();
//        System.out.println("l2 - l1 = " + (l2 - l1));
//
//        if (isBackendFormula.get()) {
//            return new ArrayList<>(visited);
//        } else {
//            return new ArrayList<>();
//        }
    }

    public List<LSCell> getLSCellsByFormulaNodes(String lsWorkbookID, String sheetIndex, List<FormulaNode> nodesToUpdate) {
        if (nodesToUpdate != null) {
            List<LSCell> lsCellsToUpadate = new ArrayList<>();
            LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(lsWorkbookID);
            lsWorkBook.getSheets().forEach(lsSheet -> {
                for (FormulaNode node : nodesToUpdate) {
                    if (node.get_sheetIndex().equals(lsSheet.getIndex())) {
                        LSCell lsCell = lsSheet.getCellByRowColumn(node.getRow(), node.getColumn()).getValue();
                        lsCell.getV().setV(String.valueOf(node.getCellValue()));
                        lsCell.getV().setM(String.valueOf(node.getCellValue()));
                        lsCellsToUpadate.add(lsCell);
                    }
                }
            });
            return lsCellsToUpadate;
        } else {
            return new ArrayList<>();
        }
    }

    @Override
    public List<List<LSCell>> processRefreshCellRange(String lsWorkbookID, LSOperationRefreshCellRange operation
//    ) throws Exception {
    ) {
        // 获取刷新的单元格
        List<List<LSCellValue>> value = operation.getValue();
        List<List<LSCell>> lsCellsToReturn = new ArrayList<>();

        // 刷新单元格的行列起始下标和行列数（下标从0开始）
        int rowStart = operation.getRange().getRow().get(0);
        int columnStart = operation.getRange().getColumn().get(0);

        int row = rowStart;
        for (List<LSCellValue> innerList : value) {
            int column = columnStart;
            for (LSCellValue lsCellValue : innerList) {
                LSOperationRefreshCell operationRefreshCell = new LSOperationRefreshCell(operation.getType(), operation.getIndex(), lsCellValue, row, column);
                List<LSCell> presentLsCellChain = newProcessRefreshCell(lsWorkbookID, operationRefreshCell);
                lsCellsToReturn.add(presentLsCellChain);
                column++;
            }
            row++;
        }

        return lsCellsToReturn;
    }

    @Override
    public void processMv(String wbId, LSOperationMv operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setLuckysheet_select_save(operation.getValue().getRange());
                sheet.setStatus(1);
            } else {
                sheet.setStatus(0);
            }
        });
    }

    @Override
    public void processConfigHideColumn(String wbId, LSOperationConfigHideColumn operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                if (sheet.getConfig() == null) {
                    sheet.setConfig(new LSConfig());
                }
                sheet.getConfig().setColhidden(operation.getValue());
            }
        });
    }

    @Override
    public void processConfigHideRow(String wbId, LSOperationConfigHideRow operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                if (sheet.getConfig() == null) {
                    sheet.setConfig(new LSConfig());
                }
                sheet.getConfig().setRowhidden(operation.getValue());
            }
        });
    }

    @Override
    public void processBorderInfo(String wbId, LSOperationSetBorderInfo operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                if (sheet.getConfig() == null) {
                    sheet.setConfig(new LSConfig());
                }
                sheet.getConfig().setBorderInfo(operation.getValue());
            }
        });
    }

    @Override
    public void processColWidth(String wbId, LSOperationSetColWidth operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                if (sheet.getConfig() == null) {
                    sheet.setConfig(new LSConfig());
                }
                sheet.getConfig().setColumnlen(operation.getValue());
            }
        });
    }

    @Override
    public void processRowHeight(String wbId, LSOperationSetRowHeight operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                if (sheet.getConfig() == null) {
                    sheet.setConfig(new LSConfig());
                }
                sheet.getConfig().setRowlen(operation.getValue());
            }
        });
    }

    @Override
    public void processFilterClear(String wbId, LSOperationFilterClear operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setFilter(null);
                sheet.setFilter_select(null);
            }
        });
    }

    @Override
    public void processFilterRestore(String wbId, LSOperationFilterRestore operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                // TODO:有问题,一般为Map类型,但是传过来的参数是数组
                sheet.setFilter(operation.getValue().getFilter());
                sheet.setFilter_select(operation.getValue().getFilter_select());
            }
        });
    }

    @Override
    public void processCalcChain(String wbId, LSOperationCalcChain operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setCalcChain(operation.getValue());
            }
        });
    }

    @Override
    public void processCalcChainAdd(String wbId, LSOperationCalcChainAdd operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                LSFormula lsFormula = JSON.parseObject(operation.getValue(), LSFormula.class);
                switch (operation.getOp()) {
                    case "add" -> sheet.getCalcChain().add(lsFormula);
                    case "del" -> {
                        int row = sheet.getCalcChain().get(operation.getPosition()).getR();
                        int column = sheet.getCalcChain().get(operation.getPosition()).getC();
                        sheet.getCalcChain().remove(operation.getPosition());

                        // 将后端公式链中的公式结点也同时删除
                        workbookInit.getMyWorkBookByID(wbId).getCalcChains().remove(new CalcNode(row, column, operation.getIndex()));
                    }
                    case "update" ->
                            sheet.getCalcChain().set(operation.getPosition(), JSON.parseObject(operation.getValue(), LSFormula.class));
                }
            }
        });
    }

    @Override
    public void processHyperLink(String wbId, LSOperationHyperLink operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setHyperlink(operation.getValue());
            }
        });
    }

    @Override
    public void processImages(String wbId, LSOperationImages operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setImages(operation.getValue());
            }
        });
    }

    private void updateCellFormula(LSCell lsCell, Sheet poiSheet) {
        if (lsCell.getV().getF() != null && !lsCell.getV().getF().isEmpty()) {
            Cell poiCell = poiSheet.getRow(lsCell.getR()).getCell(lsCell.getC());
            lsCell.getV().setF("=" + poiCell.getCellFormula());
        }
    }

    @Override
    public void processRowOrColumnAdd(String wbId, LSOperationRowOrColumnAdd operation) {
        // 获取 Luckysheet 表格
        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(wbId);

        // 获取 Luckysheet 中对应 index 表格的 name
        // 因为 POI 表格中 sheet 的索引对应的是 Luckysheet 表格的 name
        LSSheet lsSheet = lsWorkBook.getSheets().stream().filter(sheet -> Objects.equals(sheet.getIndex(), operation.getIndex())).findFirst().orElseThrow(() -> new RuntimeException("Sheet not found"));
        String poiSheetName = lsSheet.getName();

        Workbook poiWorkbook = workbookInit.getWorkbookByGridKey(wbId);
        Sheet poiSheet = poiWorkbook.getSheet(poiSheetName);

        List<List<LSCellValue>> data = operation.getValue().getData();
        int index = operation.getValue().getIndex();
        int len = operation.getValue().getLen();

        switch (operation.getRowOrColumn()) {
            case "r" -> {
                lsSheet.setRow(lsSheet.getRow() + len);
                // 向下添加行
                if (Objects.equals(operation.getValue().getDirection(), "rightbottom")) {
                    poiSheet.shiftRows(index + 1, max(poiSheet.getLastRowNum(), index + 1), len);
                    // 更新当前行之后（不包括当前行）的所有行包含的单元格的r字段
                    lsSheet.getCelldata().forEach(cell -> {
                        if (cell.getR() > index) { // Cells that should be updated
                            cell.setR(cell.getR() + len);
                            updateCellFormula(cell, poiSheet);
                        }
                    });
                } else {// 向上添加行 lefttop
                    poiSheet.shiftRows(index, max(poiSheet.getLastRowNum(), index), len);
                    // 更新当前行之后（包括当前行）的所有行包含的单元格的r字段
                    lsSheet.getCelldata().forEach(cell -> {
                        if (cell.getR() >= index) {
                            cell.setR(cell.getR() + len);
                            updateCellFormula(cell, poiSheet);
                        }
                    });
                }
                if (data != null) {
                    // TODO: 给 POI 表格添加数据
                    for (int r = 0; r < data.size(); r++) {
                        for (int c = 0; c < data.get(r).size(); c++) {
                            if (data.get(r).get(c) != null) {
                                lsSheet.getCelldata().add(new LSCell(index + r, c, data.get(r).get(c)));
                                if (poiSheet.getRow(index + r) == null) {
                                    poiSheet.createRow(index + r);
                                }
                                CellUtility.LS2POI(poiWorkbook, poiSheet.getRow(index + r).createCell(c), data.get(r).get(c));
                            }
                        }
                    }
                }
            }
            case "c" -> {
                lsSheet.setColumn(lsSheet.getColumn() + len);
                // 向右添加列
                if (Objects.equals(operation.getValue().getDirection(), "rightbottom")) {
                    poiSheet.shiftColumns(index + 1, max(lsSheet.getColumn(), index + 1), len);
                    // 更新当前列之后（不包括当前列）的所有列包含单元格的c字段
                    lsSheet.getCelldata().forEach(cell -> {
                        if (cell.getC() > index) {
                            cell.setC(cell.getC() + len);
                            updateCellFormula(cell, poiSheet);
                        }
                    });
                } else {// 向左添加列 lefttop
                    poiSheet.shiftColumns(index, max(lsSheet.getColumn(), index), len);
                    // 更新当前列之后（包括当前列）的所有列包含单元格的c字段
                    lsSheet.getCelldata().forEach(cell -> {
                        if (cell.getC() >= index) {
                            cell.setC(cell.getC() + len);
                            updateCellFormula(cell, poiSheet);
                        }
                    });
                }
                if (data != null) {
                    // TODO: 给 POI 表格添加数据
                    for (int r = 0; r < data.size(); r++) {
                        for (int c = 0; c < data.get(r).size(); c++) {
                            if (data.get(r).get(c) != null) {
                                lsSheet.getCelldata().add(new LSCell(r, c + index, data.get(r).get(c)));
                                if (poiSheet.getRow(r) == null) {
                                    poiSheet.createRow(r);
                                }
                                CellUtility.LS2POI(poiWorkbook, poiSheet.getRow(r).createCell(c + index), data.get(r).get(c));
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void processRowOrColumnDel(String wbId, LSOperationRowOrColumnDel operation) {
        // 获取 Luckysheet 表格
        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(wbId);

        // 获取 Luckysheet 中对应 index 表格的 name
        // 因为 POI 表格中 sheet 的索引对应的是 Luckysheet 表格的 name
        LSSheet lsSheet = lsWorkBook.getSheets().stream().filter(sheet -> Objects.equals(sheet.getIndex(), operation.getIndex())).findFirst().orElseThrow(() -> new RuntimeException("Sheet not found"));
        String poiSheetName = lsSheet.getName();

        Workbook poiWorkbook = workbookInit.getWorkbookByGridKey(wbId);
        Sheet poiSheet = poiWorkbook.getSheet(poiSheetName);


        int index = operation.getValue().getIndex();
        int len = operation.getValue().getLen();
        switch (operation.getRowOrColumn()) {
            case "r" -> {
                // 删除行
                // 如果删除的行不是最后一行，将改行后的行向上移动
                // 如果删除的行是最后一行，删除行
                logger.debug(poiSheet.getLastRowNum());
                if (index + len < poiSheet.getLastRowNum()) {
                    poiSheet.shiftRows(index + len, poiSheet.getLastRowNum(), -len);
                } else {
                    for (int i = 0; i < len; i++) {
                        Row row = poiSheet.getRow(index + i);
                        if (row != null) {
                            poiSheet.removeRow(row);
                        }
                    }
                }

                // 创建列表迭代器
                ListIterator<LSCell> iterator = lsSheet.getCelldata().listIterator();
                while (iterator.hasNext()) {
                    LSCell cell = iterator.next();
                    if (cell.getR() >= index && cell.getR() < index + len) {
                        iterator.remove();// 删除选中区cell
                    } else if (cell.getR() >= index + len) {
                        // 更新选中区cell的r字段
                        cell.setR(cell.getR() - len);
                        iterator.set(cell);
                    }
                }
                lsSheet.setRow(lsSheet.getRow() - len);

                // 更新单元格公式
                for (int i = index; i < index + len; i++) {
                    for (int j = 0; j < lsSheet.getColumn(); j++) {
                        LSCell cell = lsSheet.getCellByRowColumn(i, j).getValue();
                        updateCellFormula(cell, poiSheet);
                    }
                }
            }
            case "c" -> {

                // 删除列
                // 如果删除的列不是最后一列，将该列后的列向左移动
                // 如果删除的列是最后一列，删除列
                if (index + len < poiSheet.getLastRowNum()) {
                    poiSheet.shiftColumns(index + len, lsSheet.getColumn(), -len);
                } else {
                    for (int i = 0; i < len; i++) {
                        for (Row row : poiSheet) {
                            Cell cell = row.getCell(index + i);
                            if (cell != null) {
                                row.removeCell(cell);
                            }
                        }
                    }
                }

                // 创建列表迭代器
                ListIterator<LSCell> iterator = lsSheet.getCelldata().listIterator();
                while (iterator.hasNext()) {
                    LSCell cell = iterator.next();
                    if (cell.getC() >= index && cell.getC() < index + len) {
                        iterator.remove();// 删除选中区cell
                    } else if (cell.getC() >= index + len) {
                        // 更新选中区cell的c字段
                        cell.setC(cell.getC() - len);
                        iterator.set(cell);
                    }
                }
                lsSheet.setColumn(lsSheet.getColumn() - len);

                // 更新单元格公式
                for (int i = 0; i < lsSheet.getRow(); i++) {
                    for (int j = index; j < index + len; j++) {
                        LSCell cell = lsSheet.getCellByRowColumn(i, j).getValue();
                        updateCellFormula(cell, poiSheet);
                    }
                }
            }
        }

    }

    @Override
    public void processAddSheet(String wbId, LSOperationAddSheet operation) {
        // 更新内存自定义workbook
        workbookInit.getMyWorkBookByID(wbId).getSheets().add(operation.getValue());
        processMv(wbId, new LSOperationMv("mv", operation.getValue().getIndex(), new LSOperationMv.OpDetail()));
        // 更新内存poi中workbook
        Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
        poiWorkBook.createSheet(operation.getValue().getName());
        // TODO-测试-打印poi
        //        workbookInit.printPoiWbSheetName(wbId);
    }

    @Override
    public void processDelSheet(String wbId, LSOperationDelSheet operation) {
        ListIterator<LSSheet> iterator = workbookInit.getMyWorkBookByID(wbId).getSheets().listIterator();
        while (iterator.hasNext()) {
            LSSheet sheet = iterator.next();
            if (Objects.equals(sheet.getIndex(), operation.getValue().getDeleIndex())) {
                // 缓存中保存最新版本
                if (cacheDelLSWb.get(wbId) == null) {
                    Map<String, LSSheet> sheetMap = new HashMap<>();
                    sheetMap.put(sheet.getIndex(), SerializationUtils.clone(sheet));
                    cacheDelLSWb.put(wbId, sheetMap);
                } else {
                    cacheDelLSWb.get(wbId).put(sheet.getIndex(), SerializationUtils.clone(sheet));
                }
                // 更新内存poi中workbook
                Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
                poiWorkBook.removeSheetAt(poiWorkBook.getSheetIndex(sheet.getName()));
                // 更新内存自定义workbook
                iterator.remove();
                // TODO-测试-打印poi
                //                workbookInit.printPoiWbSheetName(wbId);
            }
        }
    }

    @Override
    public void processAdjustSheet(String wbId, LSOperationAdjustSheet operation) {
        Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (operation.getValue().get(sheet.getIndex()) != null) {
                sheet.setOrder(operation.getValue().get(sheet.getIndex()));
                poiWorkBook.setSheetOrder(sheet.getName(), operation.getValue().get(sheet.getIndex()));
            }
        });
        // TODO-测试-打印poi
        //        workbookInit.printPoiWbSheetName(wbId);
    }

    @Override
    public void processRestoreDelSheet(String wbId, LSOperationRestoreDelSheet operation) {
        cacheDelLSWb.get(wbId).values().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getValue().getReIndex())) {
                // 更新内存自定义workbook
                workbookInit.getMyWorkBookByID(wbId).getSheets().add(sheet);
                // 更新内存poi中workbook
                Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
                poiWorkBook.createSheet(sheet.getName());
                poiWorkBook.setSheetOrder(sheet.getName(), sheet.getOrder());
                // TODO-测试-打印poi
                //                workbookInit.printPoiWbSheetName(wbId);
            }
        });
        // 更新缓存（从缓存中删除恢复的sheet）
        cacheDelLSWb.get(wbId).remove(operation.getValue().getReIndex());
    }

    @Override
    public void processCopySheet(String wbId, LSOperationCopySheet operation) {
        ListIterator<LSSheet> iterator = workbookInit.getMyWorkBookByID(wbId).getSheets().listIterator();
        while (iterator.hasNext()) {
            LSSheet sheet = SerializationUtils.clone(iterator.next());
            if (Objects.equals(sheet.getIndex(), operation.getValue().getCopyindex())) {
                // 更新内存自定义workbook
                sheet.setName(operation.getValue().getName());
                sheet.setIndex(operation.getIndex());
                iterator.add(sheet);
                // 更新内存poi中workbook
                Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
                poiWorkBook.createSheet(sheet.getName());
                poiWorkBook.setSheetOrder(sheet.getName(), sheet.getOrder() + 1);
                // TODO-测试-打印poi
                //                workbookInit.printPoiWbSheetName(wbId);
            }
        }
    }

    @Override
    public void processSwitchSheet(String wbId, LSOperationSwitchSheet operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getValue())) {
                sheet.setStatus(1);
            } else {
                sheet.setStatus(0);
            }
        });
    }

    @Override
    public void processAlternate(String wbId, LSOperationAlternateFormat operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setLuckysheet_alternateformat_save(operation.getValue());
            }
        });
    }

    @Override
    public void processCondition(String wbId, LSOperationConditionFormat operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setLuckysheet_conditionformat_save(operation.getValue());
            }
        });
    }

    @Override
    public void processDataVerification(String wbId, LSOperationDataVerification operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setDataVerification(operation.getValue());
            }
        });
    }

    @Override
    public void processDynamicArray(String wbId, LSOperationDynamicArray operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setDynamicArray(operation.getValue());
            }
        });
    }

    @Override
    public void processUsFilter(String wbId, LSOperationUsFilter operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setFilter(operation.getValue());
            }
        });
    }

    @Override
    public void processZoomRatio(String wbId, LSOperationZoomRatio operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setZoomRatio(operation.getValue());
            }
        });
    }

    @Override
    public void processFilterSelect(String wbId, LSOperationFilterSelect operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setFilter_select(operation.getValue());
            }
        });
    }

    @Override
    public void processFreeze(String wbId, LSOperationFreeze operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setFrozen(operation.getValue());
            }
        });
    }


    @Override
    public void processMerge(String wbId, LSOperationMerge operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setConfig(operation.getValue());
            }
        });
    }

    @Override
    public void processPivotTable(String wbId, LSOperationPivotTable operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setPivotTable(operation.getValue());
            }
        });
    }

    @Override
    public void processSheetColor(String wbId, LSOperationSetSheetColor operation) {
        workbookInit.getMyWorkBookByID(wbId).getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                sheet.setColor(operation.getValue());
            }
        });
    }

    @Override
    public void processSheetName(String wbId, LSOperationSetSheetName operation) {
//        FormulaChainManager formulaChainManager = workbookInit.getFormulaChainByID(wbId);
        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(wbId);
        lsWorkBook.getSheets().forEach(sheet -> {
            if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                // 1.先通过原来的sheet name获取poi中sheet的索引
                int poiSheetIndex = workbookInit.getWorkbookByGridKey(wbId).getSheetIndex(sheet.getName());
                // 2.通过获取的index更新对应表名称
                Workbook poiWorkBook = workbookInit.getWorkbookByGridKey(wbId);
                poiWorkBook.setSheetName(poiSheetIndex, operation.getValue());
                String oldSheetName = sheet.getName();
                String newSheetName = operation.getValue();
                sheet.setName(operation.getValue());
                // TODO-测试-打印poi
                //                workbookInit.printPoiWbSheetName(wbId);
                // 旧版公式链更新
//                formulaChainManager.updateFormulaChainNodeName(oldSheetName, newSheetName);
                // 新版公式链更新
                FormulaParsingWorkbook fpWorkbook = XSSFEvaluationWorkbook.create((XSSFWorkbook) poiWorkBook);
                lsWorkBook.getCalcChains().forEach(calcNode -> {
                    Ptg[] ptgs = FormulaParser.parse(calcNode.getFunc(), fpWorkbook, FormulaType.CELL, 0);
                    for (Ptg ptg : ptgs) {
                        String sheetName;
                        if (ptg instanceof Ref3DPtg) {
                            Ref3DPtg ref3d = (Ref3DPtg) ptg;
                            sheetName = poiWorkBook.getSheetName(ref3d.getExternSheetIndex());
                            if (oldSheetName.equals(sheetName)) {
                                ref3d.setExternSheetIndex(fpWorkbook.getExternalSheetIndex(newSheetName));
                            }
                        } else if (ptg instanceof Ref3DPxg) { // Ref3DPxg
                            Ref3DPxg ref3dpxg = (Ref3DPxg) ptg;
                            if (oldSheetName.equals(ref3dpxg.getSheetName())) {
                                ref3dpxg.setSheetName(newSheetName);
                            }
                            // 用于处理.xlsx格式的文件（即XSSF—XML Spreadsheet Format）。这是较新的Excel文件格式，基于XML，由POI的XSSF部分处理。
                            // 这是一个高级对象，提供了更友好的API来直接使用工作表名称等属性，使得操作更直观易懂。它属于公式解析的一部分，允许使用者直接通过名称来引用工作表，而不仅仅是索引。
                        } else if (ptg instanceof Area3DPxg) { // Area3DPxg
                            Area3DPxg area3dpxg = (Area3DPxg) ptg;
                            sheetName = area3dpxg.getSheetName();
                            if (oldSheetName.equals(area3dpxg.getSheetName())) {
                                area3dpxg.setSheetName(newSheetName);
                            }
                            // 用于处理.xls格式的文件（即HSSF—Horrible Spreadsheet Format）。这是较老的Excel文件格式，由POI的HSSF部分处理。
                            // 这是一个Parsed Token，用于公式解析过程中，它是一个较低级别的表示，不包括友好的工作表名称引用，而是通过工作表的外部索引来引用。
                        } else if (ptg instanceof Area3DPtg) {
                            Area3DPtg area3d = (Area3DPtg) ptg;
                            //                EvaluationWorkbook evalWorkbook = XSSFEvaluationWorkbook.create(workbook);
                            //                sheetName = evalWorkbook.getSheetName(area3d.getExternSheetIndex());
                            //                System.out.println("Area3DPtg --> sheetName = " + sheetName);
                        }
                    }
                    String updatedFormula = FormulaRenderer.toFormulaString((FormulaRenderingWorkbook) fpWorkbook, ptgs);
                    calcNode.setFunc("=" + updatedFormula);
                });
                // 内存中的两张表更新公式内容
                workbookInit.updateFormulaAfterSheetName(wbId, oldSheetName, newSheetName);
            }
        });
    }

    @Override
    public void processSheetShow(String wbId, LSOperationSheetShow operation) {
        LSWorkBook lsWorkBook = workbookInit.getMyWorkBookByID(wbId);
        // 当前sheet隐藏，激活给定sheet
        if (operation.getValue() == 1) {
            lsWorkBook.getSheets().forEach(sheet -> {
                if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                    sheet.setHide(1);
                    sheet.setStatus(0);
                } else if (Objects.equals(sheet.getIndex(), operation.getActiveIndex())) {
                    sheet.setStatus(1);
                }
            });
        }// 显示给定sheet，隐藏当前sheet
        else {
            lsWorkBook.getSheets().forEach(sheet -> {
                if (Objects.equals(sheet.getIndex(), operation.getIndex())) {
                    sheet.setHide(0);
                    sheet.setStatus(1);
                } else {
                    sheet.setStatus(0);
                }
            });
        }
    }

    @Override
    public void processWorkBookName(String wbId, LSOperationWbName operation) {
        workbookInit.getMyWorkBookByID(wbId).setTitle(operation.getValue());
        WorkBookEntity wb = new WorkBookEntity();
        LSWorkBook workBook = new LSWorkBook();
        workBook.setTitle(operation.getValue());
        workBook.setGridKey(wbId);
        wb.setId(wbId);
        wb.setWorkBook(workBook);
        workBookRepository.save(wb);
    }
}
