package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.*;

public class StyleData extends StyleBase{
    private TextRotation tr; // textRotation
    private TextDirection td;
    private HorizontalAlign ht;
    private VerticalAlign vt;
    private WrapStrategy tb;
    private PaddingData pd;
}
