package org.geely.pms_server.backend.core.model.luckysheet_operation.config;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.config.LSBorderInfoItem;

import java.util.List;

/**
 * 单元格边框
 * t:borderInfo
 */
@Data
public class LSOperationSetBorderInfo {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 包含所有单元格边框信息
     */
    @JSONField(name = "v")
    private List<LSBorderInfoItem> value;

}
