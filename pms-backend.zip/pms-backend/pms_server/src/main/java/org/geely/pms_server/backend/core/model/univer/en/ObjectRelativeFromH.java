package org.geely.pms_server.backend.core.model.univer.en;

public enum ObjectRelativeFromH {
    PAGE,
    COLUMN,
    CHARACTER,
    MARGIN,
    INSIDE_MARGIN,
    OUTSIDE_MARGIN,
    LEFT_MARGIN,
    RIGHT_MARGIN,
}
