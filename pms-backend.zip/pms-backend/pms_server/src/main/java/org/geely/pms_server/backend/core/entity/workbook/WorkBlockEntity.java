package org.geely.pms_server.backend.core.entity.workbook;


;
import org.geely.pms_server.backend.core.entity.BaseBlockEntity;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "work_sheet_block")
public class WorkBlockEntity extends BaseBlockEntity {
    private String wbId;

    @Override
    public void setBelongsId(String wbId) {
        this.wbId = wbId;
    }
}
