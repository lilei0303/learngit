package org.geely.pms_server.backend.core.entity.template;

import org.geely.pms_server.backend.core.entity.BaseSheetEntity;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "template_sheet")
public class TemplateSheetEntity extends BaseSheetEntity {
    private String templateId;

    @Override
    public void setBelongsId(String wbId) {
        this.templateId = wbId;
    }
}
