package org.geely.pms_server.backend.core.controller;

import io.minio.errors.*;
import io.minio.messages.Item;
import jakarta.annotation.Resource;
import org.geely.pms_server.backend.utils.MinioUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@RestController
public class TestMinio {
    @Resource
    MinioUtil minioUtil;

    @PostMapping("/upload")
    public String upload(MultipartFile file, String minioId) {
        return minioUtil.upload(file, minioId);
    }

    @GetMapping("/delete")
    public boolean delete(String minioId) {
        return minioUtil.deleteFile(minioId);
    }

    @GetMapping("/list")
    public List<Item> list() {
        return minioUtil.listObjects();
    }

    @GetMapping("/stat")
    public Object stat(String fileName) throws ServerException, InsufficientDataException, ErrorResponseException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException {
        System.out.println("fileName = " + fileName);
        return minioUtil.stat(fileName);
    }

}
