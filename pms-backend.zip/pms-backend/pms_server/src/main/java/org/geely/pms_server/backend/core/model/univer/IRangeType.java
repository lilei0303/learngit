package org.geely.pms_server.backend.core.model.univer;

public interface IRangeType {
}
