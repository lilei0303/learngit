package org.geely.pms_server.backend.core.model.luckysheet_model.image;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置ImageItem的border字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSBorder implements Serializable {

    /**
     * 边框宽度
     */
    private Integer width;

    /**
     * 边框半径
     */
    private Integer radius;

    /**
     * 边框类型
     */
    private String style;

    /**
     * 边框颜色
     */
    private String color;
}
