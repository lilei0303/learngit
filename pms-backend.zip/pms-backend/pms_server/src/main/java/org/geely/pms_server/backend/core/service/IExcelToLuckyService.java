package org.geely.pms_server.backend.core.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CompletableFuture;

public interface IExcelToLuckyService {
    String convertExcelToLucky(InputStream excelFile) throws IOException, ExcelConversionException;

    CompletableFuture<String> convertExcelToLuckyAsync(InputStream inputStream) throws IOException, ExcelConversionException;

    public class ExcelConversionException extends Exception {
        public ExcelConversionException(String message) {
            super(message);
        }
    }

}
