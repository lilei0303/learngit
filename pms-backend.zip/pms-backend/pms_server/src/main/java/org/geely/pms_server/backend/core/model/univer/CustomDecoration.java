package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.CustomDecorationType;

public class CustomDecoration {
    private Double startIndex;
    private Double endIndex;
    private String id;
    private CustomDecorationType type;
}
