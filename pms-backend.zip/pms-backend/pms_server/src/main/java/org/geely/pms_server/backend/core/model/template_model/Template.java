package org.geely.pms_server.backend.core.model.template_model;

import lombok.Getter;
import lombok.Setter;
import org.geely.pms_server.backend.core.model.luckysheet_model.Base;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;

import java.util.List;

@Getter
@Setter
public class Template extends Base {

    private List<Object> datasetViews;

    public Template() {
        super();
    }

    public Template(String gridKey, String title, String lang, List<LSSheet> sheets) {
        super(gridKey, title, lang, sheets);
    }
}
