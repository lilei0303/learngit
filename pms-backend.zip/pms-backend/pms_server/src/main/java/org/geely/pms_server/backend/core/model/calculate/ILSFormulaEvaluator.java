package org.geely.pms_server.backend.core.model.calculate;

import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;

public interface ILSFormulaEvaluator {

    //返回double类型计算结果
    public double LSEvaluateInDouble(String workbookID, String lsSheetIndex, LSCell lsCell) throws Exception;

    //返回LSCell类型计算结果
    public LSCell LSEvaluateInLSCell(String workbookID, String lsSheetIndex, LSCell lsCell) throws Exception;

    //具体计算过程
//    public void LSCalculate (int sheetIndex, LSCell lsCell,double cellValueInDouble);
    public void LSCalculate(String workbookID, String lsSheetIndex, LSCell lsCell, double cellValueInDouble) throws Exception;

    public boolean isFormulaValid(LSCell lsCell);//检查公式合法性
}
