package org.geely.pms_server.backend.core.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;

import java.util.List;

@Data
@AllArgsConstructor
public class LSLoadSheetDTO {
    /**
     * Sheet 名称
     */
    private String name;

    /**
     * Sheet 索引
     */
    private String index;

    /**
     * Sheet 顺序
     */
    private long order;

    /**
     * Sheet 状态
     * 0 为隐藏，1 为显示
     */
    private long status;

    /**
     * Sheet 单元格数据
     */
    private List<LSCell> celldata;
}