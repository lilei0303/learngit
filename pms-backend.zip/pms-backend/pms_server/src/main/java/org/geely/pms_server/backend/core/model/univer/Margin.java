package org.geely.pms_server.backend.core.model.univer;

public class Margin {
    private Double marginTop;
    private Double marginBottom;
    private Double marginRight;
    private Double marginLeft;
}
