package org.geely.pms_server.backend.core.model.univer.en;

public enum PositionedObjectLayoutType {
    INLINE,
    WRAP_NONE,
    WRAP_POLYGON,
    WRAP_SQUARE,
    WRAP_THROUGH,
    WRAP_TIGHT,
    WRAP_TOP_AND_BOTTOM,
}
