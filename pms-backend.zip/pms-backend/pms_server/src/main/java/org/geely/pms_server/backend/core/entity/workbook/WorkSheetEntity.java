package org.geely.pms_server.backend.core.entity.workbook;

import org.geely.pms_server.backend.core.entity.BaseSheetEntity;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "work_sheet")
public class WorkSheetEntity extends BaseSheetEntity {
    private String wbId;

    @Override
    public void setBelongsId(String wbId) {
        this.wbId = wbId;
    }
}
