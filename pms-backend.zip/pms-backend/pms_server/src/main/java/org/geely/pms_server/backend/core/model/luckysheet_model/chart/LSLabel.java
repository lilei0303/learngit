package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSLabel implements Serializable {

    private Integer fontSize;

    private String color;

    private String fontFamily;

    private List<Object>fontGroup;

    private Integer cusFontSize;
}
