package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.NumberUnitType;

public class NumberUnit {
    private Double v;
    private NumberUnitType u;
}
