package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.AlignTypeV;
import org.geely.pms_server.backend.core.model.univer.en.ObjectRelativeFromV;

public class ObjectPositionV {
    private ObjectRelativeFromV relativeFrom;
    private AlignTypeV align;
    private Double posOffset;
    private Double percent;
}
