package org.geely.pms_server.backend.core.dto.import_workbook;

import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;

import java.util.List;

@Data
public class ImportWorkbookRequestDTO {
    private String title;
    private String lang;
    private List<LSSheet> sheets;
}
