package org.geely.pms_server.backend.core.repository.template;

import org.geely.pms_server.backend.core.entity.template.TemplateBlockEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TemplateBlockRepository extends MongoRepository<TemplateBlockEntity, String> {

    /**
     * 通过sheetId获取所有块
     *
     * @param sheetId
     * @return
     */
    List<TemplateBlockEntity> findAllBySheetId(String sheetId);

    /**
     * 更新整个工作簿时，调用下列方法删除原数据
     *
     * @param templateId
     * @param sheetId
     */
    void deleteAllByTemplateIdAndSheetId(String templateId, String sheetId);

    /**
     * 根据templateId删除
     *
     * @param templateId
     */
    void deleteAllByTemplateId(String templateId);
}
