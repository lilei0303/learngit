package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.*;

public class DocumentRenderConfig {
    private VerticalAlign verticalAlign;
    private Double centerAngle;
    private Double vertexAngle;
    private HorizontalAlign horizontalAlign;
    private BooleanNumber isRotateNonEastAsian;
    private ColorStyle background;
    private WrapStrategy wrapStrategy;
    private CellValueType cellValueType;
    private BooleanNumber isRenderStyle;
}
