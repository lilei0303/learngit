package org.geely.pms_server.backend.core.model.luckysheet_model.pivottable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 该类详细配置PivotTable类的values字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSValues {

    private Integer index;

    private String name;

    private String fullname;

    private Integer nameindex;
}
