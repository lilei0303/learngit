package org.geely.pms_server.backend.core.model.luckysheet_operation.filter;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.filter.LSFilter;
import org.geely.pms_server.backend.core.model.luckysheet_model.filterselect.LSFilterSelect;

import java.util.Map;

/**
 * 恢复筛选
 * t:fsr
 */
@Data
public class LSOperationFilterRestore {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 恢复筛选
     */
    @JSONField(name = "v")
    private OpFilter value;

    @Data
    public static class OpFilter {
        private Map<String, LSFilter> filter;
        private LSFilterSelect filter_select;
    }
}
