package org.geely.pms_server.backend.core.entity.template;


import org.geely.pms_server.backend.core.entity.BaseBlockEntity;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "template_sheet_block")
public class TemplateBlockEntity extends BaseBlockEntity {

    /**
     * 关联模板Id
     */
    private String templateId;

    @Override
    public void setBelongsId(String wbId) {
        this.templateId = wbId;
    }
}
