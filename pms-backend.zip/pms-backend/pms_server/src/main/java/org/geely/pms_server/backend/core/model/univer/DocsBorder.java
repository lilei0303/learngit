package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.DashStyleType;

public class DocsBorder {
    ColorStyle color;
    Double width;
    DashStyleType dashStyle;
}
