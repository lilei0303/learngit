package org.geely.pms_server.backend.core.entity.template;

import lombok.Getter;
import org.geely.pms_server.backend.core.entity.BaseEntity;
import org.geely.pms_server.backend.core.model.template_model.Template;
import org.springframework.data.mongodb.core.mapping.Document;

@Getter
@Document(collection = "template")
public class TemplateEntity extends BaseEntity {

    /**
     * 关联模板
     */
    private Template template;

    public void setTemplate(Template template) {
        this.template = template;
    }

}
