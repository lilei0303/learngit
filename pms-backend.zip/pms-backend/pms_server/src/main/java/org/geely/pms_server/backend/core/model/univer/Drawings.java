package org.geely.pms_server.backend.core.model.univer;

import java.util.Map;

public class Drawings {
    private Map<String, DocDrawingBase> drawings;
}
