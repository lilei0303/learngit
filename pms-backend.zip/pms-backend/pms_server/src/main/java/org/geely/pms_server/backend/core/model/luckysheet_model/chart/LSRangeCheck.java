package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置ChartOptions类的rangeColCheck、rangeRolCheck字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSRangeCheck implements Serializable {

    private Boolean exits;

    private List<Integer> range;
}
