package org.geely.pms_server;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.geely.pms_server.backend.BackendServerApplication;

public class ServerBoot {
    /*
     * 后端服务总入口
     * 处理pms-ui前端请求的服务在backend.BackendServerApplication //Spring boot
     */
    static final Logger logger = LogManager.getLogger(ServerBoot.class);
    public static String configFilePath = "serverConfig.json";

    public static void main(String[] args) {
        // can change this config to test

        if (args.length > 0) {
            configFilePath = args[0];
        }
        ServerConfig serverConfig = ServerConfig.loadFromConfigFile(configFilePath);
        if (serverConfig != null) {
            if (serverConfig.serverVersion.equals("dev")) {
                // for test
            }
        } else {
            logger.error("Load config file failed!");
            System.exit(-1);
        }

        // start backend server(spring boot) for pms_ui
        new Thread(() -> BackendServerApplication.main(args)).start();
        logger.info("Start backend server at port " + serverConfig.backendServerPort);

    }
}
