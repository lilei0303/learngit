package org.geely.pms_server.backend.core.entity;


import lombok.Data;
import org.springframework.data.annotation.Id;

import java.io.Serializable;

/**
 * 定义template、workbook实体的基类
 */
@Data
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识唯一Id
     */
    @Id
    private String id;
}
