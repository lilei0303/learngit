package org.geely.pms_server.backend.core.service.impl;

import cn.hutool.core.util.IdUtil;
import org.geely.pms_server.backend.core.dto.manage_workbook.TemplateInfo;
import org.geely.pms_server.backend.core.entity.template.TemplateBlockEntity;
import org.geely.pms_server.backend.core.entity.template.TemplateEntity;
import org.geely.pms_server.backend.core.entity.template.TemplateSheetEntity;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.model.template_model.Template;
import org.geely.pms_server.backend.core.service.IDbTemplateProcessor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TemplateDbProcessor extends PublicDbProcessor implements IDbTemplateProcessor {

    @Override
    public Template loadTemplate(String templateId) {
        Optional<TemplateEntity> Otp = templateRepository.findById(templateId);
        Template template = new Template();
        if (Otp.isPresent()) {
            template = Otp.get().getTemplate();
        }
        List<TemplateSheetEntity> tsList = templateSheetRepository.findAllByTemplateId(templateId);
        //使用Collections集合工具类进行排序
        Collections.sort(tsList);
        //获取所有sheet
        template.setSheets(getSheets(tsList, templateBlockRepository));
        return template;
    }

    @Override
    public String saveTemplate(Template template) {
        List<LSSheet> sheets = template.getSheets();
        //保存template实体
        template.setSheets(null);
        TemplateEntity tp = new TemplateEntity();
        String templateId = "Template_" + IdUtil.simpleUUID();
        template.setGridKey(templateId);
        tp.setId(templateId);
        tp.setTemplate(template);
        templateRepository.save(tp);

        //遍历sheets
        sheets.forEach(sheet -> {
            TemplateBlockEntity templateBlock = new TemplateBlockEntity();
            sheet.setIndex("Sheet_" + IdUtil.simpleUUID());
            //获取数据
//            List<LSCell> cellData = sheet.getCelldata();
            //获取第一块数据
//            List<LSCell> firstBlockData = getFirstBlockData(cellData, 0, 50);
            //存储第一块数据
//            saveCellData(templateBlock, firstBlockData, template.getGridKey(), sheet, templateBlockRepository);
            //存储剩余数据
            saveSheetData(templateBlock, sheet, template.getGridKey(), templateBlockRepository);
            //保存sheet实体
            TemplateSheetEntity ts = new TemplateSheetEntity();
            ts.setId(sheet.getIndex());
            ts.setOrder(sheet.getOrder());
            ts.setBelongsId(template.getGridKey());
            templateSheetRepository.save(ts);
        });
        return templateId;
    }

    @Override
    public void deleteTemplate(String templateId) {
        templateBlockRepository.deleteAllByTemplateId(templateId);
        templateSheetRepository.deleteAllByTemplateId(templateId);
        templateRepository.deleteById(templateId);
    }

    @Override
    public List<TemplateInfo> getAllTemplateInfo() {
        return templateRepository.findAll().stream()
                .map(entity -> new TemplateInfo(entity.getTemplate().getTitle(), entity.getId()))
                .collect(Collectors.toList());
    }

    @Override
    public Boolean templateExists(String templateId) {
        return templateRepository.existsById(templateId);
    }

}
