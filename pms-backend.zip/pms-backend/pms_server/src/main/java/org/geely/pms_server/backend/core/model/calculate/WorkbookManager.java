package org.geely.pms_server.backend.core.model.calculate;

import cn.hutool.core.lang.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.formula.EvaluationWorkbook;
import org.apache.poi.ss.formula.FormulaParseException;
import org.apache.poi.ss.formula.eval.NotImplementedException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.geely.pms_server.backend.core.model.calcChain.CalcNode;
import org.geely.pms_server.backend.core.model.calcChain.ReferencingCell;
import org.geely.pms_server.backend.core.model.formulaChain.FormulaChainManager;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.utils.CellUtility;

import java.util.HashSet;

public class WorkbookManager {

    static final Logger logger = LogManager.getLogger(WorkbookManager.class);

    public WorkbookManager() {
        // _workbook = new XSSFWorkbook();
    }

    // 判断当前lsCell中的值是否为数字值
    public static boolean isNumeric(String lsCellValue) {
        boolean isNumeric = lsCellValue.matches("^-?\\d+(\\.\\d+)?$");
        return isNumeric;
    }

    // public Workbook getWorkbook(LSWorkBook lsWorkbook) {
    public Pair<Workbook, FormulaChainManager> getWorkbookAndFormulaChain(LSWorkBook lsWorkbook) {
        FormulaChainManager formulaChainManager = new FormulaChainManager(lsWorkbook.getGridKey());

        Workbook workbook = new XSSFWorkbook();
        EvaluationWorkbook evalWorkbook = XSSFEvaluationWorkbook.create((XSSFWorkbook) workbook);

        // 对传进来的lsWorkbook中的所有sheetData进行遍历
        for (LSSheet lsSheet : lsWorkbook.getSheets()) {
            Sheet sheet = workbook.createSheet(lsSheet.getName()); // 根据lsSheet工作表中的名称创建一个空的sheet,索引默认从0开始
            int sheetOrder = workbook.getSheetIndex(sheet.getSheetName());// 根据工作表的name来获取当前sheet的索引
            String sheetIndex = lsSheet.getIndex();

            // 对于拿到的每一个sheet，对其中的所有cellData进行遍历，将lsWorkbook中所有lsSheet的所有lsCell中的值全部赋给sheet中的cell
            for (LSCell lscell : lsSheet.getCelldata()) {
                // 在初始遍历LSSheet时，为其中的每一个LSCell的sheetIndex属性赋值
                lscell.setSheetIndex(sheetIndex);
                Row row = sheet.getRow(lscell.getR());
                if (row == null) {
                    row = sheet.createRow(lscell.getR());
                }
                Cell cell = row.getCell(lscell.getC());
                if (cell == null) {
                    cell = row.createCell(lscell.getC());
                }
                // 如果当前lsCell是公式类型
                if (lscell.getV().getF() != null
                        && (lscell.getV().getM() != null && !lscell.getV().getM().equals("#NAME?"))) {
                    try {
                        // 将lsCell中的公式值赋给cell中的cellFormula(将公式前的等号=去除)
                        cell.setCellFormula(lscell.getV().getF().substring(1));

                        // 将通过公式计算得到的结果直接赋给 cellValue
                        CellType cellType = workbook.getCreationHelper().createFormulaEvaluator()
                                .evaluateFormulaCell(cell);

                        formulaChainManager.addNewLatterDependencies(cell, lscell.getV().getBackendFunction(),
                                sheetIndex, evalWorkbook, lsSheet.getName(), lsSheet.getOrder());
                    } catch (NotImplementedException | FormulaParseException | IllegalStateException |
                             StringIndexOutOfBoundsException e) {
                        cell.setCellFormula(null);
                        logger.debug("当前单元格公式不合法！  -->  row:" + lscell.getR() + " column:" + lscell.getC() + " formula:"
                                + lscell.getV().getF());
                    }
                } else {
                    String lsCellValue = lscell.getV().getV();
                    if (lsCellValue != null) {
                        // 如果当前lsCell中的值是数字
                        if (isNumeric(lsCellValue)) {
                            // 将lsCell中的字符串类型值转成double类型存储在cell中方便计算
                            double doubleValue = Double.parseDouble(lscell.getV().getV());
                            cell.setCellValue(doubleValue);// 将lsCell中的数字值赋给cell中的cellValue
                        } else {
                            // 否则直接将lsCell里的字符串内容传给cell
                            cell.setCellValue(lsCellValue);
                        }
                    }
                }
            }
        }

        return new Pair<>(workbook, formulaChainManager);
    }

    public Workbook getPoiWorkBook(LSWorkBook lsWorkBook) {
        Workbook workbook = new XSSFWorkbook();

        // 对传进来的lsWorkbook中的所有sheetData进行遍历
        for (LSSheet lsSheet : lsWorkBook.getSheets()) {
            Sheet sheet = workbook.createSheet(lsSheet.getName()); // 根据lsSheet工作表中的名称创建一个空的sheet,索引默认从0开始
            String sheetIndex = lsSheet.getIndex();

            // 对于拿到的每一个sheet，对其中的所有cellData进行遍历，将lsWorkbook中所有lsSheet的所有lsCell中的值全部赋给sheet中的cell
            for (LSCell lscell : lsSheet.getCelldata()) {
                // 在初始遍历LSSheet时，为其中的每一个LSCell的sheetIndex属性赋值
                lscell.setSheetIndex(sheetIndex);
                Row row = sheet.getRow(lscell.getR());
                if (row == null) {
                    row = sheet.createRow(lscell.getR());
                }
                Cell cell = row.getCell(lscell.getC());
                if (cell == null) {
                    cell = row.createCell(lscell.getC());
                }
                // 如果当前lsCell是公式类型
                // if (lscell.getV().getF() != null && (lscell.getV().getM() != null &&
                // !lscell.getV().getM().equals("#NAME?"))) {
                if (lscell.getV().getF() != null && (lscell.getV().getV() != null
                        && (lscell.getV().getM() == null || !lscell.getV().getM().equals("#NAME?")))) {
                    try {
                        // 将lsCell中的公式值赋给cell中的cellFormula(将公式前的等号=去除)
                        cell.setCellFormula(lscell.getV().getF().substring(1));

                        // 将通过公式计算得到的结果直接赋给 cellValue
                        // try {
                        //     CellType cellType =
                        //             workbook.getCreationHelper().createFormulaEvaluator().evaluateFormulaCell(cell);
                        // } catch (IllegalArgumentException e) {
                        //     logger.debug("当前单元格公式涉及其它Sheet单元格");
                        //     cell.setCellValue(lscell.getV().getV());
                        // }

                        // 向公式链中添加结点
                        CalcNode calcNode = new CalcNode(lscell.getR(), lscell.getC(), sheetIndex,
                                lscell.getV().getF());
                        EvaluationWorkbook evalWorkbook = XSSFEvaluationWorkbook.create((XSSFWorkbook) workbook);
                        // 设置公式链结点的referencingCells属性
                        HashSet<ReferencingCell> referencingCells = CellUtility.extractReferencingCellsInFormula(lscell.getV().getF().substring(1), evalWorkbook, lsSheet.getName(), lsSheet.getOrder());
                        calcNode.setReferencingCells(referencingCells);
                        String cellName = lsSheet.getName() + "!"
                                + new CellReference(lscell.getR(), lscell.getC()).formatAsString();
                        calcNode.setCellName(cellName);
                        calcNode.setBackendFormula(lscell.getV().getBackendFunction());
                        lsWorkBook.getCalcChains().add(calcNode);
                    } catch (NotImplementedException | FormulaParseException | IllegalStateException |
                             StringIndexOutOfBoundsException e) {
                        cell.setCellFormula(null);
                        logger.debug("当前单元格公式不合法！  -->  row:" + lscell.getR() + " column:" + lscell.getC() + " formula:"
                                + lscell.getV().getF());
                    }
                } else {
                    String lsCellValue = lscell.getV().getV();
                    if (lsCellValue != null) {
                        // 如果当前lsCell中的值是数字
                        if (isNumeric(lsCellValue)) {
                            // 将lsCell中的字符串类型值转成double类型存储在cell中方便计算
                            double doubleValue = Double.parseDouble(lscell.getV().getV());
                            cell.setCellValue(doubleValue);// 将lsCell中的数字值赋给cell中的cellValue
                        } else {
                            // 否则直接将lsCell里的字符串内容传给cell
                            cell.setCellValue(lsCellValue);
                        }
                    }
                }
            }
        }
        return workbook;
    }
}
