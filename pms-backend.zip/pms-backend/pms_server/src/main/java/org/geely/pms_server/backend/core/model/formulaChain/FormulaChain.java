package org.geely.pms_server.backend.core.model.formulaChain;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
public class FormulaChain extends HashMap<FormulaNode, HashSet<FormulaNode>> {
    //公式链上所有结点，不包含依赖关系
    //公式链中出现的结点以及在公式链中出现的次数，当次数为0时表示不存在于公式链当中
    private FormulaNodeMap formulaNodeMap = new FormulaNodeMap();

    public FormulaNode getFormulaNode(String cellNodeName) {
        for (FormulaNode formulaNode : formulaNodeMap.keySet()) {
            //如果当前结点已经存在于公式链当中
//            if (formulaNode.getCellNodeName().equals(cellNodeName) && formulaNodeMap.get(cellNodeName) > 0) {
            if (formulaNode.getCellNodeName().equals(cellNodeName)) {
                return formulaNode;
            }
        }
        return null;
    }

    @Override
    public boolean containsKey(Object key) {
        if (key instanceof String tempName) {
            for (FormulaNode node : this.keySet()) {
                if (node.getCellNodeName().equals(tempName)) {
                    return true;
                }
            }
            return false;
        }
        return super.containsKey(key);
    }

    @Override
    public HashSet<FormulaNode> get(Object key) {
        if (key instanceof String tempName) {
            for (Map.Entry<FormulaNode, HashSet<FormulaNode>> entry : this.entrySet()) {
                FormulaNode node = entry.getKey();
                if (node.getCellNodeName().equals(tempName)) {
                    return entry.getValue();
                }
            }
            return null;
        }
        return super.get(key);
    }

    public FormulaNode getKey(String cellNodeName) {
        for (FormulaNode node : this.keySet()) {
            if (node.getCellNodeName().equals(cellNodeName)) {
                return node;
            }
        }
        return null;
    }

    public boolean getPresentNodeIsBackendCalculate(String cellNodeName) {
//        System.out.println("getKey(cellNodeName):" + getKey(cellNodeName) + " getFormulaNode(cellNodeName).is_isBackendCalculate():" + getFormulaNode(cellNodeName).is_isBackendCalculate());
        return getKey(cellNodeName) != null && getFormulaNode(cellNodeName).is_isBackendCalculate();
    }

    // 重写remove方法
    public boolean removeByCellNodeName(String cellNodeName) {
        // 遍历所有键
        for (FormulaNode key : this.keySet()) {
            // 检查cellNodeName是否匹配
            if (key.getCellNodeName().equals(cellNodeName)) {
                // 如果找到匹配的cellNodeName, 使用原生的remove方法删除
                this.remove(key);
                return true; // 返回true表示成功删除
            }
        }
        return false; // 如果遍历结束没有找到匹配的cellNodeName, 返回false
    }
}