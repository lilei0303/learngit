package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BorderStyleTypes;

public class BorderStyleData {
    private BorderStyleTypes s;
    private ColorStyle cl;
}
