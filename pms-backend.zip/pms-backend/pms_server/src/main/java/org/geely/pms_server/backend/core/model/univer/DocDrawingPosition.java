package org.geely.pms_server.backend.core.model.univer;

public class DocDrawingPosition {
    private Size size;
    private ObjectPositionH positionH;
    private ObjectPositionV positionV;
    private double angle;
}
