package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.*;

import java.util.List;

public class SectionBreakBase {
    private Double charSpace; // charSpace
    private Double linePitch; // linePitch
    private GridType gridType; // gridType

    private List<SectionColumnProperties> columnProperties; // columnProperties 17.6.4 cols (Column Definitions)
    private ColumnSeparatorType columnSeparatorType; // ColumnSeparatorType
    private TextDirection contentDirection; // contentDirection
    private SectionType sectionType; // sectionType 17.6.22 type (Section Type)
    private SectionType sectionTypeNext; // sectionType
    private TextDirectionType textDirection; // tex
}
