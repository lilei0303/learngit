package org.geely.pms_server.backend.core.model.univer.en;

public enum BooleanNumber {
    TRUE(1),
    FALSE(0);
    private final int value;
    BooleanNumber(int value) {
        this.value = value;
    }
    public int getValue() {
        return value;
    }

}
