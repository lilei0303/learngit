package org.geely.pms_server.backend.core.model.luckysheet_operation.filter;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 清除筛选
 * t:fsc
 */
@Data
public class LSOperationFilterClear {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 值为null
     */
    @JSONField(name = "v")
    private Object value;
}
