package org.geely.pms_server.backend.core.model.univer;

public class Freeze {
    private Double xSplit;
    private Double ySplit;
    private Double startRow;
    private Double startColumn;
}
