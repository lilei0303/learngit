package org.geely.pms_server.backend.core.model.univer.en;

public enum DashStyleType {
    DASH_STYLE_UNSPECIFIED, // Unspecified dash style.
    SOLID, // Solid line. Corresponds to ECMA-376 ST_PresetLineDashVal value 'solid'. This is the default dash style.
    DOT, // Dotted line. Corresponds to ECMA-376 ST_PresetLineDashVal value 'dot'.
    DASH, // Dashed line. Corresponds to ECMA-376 ST_PresetLineDashVal value 'dash'.
}
