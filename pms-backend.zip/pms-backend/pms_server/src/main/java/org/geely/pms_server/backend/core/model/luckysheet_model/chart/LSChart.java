package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置LSSheet类的chart字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSChart implements Serializable {

    private String chart_id;

    private Integer width;

    private Integer height;

    private Integer left;

    private Integer top;

    private String sheetIndex;

    private Boolean needRangeShow ;

    private LSChartOptions chartOptions;

    private Boolean isShow;
}
