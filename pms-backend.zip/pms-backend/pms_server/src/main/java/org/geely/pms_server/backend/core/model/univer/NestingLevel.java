package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BulletAlignment;

public class NestingLevel {
    private BulletAlignment bulletAlignment; // ordered list support

    private String glyphFormat; // The glyph format with placeholders %[nestingLevel]
    private TextStyle textStyle;
    private int startNumber;

    private Object glyphType; // Union field for glyphType and glyphSymbol
    private String glyphSymbol;
}
