package org.geely.pms_server.backend.core.model.luckysheet_model.image;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 作用：插入表格中图片信息，包含图片地址、宽高、位置、裁剪等信息
 * 该类详细配置LSSheet类的image字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSImageItem implements Serializable {

    /**
     * 1移动并调整单元格大小 2移动并且不调整单元格的大小 3不要移动单元格并调整其大小
     */
    private String type;

    /**
     * 图片url
     */
    private String src;

    /**
     * 所在单元格行
     */
    private Integer row;

    /**
     * 所在单元格列
     */
    private Integer column;

    /**
     * 图片原始宽度
     */
    private Integer originWidth;

    /**
     * 图片原始高度
     */
    private Integer originHeight;

    /**
     * 图片原始配置
     */
    @JsonProperty(value = "default")
    private LSDefault default_;

    /**
     * 图片裁剪后配置
     */
    private LSCrop crop;

    /**
     * 固定位置
     */
    private Boolean isFixedPos;

    /**
     * 固定位置 左位移
     */
    private Integer fixedLeft;

    /**
     * 固定位置 右位移
     */
    private Integer fixedTop;

    /**
     * 图片边框配置
     */
    private LSBorder border;

}
