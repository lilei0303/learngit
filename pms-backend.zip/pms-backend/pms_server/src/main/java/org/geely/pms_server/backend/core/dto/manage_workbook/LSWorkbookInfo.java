package org.geely.pms_server.backend.core.dto.manage_workbook;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@AllArgsConstructor
public class LSWorkbookInfo {
    private String title;
    private String gridKey;
    private Date lastUpdateTime;
}
