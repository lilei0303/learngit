package org.geely.pms_server.backend.core.model.univer;

import java.util.Map;

public class Lists {
    private Map<String, ListData> listData;
}
