package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

public class ColumnHeader {
    private Double height;
    private BooleanNumber hidden;
}
