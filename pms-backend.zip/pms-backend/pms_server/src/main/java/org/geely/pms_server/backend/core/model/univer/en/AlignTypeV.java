package org.geely.pms_server.backend.core.model.univer.en;

public enum AlignTypeV {
    BOTTOM,
    CENTER,
    INSIDE,
    OUTSIDE,
    TOP,
}
