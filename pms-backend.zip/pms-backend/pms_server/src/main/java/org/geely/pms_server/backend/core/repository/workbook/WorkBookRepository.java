package org.geely.pms_server.backend.core.repository.workbook;


import org.geely.pms_server.backend.core.entity.workbook.WorkBookEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface WorkBookRepository extends MongoRepository<WorkBookEntity, String> {
    boolean existsById(String wbId);
}
