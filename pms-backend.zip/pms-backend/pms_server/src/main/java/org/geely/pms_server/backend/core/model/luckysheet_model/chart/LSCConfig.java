package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCConfig implements Serializable {

    private String color;

    private String fontFamily;

    private LSGrid grid;
}
