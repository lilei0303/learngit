package org.geely.pms_server.backend.core.model.univer;

public class TextRun {
    private Double st;
    private Double ed;
    private String sId;
    private TextStyle ts;
}
