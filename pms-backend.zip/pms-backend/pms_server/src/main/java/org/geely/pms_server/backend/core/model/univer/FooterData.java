package org.geely.pms_server.backend.core.model.univer;

public class FooterData {
    private String footerId;
    private DocumentBody body;
}
