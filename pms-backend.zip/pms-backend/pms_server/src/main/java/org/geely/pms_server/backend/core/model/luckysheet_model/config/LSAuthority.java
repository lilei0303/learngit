package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 当前工作表的权限配置
 * 该类详细配置Config类的authority字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSAuthority implements Serializable {
    /**
     * 选定锁定单元格
     */
    private Integer selectLockedCells;

    /**
     * 选定解除锁定的单元格
     */
    private Integer selectunLockedCells;

    /**
     * 设置单元格格式
     */
    private Integer formatCells;

    /**
     * 设置列格式
     */
    private Integer formatColumns;

    /**
     * 设置行格式
     */
    private Integer formatRows;

    /**
     * 插入列
     */
    private Integer insertColumns;

    /**
     * 插入行
     */
    private Integer insertRows;

    /**
     * 插入超链接
     */
    private Integer insertHyperlinks;

    /**
     * 删除列
     */
    private Integer deleteColumns;

    /**
     * 删除行
     */
    private Integer deleteRows;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 使用自动筛选
     */
    private Integer filter;

    /**
     * 使用数据透视表和报表
     */
    private Integer usePivotTablereports;

    /**
     * 编辑对象
     */
    private Integer editObjects;

    /**
     * 编辑方案
     */
    private Integer editScenarios;

    /**
     * 如果为1或true，则该工作表受到保护；如果为0或false，则该工作表不受保护。
     */
    private Integer sheet;

    /**
     * 弹窗提示的文字
     */
    private String hintText;

    /**
     * 加密方案：MD2,MD4,MD5,RIPEMD-128,RIPEMD-160,SHA-1,SHA-256,SHA-384,SHA-512,WHIRLPOOL
     */
    private String algorithmName;

    /**
     * 密码解密的盐参数，为一个自己定的随机数值
     */
    private String saltValue;


    private List<LSAllowRange> allowRangeList;
}
