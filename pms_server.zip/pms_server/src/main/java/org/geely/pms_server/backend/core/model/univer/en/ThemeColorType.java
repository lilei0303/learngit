package org.geely.pms_server.backend.core.model.univer.en;

import lombok.Getter;

@Getter
public enum ThemeColorType {
    // TEXT
    DARK1(0),
    // BACKGROUND
    LIGHT1(1),
    DARK2(2),
    LIGHT2(3),
    ACCENT1(4),
    ACCENT2(5),
    ACCENT3(6),
    ACCENT4(7),
    ACCENT5(8),
    ACCENT6(9),
    // LINK
    HYPERLINK(10),
    FOLLOWED_HYPERLINK(11);

    private final int value;

    ThemeColorType(int value) {
        this.value = value;
    }

}
