package org.geely.pms_server.backend.core.repository.template;


import org.geely.pms_server.backend.core.entity.template.TemplateSheetEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface TemplateSheetRepository extends MongoRepository<TemplateSheetEntity, String> {
    /**
     * 通过templateId返回sheet实体
     *
     * @param templateId
     * @return
     */
    List<TemplateSheetEntity> findAllByTemplateId(String templateId);

    /**
     * 根据templateId删除
     *
     * @param templateId
     */
    void deleteAllByTemplateId(String templateId);
}
