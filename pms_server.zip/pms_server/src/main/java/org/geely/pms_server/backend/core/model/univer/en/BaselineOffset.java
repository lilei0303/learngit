package org.geely.pms_server.backend.core.model.univer.en;

import lombok.Getter;

@Getter
public enum BaselineOffset {
    NORMAL(1),
    SUBSCRIPT(2),
    SUPERSCRIPT(3);

    private final int value;

    BaselineOffset(int value) {
        this.value = value;
    }

}
