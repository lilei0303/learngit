package org.geely.pms_server.backend.core.model.luckysheet_model.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Map;

/**
 * 该类详细配置LSSheet类中的filter字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSFilter implements Serializable {

    /**
     * caljs用来设置按条件筛选的类型和对应的值，设置生效后，会计算隐藏行信息存储在rowhidden中。
     * 以下是全部的可设置的类型，其中value1和value2就是用户自己填的文本信息
     */
    private LSCalJs caljs;

    /**
     * 是存储的隐藏行信息，但是如果没有设置caljs按条件筛选，则表明是设置了按颜色筛选（如果行之间有颜色区分的话）和按值进行筛选。
     * 所以可以看出，caljs的优先级大于rowhidden
     */
    private Map<String, Integer> rowhidden;

    /**
     * 表示是否开启配置，这是一个内部标识，直接设置true即可
     */
    private Boolean optionstate;

    /**
     * 表示当前设置的列顺序，从1开始计数，和filter[key]的key值形成对应，结果是key+1
     */
    private Integer cindex;

    /**
     * str是起始行
     * 四个数字代表整个筛选范围，与filter_select的内容保持一致即可
     */
    private Integer str;

    /**
     * edr是结束行
     */
    private Integer edr;

    /**
     * stc是起始列
     */
    private Integer stc;

    /**
     * edc是结束列
     */
    private Integer edc;
}
