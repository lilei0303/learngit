package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSSubTitle implements Serializable {

    private Boolean show;

    private String text;

    private LSLabel label;

    private LSDistance distance;
}
