package org.geely.pms_server.backend.core.model.univer;

public class Size {
    private Double height;
    private Double width;
}
