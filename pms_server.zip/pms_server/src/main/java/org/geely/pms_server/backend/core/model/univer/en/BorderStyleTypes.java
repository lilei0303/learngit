package org.geely.pms_server.backend.core.model.univer.en;

public enum BorderStyleTypes {
    NONE,
    THIN,
    HAIR,
    DOTTED,
    DASHED,
    DASH_DOT,
    DASH_DOT_DOT,
    DOUBLE,
    MEDIUM,
    MEDIUM_DASHED,
    MEDIUM_DASH_DOT,
    MEDIUM_DASH_DOT_DOT,
    SLANT_DASH_DOT,
    THICK
}
