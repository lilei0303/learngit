package org.geely.pms_server.backend.core.repository.univer;

import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.entity.univer.UniverWorkbook;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UniverDaoImpl {
    @Resource
    UniverWorkbookRepository uWbRepo;

    /**
     * @param minioId
     * @param size
     * @param name
     */
    public void save(String minioId, String size, String name, String minioName) {
        UniverWorkbook uWb = uWbRepo.findByMinioId(minioId);
        if (uWb == null) {
            UniverWorkbook workbook = new UniverWorkbook();
            workbook.setMinioId(minioId);
            workbook.setSize(size);
            workbook.setName(name);
            workbook.setMinioName(minioName);
            workbook.setCreateTime(LocalDateTime.now());
            uWbRepo.save(workbook);
        } else {
            uWb.setMinioId(minioId);
            uWb.setSize(size);
            uWb.setName(name);
            uWb.setMinioName(minioName);
            uWb.setLastModifiedTime(LocalDateTime.now());
            uWbRepo.save(uWb);
        }
    }

    /**
     * @param minioId
     */
    public void deleteByMinioId(String minioId) {
        uWbRepo.deleteByMinioId(minioId);
    }

    /**
     * @param minioId
     * @return
     */
    public UniverWorkbook findByMinioId(String minioId) {
        return uWbRepo.findByMinioId(minioId);
    }

    public List<UniverWorkbook> list() {
        return uWbRepo.findAll();
    }
}
