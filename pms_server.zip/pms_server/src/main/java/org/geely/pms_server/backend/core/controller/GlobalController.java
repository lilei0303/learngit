package org.geely.pms_server.backend.core.controller;

import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson2.JSON;
import jakarta.annotation.Resource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.geely.pms_server.backend.core.dto.BackendFormulaCalcRequestDTO;
import org.geely.pms_server.backend.core.dto.ResponseWrapper;
import org.geely.pms_server.backend.core.dto.import_workbook.ImportWorkbookRequestDTO;
import org.geely.pms_server.backend.core.dto.import_workbook.ImportWorkbookResponseDTO;
import org.geely.pms_server.backend.core.model.LoadURLRequestParam;
import org.geely.pms_server.backend.core.model.calculate.WorkbookInit;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.service.IDbProcessor;
import org.geely.pms_server.backend.core.service.IOperationProcessor;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * web-excel数据存取主要接口
 *
 * @RestController
 * @RequestMapping(value = "/backend/global")
 */
@RestController
@RequestMapping(value = "/backend/global")
@CrossOrigin(origins = "*", methods = RequestMethod.POST)
public class GlobalController {

    static final Logger logger = LogManager.getLogger(GlobalController.class);

    @Resource
    IDbProcessor dbProcessor;

    @Resource
    WorkbookInit workbookInit;

    @Resource
    IOperationProcessor operationProcessor;

    private Boolean lockStatus() {
        if (workbookInit.getLock().tryLock()) {
            workbookInit.getLock().unlock();
            return false;
        } else {
            return true;
        }
    }

    @RequestMapping(value = "/getLockStatus", method = RequestMethod.GET)
    public ResponseWrapper<Boolean> getLockStatus() {
        return ResponseWrapper.success(lockStatus());
    }

    /**
     * Luckysheet 首次加载数据, 参考
     * <a href="https://mengshukeji.gitee.io/LuckysheetDocs/zh/guide/config.html#loadurl">loadurl</a>
     *
     * @param param 相关参数，如用户名、工作表 ID 等
     * @return 一个由 LSSheet 组成的数组，但只有状态为显示 (status == 1) 的 sheet 必须要加载数据
     */
    @PostMapping(value = "/loadWorkbook", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public List<LSSheet> loadWorkbook(LoadURLRequestParam param) {
        logger.debug("Lock status: " + lockStatus());
        workbookInit.getLock().lock();
        logger.debug("WorkbookInit locked.");
        try {
            List<LSSheet> sheets;

            // If gridKey is not null, and there is a workbook in database, return the workbook.
            String gridKey = param.getGridKey();
            if (gridKey != null && !gridKey.isEmpty()) {
                if (workbookInit.lsWorkbookLoaded(gridKey)) {
                    sheets = workbookInit.getMyWorkBookByID(gridKey).getSheets();
                } else {
                    sheets = dbProcessor.loadWorkbook(gridKey).getSheets();
                }
                // 深拷贝 sheets 防止修改原数据
                sheets = sheets.stream().map(LSSheet::clone).toList();
                // 载入 status 为 1 的 sheet 数据中的 celldata，其余的 sheet 载入除 celldata 字段外的所有配置字段
                sheets.stream().filter(sheet -> sheet.getStatus() == 0).forEach(sheet -> sheet.setCelldata(null));

                // 如果有行数限制，将超出行数限制的行的数据删除
                if (param.getRows() != null) {
                    sheets.stream().filter(sheet -> sheet.getStatus() == 1)
                            .forEach(sheet -> {
                                sheet.getCelldata().removeIf(cell -> cell.getR() >= param.getRows());
                            });
                }
            } else {
                // If gridKey is null, throw an error
                throw new IllegalArgumentException("gridKey is null");
            }
            return sheets;
        } finally {
            workbookInit.getLock().unlock();
            logger.debug("WorkbookInit unlocked.");
        }
    }

    /**
     * 获取其他单元格数据
     *
     * @param gridKey 表格主键
     * @param index   sheet 主键合集，格式为 ["sheet_01","sheet_02","sheet_03"]
     * @return 一个字典，key 为 sheet 主键，值为一个 LSCell 组成的 List
     */
    @PostMapping(value = "/loadSheet", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public Map<String, List<LSCell>> loadSheet(@NonNull String gridKey, @NonNull String[] index) throws IllegalArgumentException {
        logger.debug("gridKey = " + gridKey);
        logger.debug("index = " + Arrays.asList(index));

        if (gridKey.isEmpty()) {
            throw new IllegalArgumentException("gridKey is null");
        }

        if (index.length == 0) {
            throw new IllegalArgumentException("index is null");
        }

        LSWorkBook wb = dbProcessor.loadWorkbook(gridKey);

//        if (workbookInit.lsWorkbookLoaded(gridKey)) {
//            logger.debug("Loading sheets from workbookInit.");
//            wb = workbookInit.getMyWorkBookByID(gridKey);
//        } else {
//            logger.debug("Loading sheets from database.");
//            wb = dbProcessor.loadWorkbook(gridKey);
//        }

        if (Objects.equals(wb, null)) {
            throw new RuntimeException("Workbook is null");
        }

        return wb.getSheets()
                .stream()
                .filter(sheet -> Arrays.asList(index).contains(sheet.getIndex()))
                .collect(Collectors.toMap(LSSheet::getIndex, LSSheet::getCelldata, (oldValue, newValue) -> oldValue, HashMap::new));
    }

    /**
     * 导入已有 Luckysheet
     *
     * @param importRequest 包含所需参数的结构
     * @return ImportWorkbookResponseDTO
     */
    @PostMapping(value = "/import", consumes = MediaType.APPLICATION_JSON_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public ResponseWrapper<ImportWorkbookResponseDTO> importWorkbook(@RequestBody ImportWorkbookRequestDTO importRequest) {
        LSWorkBook wb = dbProcessor.importWorkbook(new LSWorkBook(null, importRequest.getTitle(), importRequest.getLang(),
                importRequest.getSheets()
        ), "Work_" + IdUtil.simpleUUID());
        return ResponseWrapper.success(new ImportWorkbookResponseDTO(wb.getGridKey()));
    }

    @PostMapping(value = "/calc", consumes = MediaType.APPLICATION_JSON_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public ResponseWrapper<LSCell> calculateCellValue(@RequestBody BackendFormulaCalcRequestDTO request) {
        logger.info("Backend formula calc request: " + JSON.toJSONString(request));

        // 要求工作表已加载到内存
        // TODO: user check
        if (!workbookInit.lsWorkbookLoaded(request.getGridKey())) {
            return ResponseWrapper.failure("Workbook not loaded");
        }

        System.out.println("JSON.toJSONString(request) = " + JSON.toJSONString(request));

        LSCell newCell = operationProcessor.calculateCell(request.getGridKey(), request.getIndex(), request.getR(),
                request.getC()
        );

        return ResponseWrapper.success(newCell);
    }
}