package org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 添加公式
 * t:fc
 */
@Data
public class LSOperationCalcChainAdd {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 公式
     * 添加到末尾
     */
    @JSONField(name = "v")
    private String value;

    /**
     * 更新或者删除的函数位置
     */
    @JSONField(name = "pos")
    private int position;

    /**
     * 操作类型,add为新增，update为更新，del为删除
     */
    @JSONField(name = "op")
    private String op;
}
