package org.geely.pms_server.backend.core.model.luckysheet_operation.config;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

import java.util.Map;

/**
 * 列隐藏
 * t:colhidden
 */
@Data
public class LSOperationConfigHideColumn {

    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 包含所有隐藏列信息
     */
    @JSONField(name = "v")
    private Map<String, Integer> value;
}
