package org.geely.pms_server.backend.core.dto.import_workbook;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ImportWorkbookResponseDTO {
    private String gridKey;
}
