package org.geely.pms_server.backend.core.model.univer.en;

public enum GridType {
    DEFAULT,
    LINES,
    LINES_AND_CHARS,
    SNAP_TO_CHARS,
}
