package org.geely.pms_server.backend.core.model.calcChain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
公式链结点的一个属性，表示引用的单元格内容
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReferencingCell {
//    表达式内容，例如单个单元格为"A1"，范围单元格为"A1:B1"
    private String expression;
//    根据sheetName判断当前公式所引用单元格是否为更改单元格
    private String sheetName;
}
