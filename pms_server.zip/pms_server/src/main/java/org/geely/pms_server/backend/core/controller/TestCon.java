package org.geely.pms_server.backend.core.controller;

import com.alibaba.fastjson2.JSON;
import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.service.IDbProcessor;
import org.geely.pms_server.backend.univer.ICellData;
import org.geely.pms_server.backend.univer.IWorkSheetData;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController

public class TestCon {
    @Resource
    IDbProcessor dbProcessor;

    @GetMapping("/test")
    public Object test() {
        String wbId = "Work_3f9021c8542541199b97dcedbfb47c0c";
        LSWorkBook workBook = dbProcessor.loadWorkbook(wbId);
        // 使用 fastJSON 将对象转换为 JSON 字符串
        String jsonString = JSON.toJSONString(workBook);

        // 将 JSON 字符串保存到文件
        try (FileWriter fileWriter = new FileWriter("test.json")) {
            fileWriter.write(jsonString);
            System.out.println("Person object converted to JSON and saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return toUniver(workBook.getSheets().get(0));
    }

    Object toUniver(LSSheet sheet) {
        IWorkSheetData univerSheet = new IWorkSheetData();
        sheet.getCelldata().forEach(cell -> {
            ICellData univerCell = new ICellData();
            univerCell.setV(cell.getV().getV());
            univerCell.setF(cell.getV().getF());
            if (!univerSheet.getCellData().containsKey(cell.getR())) {
                Map<Integer, ICellData> map = new HashMap<>();
                map.put(cell.getC(), univerCell);
                univerSheet.getCellData().put(cell.getR(), map);
            } else {
                univerSheet.getCellData().get(cell.getR()).put(cell.getC(), univerCell);
            }
        });
        long start = System.currentTimeMillis();
        Object value = vlookup(univerSheet);
        long end = System.currentTimeMillis();
        System.out.println("vlookup time: " + (end - start));
        return value;
    }

    // 实现 VLOOKUP 函数的功能
    public Object vlookup(IWorkSheetData sheet) {
        Map<Integer, Map<Integer, ICellData>> cellData = sheet.getCellData();
        // 模拟调用 VLOOKUP 函数
        String lookupValue = "F2983";
        String lookupRange = "F10:G3000";
        int returnColumnIndex = 2;

        // 解析搜索范围 lookupRange
        String[] range = lookupRange.split(":");
        String startCell = range[0]; // F2910
        String endCell = range[1];   // G2920

        // 获取开始列和结束列的索引
        int startCol = parseColumnIndex(startCell); // 假设解析列索引的方法是 parseColumnIndex
        int endCol = parseColumnIndex(endCell);
        int startRow = parseRowIndex(startCell);
        int endRow = parseRowIndex(endCell);

        // 解析搜索键值 lookupValue 的行索引和列索引
        int lookupRowIndex = parseRowIndex(lookupValue); // 假设解析行索引的方法是 parseRowIndex
        int lookupColIndex = parseColumnIndex(lookupValue);
        System.out.println("startCol = " + startCol);
        System.out.println("endCol = " + endCol);
        System.out.println("startRow = " + startRow);
        System.out.println("endRow = " + endRow);
        System.out.println("lookupRowIndex = " + lookupRowIndex);
        System.out.println("lookupColIndex = " + lookupColIndex);

        if (lookupRowIndex < startRow || lookupRowIndex > endRow) {
            return "不在范围内";
        }
        if (lookupColIndex != startCol) {
            return "#N/A";
        }
        if (returnColumnIndex < 1 || returnColumnIndex > endCol - startCol + 1) {
            return "#REF!";
        }

        String value = (String) cellData.get(lookupRowIndex).get(lookupColIndex).getV();
        System.out.println("value = " + value);

        // 执行 VLOOKUP
        for (int i = startRow; i <= endRow; i++) {
            if (cellData.get(i).get(startCol).getV() == value) {
                ICellData cell = cellData.get(i).get(lookupColIndex + returnColumnIndex - 1);
                if (cell != null) {
                    return cell.getV();
                }
            }
        }

        return "没有找到"; // 如果未找到匹配的值，返回 null 或适当的默认值
    }

    private int parseColumnIndex(String cell) {
        String columnChars = cell.replaceAll("[0-9]", ""); // 提取字母部分，去掉数字部分
        int columnIndex = 0;
        int factor = 1;

        // 从右向左计算列索引
        for (int i = columnChars.length() - 1; i >= 0; i--) {
            char c = columnChars.charAt(i);
            columnIndex += (c - 'A' + 1) * factor; // 计算字母的值，A=1, B=2, ..., Z=26
            factor *= 26; // 26 进制递增
        }

        return columnIndex - 1; // 返回列索引，Excel 中从 0 开始
    }

    private int parseRowIndex(String cell) {
        String rowChars = cell.replaceAll("[A-Z]", ""); // 提取数字部分，去掉字母部分
        return Integer.parseInt(rowChars) - 1; // 返回行索引，Excel 中从 0 开始
    }
}
