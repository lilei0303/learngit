package org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;

import java.util.List;

/**
 * 行增加 或 列增加
 * t:arc
 * rc:r 或 c
 */
@Data
public class LSOperationRowOrColumnAdd {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 详细信息
     */
    @JSONField(name = "v")
    private AddDetail value;

    @Data
    public class AddDetail {
        /**
         * 从第几行或者列开始新增
         */
        private Integer index;

        /**
         * 增加多少行或者列
         */
        private Integer len;

        /**
         * 方向
         * rightbottom:向下增加行、向右增加列
         * lefttop:向上增加行、向左增加列
         */
        private String direction;

        /**
         * 新增行或者列的内容
         */
        List<List<LSCellValue>> data;
    }

    /**
     * 行操作还是列操作，值`r`代表行，`c`代表列
     */
    @JSONField(name = "rc")
    private String rowOrColumn;
}
