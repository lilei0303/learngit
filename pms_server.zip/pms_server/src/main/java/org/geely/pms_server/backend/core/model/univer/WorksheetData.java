package org.geely.pms_server.backend.core.model.univer;

import lombok.Getter;
import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

import java.util.List;
import java.util.Map;

@Getter
public class WorksheetData {
    /**
     * Id of the worksheet. This should be unique and immutable across the lifecycle of the worksheet.
     */
    private String id;
    /** Name of the sheet. */
    private String name;
    private String tabColor;
    private BooleanNumber hidden;
    private Freeze freeze;
    private Integer rowCount;
    private Integer columnCount;
    private Double zoomRatio;
    private Double scrollTop;
    private Double scrollLeft;
    private Double defaultColumnWidth;
    private Double defaultRowHeight;

    /** All merged cells in this worksheet. */
    private List<Range> mergeData;

    /** A matrix storing cell contents by row and column index. */
    private Map<Integer, Map<Integer, CellData>> cellData;
    private List<RowData> rowData;
    private List<ColumnData> columnData;

    private RowHeader rowHeader;

    private ColumnHeader columnHeader;

    private BooleanNumber showGridlines;

    private List<Object> selections;

    private BooleanNumber rightToLeft;
}

