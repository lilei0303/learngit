package org.geely.pms_server.backend.core.dto.manage_template;

import lombok.Data;

@Data
public class LoadTemplateParam {
    private String gridKey;
}
