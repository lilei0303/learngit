package org.geely.pms_server.backend.core.model.univer;

public class TextStyle extends StyleBase{
    private Double sc;
    private Double pos;
    private Double sa;
}
