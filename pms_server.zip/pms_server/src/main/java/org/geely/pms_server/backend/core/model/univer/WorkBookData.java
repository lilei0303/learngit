package org.geely.pms_server.backend.core.model.univer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import org.geely.pms_server.backend.core.model.univer.en.LocaleType;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
public class WorkBookData {
    /**
     * unit id
     */
    private String id;

    /**
     * Revision of this spreadsheet. Would be used in collaborated editing. Starts from one.
     */
    private Double rev;

    /**
     * Name of the spreadsheet.
     */
    private String name;

    /**
     * Version of Univer model definition.
     */
    private String appVersion;

    private LocaleType locale;

    /**
     * Style reference.
     */
    private Map<String, StyleData> styles;

    private List<String> sheetOrder; // sheet id order list ['xxxx-sheet3', 'xxxx-sheet1','xxxx-sheet2']
    private Map<String, WorksheetData> sheets;

    // The type of data depends on how the plug-in is defined
    private List<MyOptions> resources;
}
