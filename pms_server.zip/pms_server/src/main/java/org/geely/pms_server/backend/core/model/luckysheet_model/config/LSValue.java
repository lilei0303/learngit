package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置BorderInfoItem类的value字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSValue implements Serializable {

    /**
     * 单元格的行数索引
     */
    private Integer row_index;

    /**
     * 单元格的列数索引
     */
    private Integer col_index;

    /**
     * 单元格左边框
     */
    private LSBorderLeft l;

    /**
     * 单元格右边框
     */
    private LSBorderRight r;

    /**
     * 单元格上边框
     */
    private LSBorderTop t;

    /**
     * 单元格下边框
     */
    private LSBorderBottom b;
}
