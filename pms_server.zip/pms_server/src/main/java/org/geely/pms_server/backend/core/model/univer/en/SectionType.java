package org.geely.pms_server.backend.core.model.univer.en;

public enum SectionType {
    SECTION_TYPE_UNSPECIFIED, // The section type is unspecified.
    CONTINUOUS, // The section starts immediately after the last paragraph of the previous section.
    NEXT_PAGE, // The section starts on the next page.
    EVEN_PAGE, // The section starts on the next page.
    ODD_PAGE, // The section starts on the next page.
}
