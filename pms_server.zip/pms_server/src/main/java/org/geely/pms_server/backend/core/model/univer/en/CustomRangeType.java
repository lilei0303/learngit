package org.geely.pms_server.backend.core.model.univer.en;

public enum CustomRangeType {
    HYPERLINK,
    FIELD, // 17.16 Fields and Hyperlinks
    SDT, // 17.5.2 Structured Document Tags
    BOOKMARK,
    COMMENT,
    CUSTOM,
    MENTION,
    UNI_FORMULA,
}
