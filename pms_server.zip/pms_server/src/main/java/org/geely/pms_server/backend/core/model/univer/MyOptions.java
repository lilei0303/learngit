package org.geely.pms_server.backend.core.model.univer;

public class MyOptions {
    private String id;
    private String name;
    private String data;
}
