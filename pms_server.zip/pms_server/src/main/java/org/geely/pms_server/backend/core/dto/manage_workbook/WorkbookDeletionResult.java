package org.geely.pms_server.backend.core.dto.manage_workbook;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Optional;

@Data
@AllArgsConstructor
public class WorkbookDeletionResult {
    private String workbookId;
    private Boolean deleted;
    private Optional<String> reason;

    public static WorkbookDeletionResult success(String wbId) {
        return new WorkbookDeletionResult(wbId, true, Optional.empty());
    }

    public static WorkbookDeletionResult failure(String wbId, @NotNull String reason) {
        return new WorkbookDeletionResult(wbId, false, Optional.of(reason));
    }
}
