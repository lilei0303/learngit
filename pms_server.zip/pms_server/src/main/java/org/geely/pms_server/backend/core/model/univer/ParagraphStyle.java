package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.*;

public class ParagraphStyle {
    String headingId;
    NamedStyleType namedStyleType;
    HorizontalAlign horizontalAlign;
    Double lineSpacing;
    TextDirection direction;
    SpacingRule spacingRule;
    BooleanNumber snapToGrid;
    NumberUnit spaceAbove;
    NumberUnit spaceBelow;
    ParagraphBorder borderBetween;
    ParagraphBorder borderTop;
    ParagraphBorder borderBottom;
    ParagraphBorder borderLeft;
    ParagraphBorder borderRight;
    NumberUnit indentEnd;
    BooleanNumber keepLines;
    BooleanNumber keepNext;
    BooleanNumber wordWrap;
    BooleanNumber widowControl;
    Shading shading;
    BooleanNumber suppressHyphenation;
}
