package org.geely.pms_server.backend.core.model.luckysheet_model.pivottable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 该类详细配置PivotTable类的column和row字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSColumn {

    private Integer index;

    private Integer name;

    private String fullname;
}
