package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;
import org.geely.pms_server.backend.core.model.univer.en.PositionedObjectLayoutType;
import org.geely.pms_server.backend.core.model.univer.en.WrapTextType;

public class DocDrawingBase {
    private String drawingId;

    private String title;

    private String description;

    private DocDrawingPosition docTransform;

    private PositionedObjectLayoutType layoutType;

    private BooleanNumber behindDoc; // Nullable boolean to handle the optional property

    private Integer[] start; // Nullable array to handle the optional property

    private Integer[][] lineTo; // Nullable array to handle the optional property

    private WrapTextType wrapText; // Nullable enum to handle the optional property

    private Double distL; // Nullable double to handle the optional property

    private Double distR; // Nullable double to handle the optional property

    private Double distT; // Nullable double to handle the optional property

    private Double distB; // Nullable double to handle
}
