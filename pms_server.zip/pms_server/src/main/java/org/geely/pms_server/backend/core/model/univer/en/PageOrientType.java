package org.geely.pms_server.backend.core.model.univer.en;

public enum PageOrientType {
    PORTRAIT,
    LANDSCAPE
}
