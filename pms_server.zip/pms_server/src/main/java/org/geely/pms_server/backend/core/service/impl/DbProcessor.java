package org.geely.pms_server.backend.core.service.impl;

import cn.hutool.core.util.IdUtil;
import org.geely.pms_server.backend.core.dto.manage_workbook.LSWorkbookInfo;
import org.geely.pms_server.backend.core.entity.workbook.WorkBlockEntity;
import org.geely.pms_server.backend.core.entity.workbook.WorkBookEntity;
import org.geely.pms_server.backend.core.entity.workbook.WorkSheetEntity;
import org.geely.pms_server.backend.core.model.calculate.WorkbookInit;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.service.IDbProcessor;
import org.geely.pms_server.backend.utils.SerializeUtil;
import org.geely.pms_server.backend.utils.SpringContextUtil;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

/**
 * 实现对数据的存取接口
 */
@Service
public class DbProcessor extends PublicDbProcessor implements IDbProcessor {

    private WorkbookInit workbookInit() {
        return SpringContextUtil.getBean(WorkbookInit.class);
    }

    private static final ReadWriteLock readWriteLock = new ReentrantReadWriteLock();

    /**
     * 用户新建工作簿时调用此接口
     *
     * @return
     */
    @Override
    public LSWorkBook loadNewWb() {
        LSWorkBook workBook = new LSWorkBook();

        //生成workbook
        WorkBookEntity wb = new WorkBookEntity();
        String wbId = "Work_" + IdUtil.simpleUUID();
        workBook.setTitle("新建工作簿");
        workBook.setGridKey(wbId);
        wb.setId(wbId);
        wb.setWorkBook(workBook);
        workBookRepository.save(wb);
        //生成sheet
        WorkSheetEntity ws = new WorkSheetEntity();
        String sheetId = "Sheet_" + IdUtil.simpleUUID();
        LSSheet sheet = new LSSheet();
        sheet.setIndex(sheetId);
        sheet.setStatus(1);
        sheet.setOrder(0);
        ws.setId(sheetId);
        ws.setBelongsId(wbId);
        ws.setOrder(0);
        WorkBlockEntity workBlock = new WorkBlockEntity();
        saveSheetData(workBlock, sheet, workBook.getGridKey(), workBlockRepository);
        workSheetRepository.save(ws);
        //返回workbook
        workBook.getSheets().add(sheet);
        return workBook;
    }

    /**
     * 用户打开已有工作簿调用此接口
     *
     * @param wbId
     * @return
     */
    @Override
    public LSWorkBook loadWorkbook(String wbId) {
        readWriteLock.readLock().lock();
        try {
            Optional<WorkBookEntity> Owb = workBookRepository.findById(wbId);
            LSWorkBook workBook = new LSWorkBook();
            if (Owb.isPresent()) {
                workBook = Owb.get().getWorkBook();
            }
            List<WorkSheetEntity> wsList = workSheetRepository.findAllByWbId(wbId);
            //使用Collections集合工具类进行排序
            Collections.sort(wsList);
            //获取所有sheet
            workBook.setSheets(getSheets(wsList, workBlockRepository));
            return workBook;
        } finally {
            readWriteLock.readLock().unlock();
        }
    }

    /**
     * 数据导入
     *
     * @param workBook
     * @return
     */
    @Override
    public LSWorkBook importWorkbook(LSWorkBook workBook, String wbId) {
        //获取sheets
        List<LSSheet> sheets = workBook.getSheets();
        //保存导入的工作簿
        WorkBookEntity wb = new WorkBookEntity();
        workBook.setGridKey(wbId);
        workBook.setSheets(null);
        wb.setId(wbId);
        wb.setWorkBook(workBook);

        //遍历sheets
        sheets.forEach(sheet -> {
            WorkBlockEntity workBlock = new WorkBlockEntity();
            //获取数据
            List<LSCell> cellData = sheet.getCelldata();

            //TODO:导入的数据无 r、c会有问题
            int row = 74;
            int column = 50;
            for (LSCell cell : cellData) {
                if (cell.getR() > row) {
                    row = cell.getR();
                }
                if (cell.getC() > column) {
                    column = cell.getC();
                }
            }
            sheet.setRow(row + 10);
            sheet.setColumn(column + 10);

            //保存导入的sheet
            WorkSheetEntity ws = new WorkSheetEntity();
            String sheetId = "Sheet_" + IdUtil.simpleUUID();
            //更新公式链为自定义index值
            sheet.getCalcChain().forEach(calc -> {
                calc.setIndex(sheetId);
            });
            sheet.setIndex(sheetId);
            //克隆celldata,防止修改原数据
            List<LSCell> cloneCellData = cellData.stream().map(LSCell::clone).toList();
            //获取第一块存储
//            List<LSCell> firstBlockData = getFirstBlockData(cellData, 0, 50);
//            saveCellData(workBlock, firstBlockData, workBook.getGridKey(), sheet, workBlockRepository);
            //分块存储sheet的剩余数据
            saveSheetData(workBlock, sheet, workBook.getGridKey(), workBlockRepository);
            //存储实体
            ws.setId(sheetId);
            ws.setOrder(sheet.getOrder());
            ws.setBelongsId(workBook.getGridKey());
            workSheetRepository.save(ws);
            sheet.setCelldata(cloneCellData);
        });
        workBookRepository.save(wb);
        workBook.setSheets(sheets);
        return workBook;
    }


    /**
     * 保存内存态的LSWorkbook到数据库
     *
     * @param workbook
     */
    @Override
    public void saveWorkbook(LSWorkBook workbook) {
        if (workbook == null)
            return;
        String wbId = workbook.getGridKey();

        readWriteLock.writeLock().lock();
        try {
            List<LSSheet> sheets = workbook.getSheets();
            //保存或更新workbook实体
            workBookRepository.findById(workbook.getGridKey()).ifPresent(wb -> {
                workbook.setSheets(null);
                wb.setWorkBook(workbook);
                wb.getWorkBook().setCalcChains(null);
                workBookRepository.save(wb);
            });
            //从数据库删除cacheDelLSWb缓存的sheet
            Map<String, Map<String, LSSheet>> cacheDelLSWb = OperationProcessor.getCacheDelLSWb();
            if (cacheDelLSWb.get(wbId) != null && !cacheDelLSWb.get(wbId).isEmpty()) {
                cacheDelLSWb.get(wbId).keySet().forEach(index -> {
                    workSheetRepository.deleteById(index);
                    workBlockRepository.deleteAllByWbIdAndSheetId(wbId, index);
                });
                cacheDelLSWb.remove(wbId);
            }

            //遍历sheets
            sheets.forEach(sheet -> {
                WorkBlockEntity workBlock = new WorkBlockEntity();
                //获取第一块数据
//            List<LSCell> firstBlockData = getFirstBlockData(sheet.getCelldata(), 0, 50);
                //sheet是否存在数据库
                workSheetRepository.findById(sheet.getIndex()).ifPresentOrElse(ws -> {
                    //删除旧数据
                    workBlockRepository.deleteAllByWbIdAndSheetId(workbook.getGridKey(), sheet.getIndex());
                    //存储第一块数据
//                saveCellData(workBlock, firstBlockData, workbook.getGridKey(), sheet, workBlockRepository);
                    //存储剩余数据
                    saveSheetData(workBlock, sheet, workbook.getGridKey(), workBlockRepository);
                    ws.setOrder(sheet.getOrder());
                    workSheetRepository.save(ws);
                }, () -> {
                    //存储第一块数据
//                saveCellData(workBlock, firstBlockData, workbook.getGridKey(), sheet, workBlockRepository);
                    //存储剩余数据
                    saveSheetData(workBlock, sheet, workbook.getGridKey(), workBlockRepository);
                    //存储实体
                    WorkSheetEntity ws = new WorkSheetEntity();
                    ws.setId(sheet.getIndex());
                    ws.setOrder(sheet.getOrder());
                    ws.setBelongsId(workbook.getGridKey());
                    workSheetRepository.save(ws);
                });
            });
        } finally {
            readWriteLock.writeLock().unlock();
        }
    }

    @Override
    public List<LSWorkbookInfo> getAllWorkbookInfo() {
        return workBookRepository.findAll().stream()
                .map(entity -> new LSWorkbookInfo(entity.getWorkBook().getTitle(), entity.getId(), entity.getLastUpdateTime()))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteWorkbook(String wbId) {
        //从内存态删除
        if (workbookInit().getLSWorkbooks() != null) {
            workbookInit().getLSWorkbooks().remove(wbId);
        }
        //从数据库删除
        workBlockRepository.deleteAllByWbId(wbId);
        workSheetRepository.deleteAllByWbId(wbId);
        workBookRepository.deleteById(wbId);
    }

    @Override
    public Boolean workbookExists(String wbId) {
        return workBookRepository.existsById(wbId);
    }

    @Override
    public List<LSCell> getFirstBlock(String wbId) {
        WorkBlockEntity wb = workBlockRepository.findByWbIdAndStatusAndNumber(wbId, 1, 0);
        if (wb != null) {
            LSCell[] blockData = (LSCell[]) SerializeUtil.unSerialize(wb.getData());
            assert blockData != null;
            return Arrays.asList(blockData);
        }
        return null;
    }
}
