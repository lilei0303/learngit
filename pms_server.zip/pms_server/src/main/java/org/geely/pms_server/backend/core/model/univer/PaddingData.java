package org.geely.pms_server.backend.core.model.univer;

public class PaddingData {
    private Double t;

    private Double b;

    private Double l;

    private Double r;
}
