package org.geely.pms_server.backend.core.model.univer.en;

public enum BulletAlignment {
    BULLET_ALIGNMENT_UNSPECIFIED, //	The bullet alignment is unspecified.
    START, //	The bullet is aligned to the start of the space allotted for rendering the bullet. Left-aligned for LTR text, right-aligned otherwise.
    CENTER, //	The bullet is aligned to the center of the space allotted for rendering the bullet.
    END, //	The bullet is aligned to the end of the space allotted for rendering the bullet. Right-aligned for LTR text, left-aligned otherwise.
}
