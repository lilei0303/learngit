package org.geely.pms_server.backend.core.service.impl;

import cn.hutool.core.util.IdUtil;
import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.entity.BaseBlockEntity;
import org.geely.pms_server.backend.core.entity.BaseSheetEntity;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.core.repository.template.TemplateBlockRepository;
import org.geely.pms_server.backend.core.repository.template.TemplateRepository;
import org.geely.pms_server.backend.core.repository.template.TemplateSheetRepository;
import org.geely.pms_server.backend.core.repository.workbook.WorkBlockRepository;
import org.geely.pms_server.backend.core.repository.workbook.WorkBookRepository;
import org.geely.pms_server.backend.core.repository.workbook.WorkSheetRepository;
import org.geely.pms_server.backend.utils.SerializeUtil;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

public class PublicDbProcessor {
    @Resource
    WorkBlockRepository workBlockRepository;
    @Resource
    WorkBookRepository workBookRepository;
    @Resource
    WorkSheetRepository workSheetRepository;
    @Resource
    TemplateRepository templateRepository;
    @Resource
    TemplateSheetRepository templateSheetRepository;
    @Resource
    TemplateBlockRepository templateBlockRepository;

    /**
     * 从celldata取第一块数据
     *
     * @param cellData
     * @return
     */
    public List<LSCell> getFirstBlockData(List<LSCell> cellData, Integer rowRangeMin, Integer rowRangeMax) {
        List<LSCell> firstBlock = new ArrayList<>();
        ListIterator<LSCell> iterator = cellData.listIterator();
        while (iterator.hasNext()) {
            LSCell cell = iterator.next();
            if (cell.getR() >= rowRangeMin && cell.getR() <= rowRangeMax) {
                firstBlock.add(cell);
                iterator.remove();
            }
        }
        return firstBlock;
    }

    /**
     * 设置sheetBlock的属性
     *
     * @param sheetBlock
     * @param parentId
     * @param sheet
     * @param blockBytes
     * @param number
     * @param size
     */
    public void setBlock(BaseBlockEntity sheetBlock, String parentId, LSSheet sheet, byte[] blockBytes, Integer number, Integer size) {
        sheetBlock.setId(IdUtil.simpleUUID());
        sheetBlock.setBelongsId(parentId);
        sheetBlock.setSheetId(sheet.getIndex());
        sheetBlock.setData(blockBytes);
        sheetBlock.setNumber(number);
        sheetBlock.setSize(size);
        sheetBlock.setStatus(sheet.getStatus());
    }

    /**
     * celldata二进制转对象列表
     *
     * @param entity
     * @return
     */
    public Collection<LSCell> cellBinToObject(BaseBlockEntity entity) {
        //二进制转对象列表
        LSCell[] blockData = (LSCell[]) SerializeUtil.unSerialize(entity.getData());
        assert blockData != null;
        return Arrays.asList(blockData);
    }

    /**
     * sheet二进制转对象列表
     *
     * @param data
     * @return
     */
    public LSSheet sheetsBinToObject(byte[] data) {
        LSSheet blockData = (LSSheet) SerializeUtil.unSerialize(data);
        assert blockData != null;
        return blockData;
    }

    /**
     * 返回完整的sheet数据
     *
     * @param entityList
     * @return
     */
    public LSSheet getSheetData(List<? extends BaseBlockEntity> entityList) {
//        List<LSCell> cellData = new ArrayList<>();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        //遍历分块二进制转对象列表
        entityList.forEach(sb -> {
//            if (sb.getNumber() == 0) {
//                cellData.addAll(cellBinToObject(sb));
//            } else {
            try {
                outputStream.write(sb.getData());
            } catch (IOException e) {
                throw new RuntimeException(e);
//                }
            }
        });
        byte[] mergedArray = outputStream.toByteArray();
        LSSheet sheet = sheetsBinToObject(mergedArray);
//        sheet.getCelldata().addAll(cellData);
        return sheet;
    }

    /**
     * 保存第一块数据
     *
     * @param sheetBlock
     * @param firstBlockData
     * @param parentId
     * @param sheet
     * @param blockRepository
     * @param <T>
     */
    public <T extends BaseBlockEntity> void saveCellData(T sheetBlock, List<LSCell> firstBlockData, String parentId, LSSheet sheet, MongoRepository<T, String> blockRepository) {
        LSCell[] blockArray = firstBlockData.toArray(new LSCell[0]);
        byte[] blockBytes = SerializeUtil.serialize(blockArray);
        setBlock(sheetBlock, parentId, sheet, blockBytes, 0, firstBlockData.size());
        blockRepository.save(sheetBlock);
    }

    /**
     * 保存sheet剩余的数据
     *
     * @param sheetBlock
     * @param sheet
     * @param parentId
     * @param blockRepository
     * @param <T>
     */
    public <T extends BaseBlockEntity> void saveSheetData(T sheetBlock, LSSheet sheet, String parentId, MongoRepository<T, String> blockRepository) {
        byte[] sheetBytes = SerializeUtil.serialize(sheet);
        int chunkSize = 16600000;
        for (int i = 0; i < sheetBytes.length; i += chunkSize) {
            byte[] chunk = Arrays.copyOfRange(sheetBytes, i, Math.min(i + chunkSize, sheetBytes.length));
//            System.out.println("chunk" + i / chunkSize + " = " + chunk.length);
            setBlock(sheetBlock, parentId, sheet, chunk, i / chunkSize, chunk.length);
            blockRepository.save(sheetBlock);
        }
    }

    /**
     * 返回sheets
     *
     * @param sheetList
     * @param blockRepository
     * @param <T>
     * @param <R>
     * @return
     */
    public <T extends BaseSheetEntity, R extends BaseBlockEntity> List<LSSheet> getSheets(List<T> sheetList, MongoRepository<R, String> blockRepository) {
        List<LSSheet> sheets = new ArrayList<>();
        sheetList.forEach(sheet -> {
            try {
                // 通过反射调用findAllBySheetId方法
                Method method = blockRepository.getClass().getMethod("findAllBySheetId", String.class);
                List<R> blockList = (List<R>) method.invoke(blockRepository, sheet.getId());
                sheets.add(getSheetData(blockList));
            } catch (Exception e) {
                e.printStackTrace();
                // 处理异常情况
            }
        });
        return sheets;
    }
}
