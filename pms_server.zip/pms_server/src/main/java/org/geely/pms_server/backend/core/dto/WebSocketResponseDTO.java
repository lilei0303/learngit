package org.geely.pms_server.backend.core.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@AllArgsConstructor
public class WebSocketResponseDTO {
    private static final long serialVersionUID = -275582248840137389L;

    private Integer type;

    private String id;

    private String username;

    private String data;


    public static WebSocketResponseDTO success(String id, String username, String data) {
        return new WebSocketResponseDTO(1, id, username, data);
    }

    public static WebSocketResponseDTO update(String id, String username, String data) {
        return new WebSocketResponseDTO(2, id, username, data);
    }

    public static WebSocketResponseDTO mv(String id, String username, String data) {
        return new WebSocketResponseDTO(3, id, username, data);
    }

    public static WebSocketResponseDTO bulkUpdate(String id, String username, String data) {
        return new WebSocketResponseDTO(4, id, username, data);
    }

    public static WebSocketResponseDTO error(String id, String username, String errorMessage) {
        return new WebSocketResponseDTO(5, id, username, errorMessage);
    }
}
