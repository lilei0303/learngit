package org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置LSSheet的luckysheet_select_save字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCellRangeItem implements Serializable {

    private Integer left;

    private Integer width;

    private Integer top;

    private Integer height;

    private Integer left_move;

    private Integer width_move;

    private Integer top_move;

    private Integer height_move;

    private List<Integer> row;

    private List<Integer> column;

    private Integer row_focus;

    private Integer column_focus;

    private Boolean column_select;

    private Boolean row_select;
}
