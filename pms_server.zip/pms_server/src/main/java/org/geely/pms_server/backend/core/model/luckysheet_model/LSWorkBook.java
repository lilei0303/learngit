package org.geely.pms_server.backend.core.model.luckysheet_model;

import com.google.common.base.Objects;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.geely.pms_server.backend.core.model.calcChain.CalcNode;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * 该类作为一个工作簿
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class LSWorkBook extends Base{
    public LSWorkBook() {
        super();
    }

    public LSWorkBook(String gridKey, String title, String lang, List<LSSheet> sheets) {
        super(gridKey, title, lang, sheets);
    }

    public String getSuper(){
        return super.getTitle();
    }

    // 当前工作簿的公式链
    private HashSet<CalcNode> calcChains = new HashSet<>();

    //根据LSSheet的索引来获取其中的数据
    public LSSheet getLSSheetsByOrder(int sheetOrder) {
        Iterator<LSSheet> iterator = getSheets().iterator();
        LSSheet goalLSSheet = new LSSheet();
        while (iterator.hasNext()) {
            LSSheet lsSheet = iterator.next();
            if (lsSheet.getOrder() == sheetOrder) {
                goalLSSheet = lsSheet;
                break; // 当查找到index等于传入参数的sheet时，跳出循环
            }
        }
        return goalLSSheet;
    }

    public Optional<LSSheet> getLSSheetsByIndex(String sheetIndex) {
        for (LSSheet sheet : getSheets()) {
            if (Objects.equal(sheet.getIndex(), sheetIndex)) {
                return Optional.of(sheet);
            }
        }
        return Optional.empty();
    }
}
