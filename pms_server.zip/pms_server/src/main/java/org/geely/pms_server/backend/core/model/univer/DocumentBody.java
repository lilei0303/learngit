package org.geely.pms_server.backend.core.model.univer;


import java.util.List;
import java.util.Map;

public class DocumentBody {
    private String dataStream;
    private List<TextRun> textRuns;
    private List<Paragraph> paragraphs;
    private List<SectionBreak> sectionBreaks;
    private List<CustomBlock> customBlocks;
    private List<Table> tables;
    // private Map<Integer, TableOfContent> tableOfContents;
    // private Map<Integer, Hyperlink> links;
    private List<CustomRange> customRanges;
    private List<CustomDecoration> customDecorations;

    /**
     * for copy/paste, data of custom-range and other module
     * it won't save to disk
     */
    private Map<String, String> payloads;
}
