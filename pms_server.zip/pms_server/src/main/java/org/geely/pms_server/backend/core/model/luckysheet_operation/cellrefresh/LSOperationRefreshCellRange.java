package org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;

import java.util.List;

/**
 * 范围单元格刷新
 * t:rv
 */
@Data
public class LSOperationRefreshCellRange {

    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 范围二维数组，单元格对象参考
     * <a href="https://dream-num.github.io/LuckysheetDocs/zh/guide/cell.html#%E5%9F%BA%E6%9C%AC%E5%8D%95%E5%85%83%E6%A0%BC">单元格属性表</a>
     * <p>
     */
    @JSONField(name = "v")
    private List<List<LSCellValue>> value;

    /**
     * 范围行列数
     */
    @JSONField(name = "range")
    private Range range;

    @Data
    public class Range {
        private List<Integer> row;
        private List<Integer> column;
    }
}
