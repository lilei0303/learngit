package org.geely.pms_server.backend.core.model.luckysheet_model.filter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置Filter类的caljs字段
 * caljs:{value: null, text: "无", type: "0"}
 * caljs:{value: "cellnull", text: "单元格为空", type: "0"}
 * caljs:{value: "cellnonull", text: "单元格有数据", type: "0"}
 * caljs:{value: "textinclude", text: "文本包含", type: "1", value1: "Lucky"}
 * caljs:{value: "textnotinclude", text: "文本不包含", type: "1", value1: "Lucky"}
 * caljs:{value: "textstart", text: "文本开头为", type: "1", value1: "Lucky"}
 * caljs:{value: "textend", text: "文本结尾为", type: "1", value1: "Lucky"}
 * caljs:{value: "textequal", text: "文本等于", type: "1", value1: "Lucky"}
 * caljs:{value: "dateequal", text: "日期等于", type: "1", value1: "2020-10-16"}
 * caljs:{value: "datelessthan", text: "日期早于", type: "1", value1: "2020-10-16"}
 * caljs:{value: "datemorethan", text: "日期晚于", type: "1", value1: "2020-10-16"}
 * caljs:{value: "morethan", text: "大于", type: "1", value1: "10"}
 * caljs:{value: "moreequalthan", text: "大于等于", type: "1", value1: "10"}
 * caljs:{value: "lessthan", text: "小于", type: "1", value1: "10"}
 * caljs:{value: "lessequalthan", text: "小于等于", type: "1", value1: "10"}
 * caljs:{value: "equal", text: "等于", type: "1", value1: "10"}
 * caljs:{value: "noequal", text: "不等于", type: "1", value1: "10"}
 * caljs:{value: "include", text: "介于", type: "2", value1: "15", value2: "25"}
 * caljs:{value: "noinclude", text: "不在其中", type: "2", value1: "15", value2: "25"}
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCalJs implements Serializable {

    private String value;

    private String value1;

    private String value2;

    private String text;

    /**
     * 对应哪个value
     */
    private String type;
}
