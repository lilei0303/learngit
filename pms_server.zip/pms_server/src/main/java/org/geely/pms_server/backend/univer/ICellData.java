package org.geely.pms_server.backend.univer;

import lombok.Data;

@Data
public class ICellData {
    private Object v;
    private String s;
    private Integer t;
    private String p;
    private String f;
    private String si;
}
