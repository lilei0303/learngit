package org.geely.pms_server.backend.core.model.luckysheet_model.alternateformat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;

import java.io.Serializable;

/**
 * 该类详细配置LSSheet类的luckysheet_alternateformat_save字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSAlternateFormat implements Serializable {

    /**
     * 单元格范围
     */
    private LSCellRangeItem cellrange;

    /**
     * 格式
     */
    private LSAFormat format;

    /**
     * 含有页眉
     */
    private Boolean hasRowHeader;

    /**
     * 含有页脚
     */
    private Boolean hasRowFooter;
}
