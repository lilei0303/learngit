package org.geely.pms_server.backend.core.model.luckysheet_operation.config;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

import java.util.Map;

/**
 * 修改列宽
 * t:columnlen
 */
@Data
public class LSOperationSetColWidth {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 包含所有修改过列宽的单元格信息 [Col : Width]
     */
    @JSONField(name = "v")
    private Map<String, Integer> value;
}
