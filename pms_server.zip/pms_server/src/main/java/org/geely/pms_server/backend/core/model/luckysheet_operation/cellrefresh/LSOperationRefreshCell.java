package org.geely.pms_server.backend.core.model.luckysheet_operation.cellrefresh;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCellValue;

/**
 * 单个单元格刷新
 * t:v
 */
@Data
@AllArgsConstructor
public class LSOperationRefreshCell {

    /**
     * 操作类型表示符号
     */
    @JSONField(name = "t")
    public String type;

    /**
     * 当前 sheet 的 index 值
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 单元格的值，数字、字符串或着对象格式，对象参考
     * <a href="https://dream-num.github.io/LuckysheetDocs/zh/guide/cell.html#%E5%9F%BA%E6%9C%AC%E5%8D%95%E5%85%83%E6%A0%BC">单元格属性表</a>
     */
    @JSONField(name = "v")
    private LSCellValue value;

    /**
     * 单元格的行号
     */
    @JSONField(name = "r")
    private int row;

    /**
     * 单元格的列号
     */
    @JSONField(name = "c")
    private int column;

    public LSOperationRefreshCell(String index, LSCellValue value, int row, int column) {
        this.type = "v";
        this.index = index;
        this.value = value;
        this.row = row;
        this.column = column;
    }
}
