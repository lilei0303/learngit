package org.geely.pms_server.backend.core.model.univer.en;

public enum TextDirectionType {
    NORMAL, // Horizontal
    TBRL, // Vertical
    LRTBV, // Rotate Asian characters 270°
}
