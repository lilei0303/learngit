package org.geely.pms_server.backend.core.model.univer.en;

public enum ETextDecoration {
    DASH,
    DASH_DOT_DOT_HEAVY,
    DASH_DOT_HEAVY,
    DASHED_HEAVY,
    DASH_LONG,
    DASH_LONG_HEAVY,
    DOT_DASH,
    DOT_DOT_DASH,
    DOTTED,
    DOTTED_HEAVY,
    DOUBLE,
    NONE,
    SINGLE,
    THICK,
    WAVE,
    WAVY_DOUBLE,
    WAVY_HEAVY,
    WORDS
}
