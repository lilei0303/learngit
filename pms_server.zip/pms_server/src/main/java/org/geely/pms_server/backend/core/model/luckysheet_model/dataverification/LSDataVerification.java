package org.geely.pms_server.backend.core.model.luckysheet_model.dataverification;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 作用：数据验证的配置信息。
 * 该类详细配置LSSheet类的dataVerification字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSDataVerification implements Serializable {
    /**
     * 类型
     * "dropdown"(下拉列表)
     * "checkbox"(复选框)
     * "number"(数字)
     * "number_integer"(数字-整数)
     * "number_decimal"(数字-小数)
     * "text_content"(文本-内容)
     * "text_length"(文本-长度)
     * "date"(日期)
     * "validity"(有效性)；
     */
    private String type;

    /**
     * 条件类型
     * 类型type值为"dropdown"/"checkbox"时，type2值可为
     * null；
     * 类型type值为"number"/"number_integer"/"number_decimal"/"text_length"时，type2值可为
     * "bw"(介于)
     * "nb"(不介于)
     * "eq"(等于)
     * "ne"(不等于)
     * "gt"(大于)
     * "lt"(小于)
     * "gte"(大于等于)
     * "lte"(小于等于)
     * 类型type值为"text_content"时，type2值可为
     * "include"(包括)
     * "exclude"(不包括)
     * "equal"(等于)
     * 类型type值为"date"时，type2值可为
     * "bw"(介于)
     * "nb"(不介于)
     * "eq"(等于)
     * "ne"(不等于)
     * "bf"(早于)
     * "nbf"(不早于)
     * "af"(晚于)
     * "naf"(不晚于)
     * 类型type值为"validity"时，type2值可为
     * "card"(身份证号码)
     * "phone"(手机号)；
     */
    private String type2;

    /**
     * 类型type值为"dropdown"时，value1值可为选区或以英文逗号隔开的字符串，如"1,2,3"或者"A1:B2"；
     * 类型type值为"validity"时，value1值可为空；
     * 其他类型时value1值为数值或字符串
     */
    private String value1;

    /**
     * 类型type值为"checkbox"或者条件类型type2值为"bw"、"nb"时有value2值，条件值为数值或日期时，条件值2要大于等于条件值1；其它情况可为空；
     */
    private String value2;

    /**
     * 是否勾选中复选框；type为checkbox时需配置
     */
    private Boolean checked;

    /**
     * 自动远程获取选项；默认为false
     */
    private Boolean remote;

    /**
     * 输入数据无效时禁止输入；默认为false
     */
    private Boolean prohibitInput;

    /**
     * 选中单元格时显示提示语；默认为false
     */
    private Boolean hintShow;

    /**
     * 提示语文本；hintShow为true时需配置
     */
    private String hintText;
}
