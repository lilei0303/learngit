package org.geely.pms_server.backend.core.model.univer;

public class Test {
    public static void main(String[] args) {
        StyleData styleData = new StyleData();
        System.out.println("styleData = " + styleData);
    }
}
