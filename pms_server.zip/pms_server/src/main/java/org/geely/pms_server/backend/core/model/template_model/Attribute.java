package org.geely.pms_server.backend.core.model.template_model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Attribute implements Serializable {
    /**
     * 标题
     */
    private String title;

    /**
     * 公式表达式
     */
    private String formulaExpression;

    /**
     * 样式
     */
    private String style;

    /**
     * 表头样式
     */
    private String headerStyle;

    /**
     * 宽度
     */
    private Integer width;

    /**
     * 条件格式化
     */
    private String conditionalFormat;

    /**
     * 只读
     */
    private Boolean readonly;

    /**
     * 列固定
     */
    private Boolean fixedColumn;

    /**
     * 数据验证规则
     */
    private String validationRules;

    /**
     * 关联表
     */
    private String relatedTable;

    /**
     * 查找源字段
     */
    private String sourceField;

    /**
     * 目标字段
     */
    private String targetField;
}
