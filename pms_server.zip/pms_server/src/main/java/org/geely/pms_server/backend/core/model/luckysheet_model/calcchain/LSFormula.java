package org.geely.pms_server.backend.core.model.luckysheet_model.calcchain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置LSSheet类的calcChain字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSFormula implements Serializable {
    /**
     * 行数
     */
    private Integer r;

    /**
     * 列数
     */
    private Integer c;

    /**
     * 工作表id
     */
    private String index;

    /**
     * 公式信息，包含公式计算结果和公式字符串
     */
    private String func;

    // 公式单元格引用的单元格数组
    private List<String> referencingCells;

    // 当前公式链节点的单元格名称
    private String cellName;

    /**
     * "w"：采用深度优先算法 "b":普通计算
     */
    private String color;

    /**
     *
     */
    private String parent;

    /**
     *
     */
    private Object children;

    /**
     *
     */
    private String times;

}
