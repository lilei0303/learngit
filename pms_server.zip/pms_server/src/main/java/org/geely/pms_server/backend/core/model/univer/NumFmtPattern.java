package org.geely.pms_server.backend.core.model.univer;

public class NumFmtPattern {
    private String pattern;
}
