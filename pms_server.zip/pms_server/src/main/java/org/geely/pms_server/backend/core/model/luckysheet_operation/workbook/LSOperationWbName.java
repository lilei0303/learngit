package org.geely.pms_server.backend.core.model.luckysheet_operation.workbook;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 修改工作簿名称
 * t:na
 */
@Data
public class LSOperationWbName {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 工作簿名称
     */
    @JSONField(name = "v")
    private String value;
}
