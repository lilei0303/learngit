package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.WidthType;

import java.util.List;

public class Table {
    private Double startIndex;
    private Double endIndex;
    private Double rows;
    private Double columns;
    private List<TableRow> tableRows;
    private WidthType tableType;
    private Double width;
}
