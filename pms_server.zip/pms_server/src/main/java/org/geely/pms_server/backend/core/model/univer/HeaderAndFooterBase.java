package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

public class HeaderAndFooterBase {
    private String defaultHeaderId; // defaultHeaderId or the odd page header id
    private String defaultFooterId; // defaultFooterId or the odd page footer id
    private String evenPageHeaderId; // evenPageHeaderId
    private String evenPageFooterId; // evenPageFooterId
    private String firstPageHeaderId; // firstPageHeaderId
    private String firstPageFooterId; // firstPageFooterId
    private BooleanNumber useFirstPageHeaderFooter; // useFirstPageHeaderFooter
    private BooleanNumber evenAndOddHeaders; // useEven
}
