package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置Config类的merge字段和CellValue类的mc
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSMerge implements Serializable {
    /**
     * 主单元格的行号
     */
    private Integer r;

    /**
     * 主单元格的列号
     */
    private Integer c;

    /**
     * 合并单元格占的行数
     */
    private Integer rs;

    /**
     * 合并单元格占的列数
     */
    private Integer cs;
}
