package org.geely.pms_server.backend.core.model.luckysheet_operation.rowcolumn;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 行删除 或 列删除
 * t:drc
 * rc:r 或 c
 */
@Data
public class LSOperationRowOrColumnDel {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 详细信息
     */
    @JSONField(name = "v")
    private DelDetail value;

    @Data
    public class DelDetail {
        /**
         * 从第几行或者列开始删除
         */
        private Integer index;

        /**
         * 删除多少行或者列
         */
        private Integer len;
    }

    /**
     * 行操作还是列操作，值`r`代表行，`c`代表列
     */
    @JSONField(name = "rc")
    private String rowOrColumn;
}
