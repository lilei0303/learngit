package org.geely.pms_server.backend.core.entity.workbook;


import lombok.Getter;
import org.geely.pms_server.backend.core.entity.BaseEntity;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSWorkBook;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Getter
@Document(collection = "workbook")
public class WorkBookEntity extends BaseEntity {
    /**
     * 关联workbook
     */
    private LSWorkBook workBook;

    private Date lastUpdateTime;

    // Auto update lastUpdateTime on save
    public void setWorkBook(LSWorkBook workBook) {
        this.workBook = workBook;
        this.lastUpdateTime = new Date();
    }
}
