package org.geely.pms_server.backend.core.dto;

import com.alibaba.fastjson2.JSON;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.coyote.Response;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseWrapper<T> {
    boolean success;
    T data;
    String errorMessage;

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String toString() {
        return JSON.toJSONString(this);
    }

    static public <T> ResponseWrapper<T> success(T data) {
        return new ResponseWrapper<>(true, data, null);
    }

    static public <T> ResponseWrapper<T> failure(String errorMessage) {
        return new ResponseWrapper<>(false, null, errorMessage);
    }
}