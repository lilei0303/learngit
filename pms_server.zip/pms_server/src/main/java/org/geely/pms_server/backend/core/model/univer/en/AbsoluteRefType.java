package org.geely.pms_server.backend.core.model.univer.en;

public enum AbsoluteRefType {
    NONE,
    ROW,
    COLUMN,
    ALL
}
