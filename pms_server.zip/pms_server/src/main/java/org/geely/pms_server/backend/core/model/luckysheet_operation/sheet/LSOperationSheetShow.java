package org.geely.pms_server.backend.core.model.luckysheet_operation.sheet;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * sheet隐藏或显示
 * t:sh
 */
@Data
public class LSOperationSheetShow {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 如果hide为1则隐藏，为0或者空则为显示
     */
    @JSONField(name = "v")
    private Integer value;

    /**
     * 操作选项，有hide、show
     */
    @JSONField(name = "op")
    private String showOrHide;

    /**
     * 隐藏后设置索引对应cur的sheet为激活状态
     */
    @JSONField(name = "cur")
    private String activeIndex;
}
