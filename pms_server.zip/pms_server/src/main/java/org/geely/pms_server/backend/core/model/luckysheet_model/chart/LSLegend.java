package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSLegend implements Serializable {
    private Boolean show;

    private String selectMode;

    private List<LSSelect> selected;

    private LSLabel label;

    private LSPosition position;

    private LSWidth width;

    private LSWidth height;

    private LSDistance distance;

    private Integer itemGap;

    private List<String> data;
}
