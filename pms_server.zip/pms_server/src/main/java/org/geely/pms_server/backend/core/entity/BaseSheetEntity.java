package org.geely.pms_server.backend.core.entity;

import lombok.Data;
import org.springframework.data.annotation.Id;

import java.io.Serializable;

/**
 * 定义sheet基类
 */
@Data
public abstract class BaseSheetEntity implements Serializable, Comparable<BaseSheetEntity> {

    private static final long serialVersionUID = 1L;

    /**
     * 标识唯一Id
     */
    @Id
    private String id;

    /**
     * 配置sheet的顺序
     */
    private Integer order;

    /**
     * 设置子类关联的wbId或TemplateId
     *
     * @param id
     */
    public abstract void setBelongsId(String id);

    /**
     * 需要实现的方法，根据sheet的order字段实现升序排列
     *
     * @param o the object to be compared.
     * @return
     */
    @Override
    public int compareTo(BaseSheetEntity o) {
        return this.getOrder() - o.getOrder();
    }
}
