package org.geely.pms_server.backend.core.model.calculate;

import org.apache.poi.ss.usermodel.*;
import org.geely.pms_server.backend.core.model.luckysheet_model.LSSheet;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;
import org.geely.pms_server.backend.utils.SpringContextUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class LSFormulaEvaluator implements ILSFormulaEvaluator {
    static final Logger logger = LogManager.getLogger(LSFormulaEvaluator.class);

    WorkbookInit workbookInit() {
        return SpringContextUtil.getBean(WorkbookInit.class);
    }

    public double LSEvaluateInDouble(String workbookID, String lsSheetIndex, LSCell lsCell) {
        double cellValueInDouble = 0;
        LSCalculate(workbookID, lsSheetIndex, lsCell, cellValueInDouble);
        return cellValueInDouble;
    }

    public LSCell LSEvaluateInLSCell(String workbookID, String lsSheetIndex, LSCell lsCell) {

        double cellValueInDouble = 0;
        LSCalculate(workbookID, lsSheetIndex, lsCell, cellValueInDouble);
        return lsCell;
    }

    public void LSCalculate(String workbookID, String lsSheetIndex, LSCell lsCell, double cellValueInDouble) {
        //从全局变量InitWorkbook._workbook和InitWorkbook._lsWorkbook中根据传入lsSheet的索引找到所需sheet以及LSSheet
        LSSheet mySheet = workbookInit().getMyWorkBookByID(workbookID).getLSSheetsByIndex(lsSheetIndex).orElseThrow(() -> new RuntimeException("Sheet not found"));
        //sheet中的index即相当于lsSheet中的order
        int sheetIndex = mySheet.getOrder();
        Sheet sheet = workbookInit().getWorkbookByGridKey(workbookID).getSheetAt(sheetIndex);

        //当前单元格存在于Sheet表格中且公式合法
        if (mySheet.IsLSCellInSheet(lsCell) && isFormulaValid(lsCell)) {
            Cell cellToEvaluate = sheet.getRow(lsCell.getR()).getCell(lsCell.getC());//从当前Sheet中根据传入lsCell的行列获取单元格
            String poiFormula = lsCell.getV().getF().substring(1);

            cellToEvaluate.setCellFormula(poiFormula);//将传入lsCell中的公式赋给对应的cellFormula
//            logger.debug("lsCell.getV().getF() = " + lsCell.getV().getF());

            try {
                FormulaEvaluator evaluator = workbookInit().getWorkbookByGridKey(workbookID).getCreationHelper().createFormulaEvaluator();
//            CellValue cellValue = evaluator.evaluate(cellToEvaluate);//进行计算
                //evaluateFormulaCell计算完之后会将结果回填到计算使用到的单元格中，evaluate只计算结果不更改原单元格内容
                CellType cellType = evaluator.evaluateFormulaCell(cellToEvaluate);
//            logger.debug("cellValue = " + cellValue);

                //如果当前公式计算结果为数字类型
//            if (cellValue.getCellType() == CellType.NUMERIC) {
                if (cellType == CellType.NUMERIC) {
//                cellValueInDouble = cellValue.getNumberValue();//转成double类型
                    cellValueInDouble = cellToEvaluate.getNumericCellValue();//转成double类型
//                    logger.debug("line 50 cellValueInDouble = " + cellValueInDouble);
                    cellToEvaluate.setCellValue(cellValueInDouble);//将计算过后得到的结果赋给对应的cellValue
                    lsCell.getV().setV(String.valueOf(cellValueInDouble));//将计算过后得到的结果赋给传入lsCell中的value
                    lsCell.getV().setM(String.valueOf(cellValueInDouble));//将计算过后得到的结果赋给传入lsCell中的value
//                    logger.debug("line 53 lsCell.getV().getV() = " + lsCell.getV().getV());
//                    logger.debug("line 54 当前单元格公式计算过后的值为:" + cellValueInDouble + "\n");
                } else if (cellType == CellType.STRING){
                    //将计算过后得到的string类型结果写入到lsCell中的（如vlookUp函数）
//                lsCell.getV().setV(cellValue.getStringValue());
                    lsCell.getV().setV(cellToEvaluate.getStringCellValue());
                    lsCell.getV().setM(cellToEvaluate.getStringCellValue());
//                    logger.debug("line 59 lsCell.getV().getV() = " + lsCell.getV().getV());
//                    logger.debug("line 60 cellToEvaluate.getStringCellValue() = " + cellToEvaluate.getStringCellValue());
                }
            } catch (Exception e) {
                cellToEvaluate.setCellFormula(null);
                logger.debug("当前单元格包含公式不合法!");
            }
        } else {
            logger.debug("当前单元格不存在于lsSheet表格中或公式不合法!");
        }
    }

    public boolean isFormulaValid(LSCell lsCell) {
        if (lsCell.getV().getF() == null) {
//            logger.debug("当前单元格[" + lsCell.getR() + "," + lsCell.getC() + "]中不含公式！\n");
            return false;
        } else {
//            logger.debug("当前单元格[" + lsCell.getR() + "," + lsCell.getC() + "]公式合法");
            return true;
        }
    }
}
