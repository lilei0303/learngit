package org.geely.pms_server.backend.core.model.univer;

public class RangeLocation {
    private String unitId;
    private String sheetId;
}
