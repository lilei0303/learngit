package org.geely.pms_server.backend.core.model.luckysheet_operation.sheet;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 复制sheet
 * t:shc
 */
@Data
public class LSOperationCopySheet {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 详细信息
     */
    @JSONField(name = "v")
    private OpCopySheet value;

    @Data
    public class OpCopySheet {
        private String copyindex;
        private String name;
    }
}