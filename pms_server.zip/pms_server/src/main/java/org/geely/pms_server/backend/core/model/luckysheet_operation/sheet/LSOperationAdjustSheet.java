package org.geely.pms_server.backend.core.model.luckysheet_operation.sheet;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

import java.util.Map;

/**
 * 调整sheet位置
 * t:shr
 */
@Data
public class LSOperationAdjustSheet {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 设置Sheet的排序，为一个键值对，key代表sheet的index，
     * value代表order值。格式为：{"1": 3, "2":1, "0": 2, "3":0}
     */
    @JSONField(name = "v")
    private Map<String, Integer> value;
}