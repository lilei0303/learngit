package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.AlignTypeH;
import org.geely.pms_server.backend.core.model.univer.en.ObjectRelativeFromH;

public class ObjectPositionH {
    private ObjectRelativeFromH relativeFrom;
    private AlignTypeH align;
    private Double posOffset;
    private Double percent;

}
