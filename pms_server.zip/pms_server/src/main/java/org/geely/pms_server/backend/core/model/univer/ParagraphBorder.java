package org.geely.pms_server.backend.core.model.univer;

public class ParagraphBorder extends DocsBorder {
    Double padding;
}

