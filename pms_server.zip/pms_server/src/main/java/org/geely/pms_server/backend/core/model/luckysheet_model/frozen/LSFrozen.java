package org.geely.pms_server.backend.core.model.luckysheet_model.frozen;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;

import java.io.Serializable;

/**
 * 该类详细配置LSSheet类的frozen字段
 * 作用：冻结行列设置
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSFrozen implements Serializable {
    /**
     * "row": 冻结首行
     * "column": 冻结首列
     * "both": 冻结行列
     * "rangeRow": 冻结行到选区
     * "rangeColumn": 冻结列到选区
     * "rangeBoth": 冻结行列到选区
     * "cancel": 取消冻结
     */
    private String type;

    /**
     * 当设置冻结到选区的时候，需要设置开启冻结的单元格位置，格式为{ row_focus:0, column_focus:0 }，
     * 意为当前激活的单元格的行数和列数
     */
    private LSCellRangeItem range;
}
