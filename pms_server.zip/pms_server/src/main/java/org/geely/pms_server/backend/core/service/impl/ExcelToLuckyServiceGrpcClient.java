package org.geely.pms_server.backend.core.service.impl;

import com.google.protobuf.ByteString;
import jakarta.annotation.PostConstruct;
import luckyexcel.Luckyexcel;
import luckyexcel.PMSLuckyexcelServiceGrpc;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.geely.pms_server.backend.core.dto.ResponseWrapper;
import org.geely.pms_server.backend.core.service.IExcelToLuckyService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ExcelToLuckyServiceGrpcClient implements IExcelToLuckyService {

    @GrpcClient("PMSLuckyexcelService")
    private PMSLuckyexcelServiceGrpc.PMSLuckyexcelServiceBlockingStub luckyexcelService;

    @PostConstruct
    public void init() {
        luckyexcelService = luckyexcelService.withMaxInboundMessageSize(Integer.MAX_VALUE);
        luckyexcelService = luckyexcelService.withMaxOutboundMessageSize(Integer.MAX_VALUE);
    }

    /**
     * 将 Excel 文件转换为 Lucky 文件。
     *
     * @param excelFile 作为 InputStream 的输入 Excel 文件
     * @return 转换后的 Lucky 文件为字符串
     * @throws IOException 如果读取 Excel 文件时发生 I/O 错误
     * @throws ExcelConversionException 如果转换过程中出现错误
     */
    public String convertExcelToLucky(InputStream excelFile) throws IOException, ExcelConversionException {

        Luckyexcel.ConvertExcelToLuckyRequest request = Luckyexcel.ConvertExcelToLuckyRequest.newBuilder()
                .setExcelFile(ByteString.readFrom(excelFile))
                .build();
        Luckyexcel.ConvertExcelToLuckyResponse response = luckyexcelService.convertExcelToLucky(request);
        if (!response.getError().isEmpty()) {
            throw new ExcelConversionException(response.getError());
        }
        return response.getLuckyFile();
    }

    /**
     * 将 Excel 文件异步转换为 Lucky 文件。
     *
     * @param excelFile 作为 InputStream 的输入 Excel 文件
     * @return 一个 CompletableFuture，将转换后的 Lucky 文件作为字符串完成。
     * @throws IOException 如果读取 Excel 文件时发生 I/O 错误。
     * @throws ExcelConversionException 如果在转换过程中出现错误。
     */
    @Async
    public CompletableFuture<String> convertExcelToLuckyAsync(InputStream excelFile) throws ExcelConversionException, IOException {
        return CompletableFuture.completedFuture(convertExcelToLucky(excelFile));
    }
}
