package org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.dataverification.LSDataVerification;

import java.util.Map;

/**
 * 数据验证
 * t:dataVerification
 */
@Data
public class LSOperationDataVerification {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 参数
     */
    @JSONField(name = "v")
    private Map<String, LSDataVerification> value;
}
