package org.geely.pms_server.backend.core.model.luckysheet_model.image;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置ImageItem的crop字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCrop implements Serializable {
    /**
     * 图片裁剪后 宽度
     */
    private Integer width;

    /**
     * 图片裁剪后 高度
     */
    private Integer height;

    /**
     * 图片裁剪后离未裁剪时 左边的位移
     */
    private Integer offsetLeft;

    /**
     * 图片裁剪后离未裁剪时 顶部的位移
     */
    private Integer offsetTop;
}
