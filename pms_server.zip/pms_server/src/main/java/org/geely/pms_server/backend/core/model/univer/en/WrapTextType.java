package org.geely.pms_server.backend.core.model.univer.en;

public enum WrapTextType {
    BOTH_SIDES,
    LEFT,
    RIGHT,
    LARGEST,
}
