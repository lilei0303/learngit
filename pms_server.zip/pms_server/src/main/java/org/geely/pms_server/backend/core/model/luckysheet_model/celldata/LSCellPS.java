package org.geely.pms_server.backend.core.model.luckysheet_model.celldata;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置CellValue类的ps字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCellPS implements Serializable {

    /**
     * 批注框左边距
     */
    private Integer left;

    /**
     * 批注框上边距
     */
    private Integer top;

    /**
     * 批注框宽度
     */
    private Integer width;

    /**
     * 批注框高度
     */
    private Integer height;

    /**
     * 批准内容
     */
    private String value;

    /**
     * 批注框为显示状态
     */
    private Boolean isshow;
}