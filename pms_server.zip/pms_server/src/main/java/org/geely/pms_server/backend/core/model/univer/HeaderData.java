package org.geely.pms_server.backend.core.model.univer;

public class HeaderData {
    private String headerId;
    private DocumentBody body;
}
