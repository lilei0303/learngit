package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.AbsoluteRefType;
import org.geely.pms_server.backend.core.model.univer.en.RANGE_TYPE;

public class Range extends RangeLocation{
    private RANGE_TYPE rangeType;
    private AbsoluteRefType startAbsoluteRefType;
    private AbsoluteRefType endAbsoluteRefType;

    private Double startRow;
    private Double endRow;
    private Double startColumn;
    private Double endColumn;
}
