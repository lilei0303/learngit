package org.geely.pms_server.backend.core.model.univer.en;

public enum RANGE_TYPE {
    NORMAL,
    ROW,
    COLUMN,
    ALL
}
