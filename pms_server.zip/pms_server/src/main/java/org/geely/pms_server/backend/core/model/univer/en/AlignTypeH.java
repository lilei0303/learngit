package org.geely.pms_server.backend.core.model.univer.en;

public enum AlignTypeH {
    CENTER,
    INSIDE,
    LEFT,
    OUTSIDE,
    RIGHT,
    BOTH,
    DISTRIBUTE,
}
