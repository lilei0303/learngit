package org.geely.pms_server.backend.core.model.luckysheet_operation.functionchains;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.calcchain.LSFormula;

import java.util.List;

/**
 * 公式链
 * t:calcChain
 */
@Data
public class LSOperationCalcChain {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 公式链
     */
    @JSONField(name = "v")
    private List<LSFormula> value;
}
