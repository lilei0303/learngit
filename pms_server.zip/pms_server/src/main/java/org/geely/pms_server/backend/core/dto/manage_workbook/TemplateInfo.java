package org.geely.pms_server.backend.core.dto.manage_workbook;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TemplateInfo {
    private String title;
    private String gridKey;
}
