package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;
import org.geely.pms_server.backend.core.model.univer.en.CharacterSpacingControlType;

public class DocumentLayout {
    private Integer defaultTabStop; // 17.15.1.25 defaultTabStop (Distance Between Automatic Tab Stops)   0.5 in  = 36pt，this value should be converted to the default font size when exporting
    private CharacterSpacingControlType characterSpacingControl; // characterSpacingControl 17.18.7 ST_CharacterSpacing (Character-Level Whitespace Compression Settings)，default compressPunctuation
    private Double paragraphLineGapDefault; // paragraphLineGapDefault default line spacing
    private BooleanNumber spaceWidthEastAsian; // add space between east asian and English

    private BooleanNumber autoHyphenation; // 17.15.1.10 autoHyphenation (Automatically Hyphenate Document Contents When Displayed)
    private Integer consecutiveHyphenLimit; // 17.15.1.22 consecutiveHyphenLimit (Maximum Number of Consecutively Hyphenated Lines)
    private BooleanNumber doNotHyphenateCaps; // 17.15.1.37 doNotHyphenateCaps (Do Not Hyphenate Words in ALL CAPITAL LETTERS)
    private Integer hyphenationZone; // 17.15.
}
