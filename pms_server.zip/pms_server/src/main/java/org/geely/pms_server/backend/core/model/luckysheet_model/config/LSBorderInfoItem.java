package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;

import java.io.Serializable;
import java.util.List;

/**
 * 该类详细配置Config类的borderInfo字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSBorderInfoItem implements Serializable {
    /**
     * 范围类型分单个单元格和选区两种情况
     */
    private String rangeType;

    /**
     * rangeType："cell"
     */
    private LSValue value;

    /**
     * rangeType："range"
     * 边框类型 borderType："border-left" | "border-right" | "border-top" | "border-bottom" |
     * "border-all" | "border-outside" | "border-inside" | "border-horizontal" | "border-vertical" | "border-none"
     */
    private String borderType;

    /**
     * 边框粗细 style: 1 Thin | 2 Hair | 3 Dotted | 4 Dashed | 5 DashDot | 6 DashDotDot | 7 Double | 8 Medium |
     * 9 MediumDashed | 10 MediumDashDot | 11 MediumDashDotDot | 12 SlantedDashDot | 13 Thick
     */
    private String style;

    /**
     * 边框颜色
     */
    private String color;

    /**
     * 选区范围 行列信息数组
     */
    private List<LSCellRangeItem> range;
}
