package org.geely.pms_server.backend.core.model.luckysheet_operation;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;

import java.util.List;

/**
 * 聚焦
 * t:mv
 */
@Data
@AllArgsConstructor
public class LSOperationMv {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 选中区域
     */
    @JSONField(name = "v")
    private OpDetail value;

    @Data
    public static class OpDetail {
        private String op;
        private List<LSCellRangeItem> range;
    }
}
