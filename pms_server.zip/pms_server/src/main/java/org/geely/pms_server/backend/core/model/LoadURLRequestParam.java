package org.geely.pms_server.backend.core.model;

import lombok.Data;

@Data
public class LoadURLRequestParam {
    private String gridKey;
    private Integer rows;
}
