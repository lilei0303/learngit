package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

public class TextRotation {
    private Double a;
    private BooleanNumber v;
}
