package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.ContentAlignment;

public class TableCellStyle {
    private Integer rowSpan; // rowSpan
    private Integer columnSpan; // columnSpan
    private ColorStyle backgroundColor; // backgroundColor
    private TableCellBorder borderLeft; // borderLeft
    private TableCellBorder borderRight; // borderRight
    private TableCellBorder borderTop; // borderTop
    private TableCellBorder borderBottom; // borderBottom
    private Double paddingLeft; // paddingLeft
    private Double paddingRight; // paddingRight
    private Double paddingTop; // paddingTop
    private Double paddingBottom; // paddingBottom
    private ContentAlignment contentAlignment; // conten
}
