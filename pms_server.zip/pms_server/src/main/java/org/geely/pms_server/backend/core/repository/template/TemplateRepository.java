package org.geely.pms_server.backend.core.repository.template;

import org.geely.pms_server.backend.core.entity.template.TemplateEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TemplateRepository extends MongoRepository<TemplateEntity, String> {
}
