package org.geely.pms_server.backend.core.model.luckysheet_model.alternateformat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 该类详细配置AlternateFormat类的format字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSFormatItem implements Serializable {

    private String fc;

    private String bc;

}
