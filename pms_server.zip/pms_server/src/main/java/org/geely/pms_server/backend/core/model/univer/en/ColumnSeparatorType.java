package org.geely.pms_server.backend.core.model.univer.en;

public enum ColumnSeparatorType {
    COLUMN_SEPARATOR_STYLE_UNSPECIFIED, // An unspecified column separator style.
    NONE, // No column separator lines between columns.
    BETWEEN_EACH_COLUMN, // Renders a column separator line between each column.
}
