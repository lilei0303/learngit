package org.geely.pms_server.backend.core.model.univer.en;

import lombok.Getter;

@Getter
public enum DrawingType {
    UNRECOGNIZED(-1),
    DRAWING_IMAGE(0),
    DRAWING_SHAPE(1),
    DRAWING_CHART(2),
    DRAWING_TABLE(3),
    DRAWING_SMART_ART(4),
    DRAWING_VIDEO(5),
    DRAWING_GROUP(6),
    DRAWING_UNIT(7),
    DRAWING_DOM(8);
    private final int value;

    DrawingType(int value) {
        this.value = value;
    }

    public static DrawingType fromInt(int value) {
        for (DrawingType type : values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return UNRECOGNIZED;
    }
}
