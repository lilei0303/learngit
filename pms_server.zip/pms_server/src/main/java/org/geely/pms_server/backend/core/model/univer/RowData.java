package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;

public class RowData {
    private Double h; // height in pixel
    // is current row self-adaptive to its content, use `ah` to set row height when true, else use `h`.
    private BooleanNumber ia;
    private Double ah; // auto height
    private BooleanNumber hd; // hidden
}
