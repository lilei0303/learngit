package org.geely.pms_server.backend.core.model.formulaChain;

import cn.hutool.core.lang.Pair;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.formula.EvaluationWorkbook;
import org.apache.poi.ss.formula.FormulaParser;
import org.apache.poi.ss.formula.FormulaParsingWorkbook;
import org.apache.poi.ss.formula.FormulaType;
import org.apache.poi.ss.formula.ptg.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellReference;
import org.geely.pms_server.backend.core.model.calculate.WorkbookInit;
import org.geely.pms_server.backend.utils.CellUtility;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@NoArgsConstructor
//@Data
//@AllArgsConstructor
public class FormulaChainManager {
    static final Logger logger = LogManager.getLogger(FormulaChainManager.class);
    public FormulaChain formulaChain = new FormulaChain();
    private String _workBookID;

    public FormulaChainManager(String workBookID) {
        _workBookID = workBookID;
    }

    // 广度优先遍历
    public List<FormulaNode> updateCellNode(Cell cell, int sheetOrder, boolean isPresentNodeBackendFormula, String sheetIndex, EvaluationWorkbook evalWorkbook, String sheetName) {
        boolean isBackendCalculate = isPresentNodeBackendFormula;

        //本次更新单元格操作引起的所要修改的公式链上的结点
        List<FormulaNode> nodesToUpdate = new ArrayList<>();

        String originCellNodeName = new CellReference(cell).formatAsString();
//        String originCellNodeName = new CellReference(cell.getRowIndex(), cell.getColumnIndex()).formatAsString();
        //如果更新的单元格属于公式链
        if (formulaChain.containsKey(originCellNodeName)) {
            List<FormulaNode> formulaNodes = updateCellNodeBFS(originCellNodeName, sheetOrder, isPresentNodeBackendFormula,false, evalWorkbook, sheetName);
            if (formulaNodes != null) {
                nodesToUpdate = formulaNodes;
                isBackendCalculate = true;
            }
        }

        //如果更新之后的单元格仍为一个公式，则为其新的前置依赖添加后置依赖
        if (cell.getCellType().equals(CellType.FORMULA)) {
            if (addNewLatterDependencies(cell, isPresentNodeBackendFormula, sheetIndex, evalWorkbook, sheetName, sheetOrder)) {
                isBackendCalculate = true;
            }
            FormulaNode formulaNode = formulaChain.getKey(originCellNodeName);
//            logger.debug("formulaNode = " + formulaNode);
            if (formulaNode != null) {
                formulaNode.set_isBackendCalculate(isBackendCalculate);
                formulaNode.set_isBackendFormula(isPresentNodeBackendFormula);
            }else {
                formulaNode = new FormulaNode(originCellNodeName, isPresentNodeBackendFormula, isBackendCalculate, sheetIndex);
            }
            if (formulaChain.getFormulaNode(originCellNodeName) == null) {
//                formulaChain.getFormulaNodeSets().add(formulaNode);
//                logger.debug("添加成功！");
//                logger.debug("formulaChain.getFormulaNode(formulaNode.getCellNodeName()) = " + formulaChain.getFormulaNode(formulaNode.getCellNodeName()));
            } else {
                formulaChain.getFormulaNode(originCellNodeName).set_isBackendFormula(isPresentNodeBackendFormula);
                formulaChain.getFormulaNode(originCellNodeName).set_isBackendCalculate(isBackendCalculate);
            }
            //如果formulaNodeMap没有当前结点则将其添加,否则结点出现次数+1
            formulaChain.getFormulaNodeMap().put(formulaNode,1);
        }
        if (isBackendCalculate) {
//            nodesToUpdate.add(new FormulaNode(cell, isPresentNodeBackendFormula));
            return nodesToUpdate;
        } else {
            return null;
        }
    }

    public List<FormulaNode> updateCellNodeBFS(String originCellNodeName, int sheetOrder, boolean isPresentNodeBackendFormula,boolean isDeleteOperation, EvaluationWorkbook evalWorkbook,
                                               String sheetName) {
        //更新队列
        Queue<String> queue = new LinkedList<>();
        //已访问过的结点添加至列表
        List<FormulaNode> visited = new ArrayList<FormulaNode>() {
            @Override
            public boolean contains(Object o) {
                if (o instanceof String childCellNodeName) {
                    for (FormulaNode node : this) {
                        if (node.getCellNodeName().equals(childCellNodeName)) {
                            return true;
                        }
                    }
                }
                return false;
            }
        };

//        Set<String> visited = new HashSet<>();

        //将起始节点 originCellNodeName 入队列，并标记为已访问
        //起始结点不需要更新内存中的POI工作簿和lucky工作簿
        queue.offer(originCellNodeName);
//        visited.add(originCellNodeName);

        FormulaNode originNode = formulaChain.getFormulaNode(originCellNodeName);
//        logger.debug("originNode = " + originNode);
        boolean isBackendCalculate = isPresentNodeBackendFormula || originNode.is_isBackendCalculate();

        //在每一轮循环中，从队列中取出一个节点，遍历其相邻节点并进行处理
        while (!queue.isEmpty()) {
            String presentCellNodeName = queue.poll();
            HashSet<FormulaNode> presentNodesSet = formulaChain.get(presentCellNodeName);

//            if (presentNodesSet != null) {
            for (FormulaNode presentNode : presentNodesSet) {
                String childCellNodeName = presentNode.getCellNodeName();
                //不是公式链中最后一个节点
                if (formulaChain.get(childCellNodeName) != null) {
                    queue.offer(childCellNodeName);
                } else {
                    //如果最后一个节点的所有前置依赖都已更新完毕x
                    if (true) {
//                        logger.debug(childCellNodeName + "：当前结点为公式链中最后一个结点");
//                        logger.debug("此处要对当前结点进行更新");
                    }
                }
                //更新内存中的POI工作簿和lucky工作簿

                Optional<Pair<CellType, Cell>> cellTypeCellPair = WorkbookInit.calculateInFormulaChain(_workBookID, presentNode.get_sheetIndex(), presentNode.getRow(), presentNode.getColumn());

                if (!cellTypeCellPair.isEmpty()){
                    if (cellTypeCellPair.get().getKey() == CellType.NUMERIC) {
                        presentNode.setCellValue(String.valueOf(cellTypeCellPair.get().getValue().getNumericCellValue()));
                    } else if (cellTypeCellPair.get().getKey() == CellType.STRING){
                        presentNode.setCellValue(cellTypeCellPair.get().getValue().getStringCellValue());
                    }
                }

                //如果本次操作为删除操作，则需进行判断是否将当前单元格的所有后置依赖单元格isBackendCalculate设置为false
//                if (isDeleteOperation) {
//                    //当前单元格的当前后置依赖的所有前置依赖,如果所有前置依赖的isBackendCalculate均为false，那么才将当前单元格的isBackendCalculate设为false
//                    List<String> strings = extractCellNames(childCellNodeName);
//                    boolean isPresentNodeBackendCalculate = false;
//                    for (String name : strings) {
//                        if (formulaChain.getFormulaNode(name).is_isBackendCalculate()) {
//                            isPresentNodeBackendCalculate = true;
//                        }
//                    }
//                    presentNode.set_isBackendCalculate(isPresentNodeBackendCalculate);
//                    formulaChain.getFormulaNode(childCellNodeName).set_isBackendCalculate(false);
//                    formulaChain.getFormulaNodeMap().put(presentNode, -1);
//                }

                if (!visited.contains(childCellNodeName)) {
                    visited.add(presentNode);
                }
                //只要公式链上有一个结点为后端公式，那么就需要发送给前端更新
                if (presentNode.is_isBackendCalculate()) {
                    isBackendCalculate = true;
                }

                //如果本次操作为删除操作，则需进行判断是否将当前单元格的所有后置依赖单元格isBackendCalculate设置为false
                if (isDeleteOperation) {
                    //当前单元格的当前后置依赖的所有前置依赖,如果所有前置依赖的isBackendCalculate均为false，那么才将当前单元格的isBackendCalculate设为false
                    HashSet<String> strings = CellUtility.extractCellNameInFormula(presentNode.getFormula(),evalWorkbook,sheetName,sheetOrder);
                    boolean isPresentNodeBackendCalculate = false;
                    for (String name : strings) {
                        if (formulaChain.getFormulaNode(name) != null && formulaChain.getFormulaNode(name).is_isBackendCalculate()) {
                            isPresentNodeBackendCalculate = true;
                        }
                    }
                    presentNode.set_isBackendCalculate(isPresentNodeBackendCalculate);
                    formulaChain.getFormulaNode(childCellNodeName).set_isBackendCalculate(false);
                    formulaChain.getFormulaNodeMap().putValue(presentNode, -1);

                    //将初始删除的单元格设置为false
                    originNode.set_isBackendCalculate(false);
                    originNode.set_isBackendFormula(false);
                }
            }
//            }
            //最后一个节点不需要入队列
//            else {
//                //如果最后一个节点的所有前置依赖都已更新完毕
//                logger.debug(presentCellNodeName + "：当前结点为公式链中最后一个结点");
//                logger.debug("此处要对当前结点进行更新");
//            }
        }

        if (isBackendCalculate) {
            return visited;
        } else {
            return null;
        }
    }

    public void updateCellNodeDFS(String originCellNodeName) {
        HashSet<FormulaNode> originNodesSet = formulaChain.get(originCellNodeName);
        Iterator<FormulaNode> iterator = originNodesSet.iterator();
        while (iterator.hasNext()) {
            FormulaNode presentNode = iterator.next();
            String presentCellNodeName = presentNode.getCellNodeName();
            HashSet<FormulaNode> presentNodesSet = formulaChain.get(presentCellNodeName);
            if (presentNodesSet != null) {
//                logger.debug(presentCellNodeName + "：当前结点在公式链中的前置依赖已经更新完毕");
//                logger.debug("此处要对当前结点进行更新");
                updateCellNodeDFS(presentCellNodeName);
            } else {
//                logger.debug(presentCellNodeName + "：当前结点为公式链中最后一个结点");
//                logger.debug("此处要对当前结点进行更新");
            }
        }
    }

    //删除从最后一个节点开始删除
//    public void deleteCellNode(String originCellNodeName){
//        HashSet<FormulaNode> originNodesSet = formulaChain.get(originCellNodeName);
//        Iterator<FormulaNode> iterator = originNodesSet.iterator();
//        while (iterator.hasNext()){
//            FormulaNode presentNode = iterator.next();
//            String presentCellNodeName = presentNode.getCellNodeName();
//            HashSet<FormulaNode> presentNodesSet = formulaChain.get(presentCellNodeName);
//            if (presentNodesSet != null) {
//                deleteCellNode(presentCellNodeName);
//            }
//            logger.debug(presentCellNodeName + "：当前结点在公式链中已经无后置依赖");
//            logger.debug("此处要对当前结点进行删除");
//        }
//    }

    //更新或删除单元格时调用，更新其前置依赖
    public void updateFormerDependencies(String cellNodeName, String formula, EvaluationWorkbook evaluationWorkbook, String sheetName, int sheetOrder) {
        //解析当前单元格公式，获取其前置依赖单元格
//        List<String> formerDependenciesNames = extractFormulaNames(formula);
        HashSet<String> formerDependenciesNames = CellUtility.extractCellNameInFormula(formula,evaluationWorkbook,sheetName,sheetOrder);

        //这里需要加一步判断，即单元格刷新不一定直接删除其前置依赖的后置依赖，而要判断更新之后的公式内容是否发生改变
        for (String tempName : formerDependenciesNames) {
            if (formulaChain.containsKey(tempName)) {
//                HashSet<FormulaNode> formulaNodes = formulaChain.get(tempName);
//                for (FormulaNode formulaNode : formulaNodes) {
//                    if (formulaNode.getCellNodeName().equals(cellNodeName)) {
//                        formulaNodes.remove(formulaNode);
//                        logger.debug(cellNodeName + "已被" + tempName + "删除");
//                        break; // 删除第一个匹配项后退出循环
//                    }
//                }

                HashSet<FormulaNode> formulaNodes = formulaChain.get(tempName);
//                HashSet<FormulaNode> nodesToRemove = new HashSet<>();
//                for (FormulaNode formulaNode : formulaNodes) {
//                    if (formulaNode.getCellNodeName().equals(cellNodeName)) {
////                        nodesToRemove.add(formulaNode);
//                        logger.debug("formulaNodes = " + formulaNodes);
//                        formulaNodes.remove(formulaNode);
//                        logger.debug("\nformulaNode = " + formulaNode);
//                        logger.debug("formulaNodes = " + formulaNodes);
//                        logger.debug("\n" + cellNodeName + "已被" + tempName + "删除");
//                        break;
//                    }
//                }
//                formulaNodes.removeAll(nodesToRemove);
//                formulaChain.put(tempName, formulaNodes); // 将更新后的 formulaNodes 放回 formulaChain

                Iterator<FormulaNode> iterator = formulaNodes.iterator();
                while (iterator.hasNext()) {
                    FormulaNode formulaNode = iterator.next();
                    if (formulaNode.getCellNodeName().equals(cellNodeName)) {
                        iterator.remove(); // 使用迭代器来安全移除元素
//                        logger.debug("\n" + cellNodeName + "已被" + tempName + "删除");
                        break;
                    }
                }

                //说明当前公式链结点一个后置依赖也没有了，应当从公式链中将这个结点进行删除
//                logger.debug("tempName = " + tempName + "formulaChain.get(tempName) = " + formulaChain.get(tempName));
                if (formulaChain.get(tempName) == null || formulaChain.get(tempName).isEmpty()) {
                    formulaChain.removeByCellNodeName(tempName);
                    formulaChain.getFormulaNodeMap().putValue(formulaChain.getFormulaNode(tempName), -1);
                }
            }
        }
    }

    //    public Map<String, HashSet<FormulaNode>> getAllFormulaChain() {
    public Map<FormulaNode, HashSet<FormulaNode>> getAllFormulaChain() {
        logger.debug("--------------------------------打印当前公式链:");
        formulaChain.forEach((k, v) -> logger.debug("结点名称:" + k + " 结点的后置依赖:" + v));
        return formulaChain;
    }

    public void getFormulaChain() {
        for (FormulaNode key : formulaChain.keySet()) {
            logger.debug("结点名称: " + key.getCellNodeName() + " isBackendCalculate:" + key.is_isBackendCalculate() + " isBackendFormula:" + key.is_isBackendFormula() + " 结点的后置依赖:");
            HashSet<FormulaNode> formulaNodes = formulaChain.get(key.getCellNodeName());
              if (formulaNodes != null){
                  for (FormulaNode formulaNode : formulaNodes) {
                      logger.debug(formulaNode.getCellNodeName() + "(isBackendCalculate:" + formulaNode.is_isBackendCalculate() + " isBackendFormula:" + formulaNode.is_isBackendFormula()  + ") ");
                  }
              }
        }
    }

    //新建公式链
    //当有公式链中有新的结点加入时，要检查该公式中包含哪些单元格，并为这些单元格新增后置依赖
    public boolean addNewLatterDependencies(Cell cell, boolean isBackendFormula, String sheetIndex, EvaluationWorkbook evaluationWorkbook, String sheetName, int sheetOrder) {
        //传入的单元格，即所要更新的包含公式的单元格，是否要设置成isBackendCalculate
        boolean isBackendCalculate = isBackendFormula;

//        String presentCellNodeName = new CellReference(cell.getRowIndex(), cell.getColumnIndex()).formatAsString();
        String presentCellNodeName = new CellReference(cell).formatAsString();
        //解析当前单元格公式，获取其前置依赖单元格
//        List<String> formerDependenciesNames = extractFormulaNames(cell.getCellFormula());
        HashSet<String> formerDependenciesNames = CellUtility.extractCellNameInFormula(cell.getCellFormula(), evaluationWorkbook, sheetName, sheetOrder);
        FormulaNode formulaNode = new FormulaNode(cell, isBackendFormula, sheetIndex);
//        logger.debug("当前单元格的前置依赖有:");
//        logger.debug("formerDependenciesNames = " + formerDependenciesNames);

        //为其前置依赖单元格添加后置依赖
        //遍历其前置依赖单元格，查找当前单元格是否在公式链中
        //若存在，则直接添加后置依赖
        //否则先在公式链中添加
        for (String tempName : formerDependenciesNames) {
            // 检查 formulaChain 的 key 是否包含 tempName
            if (formulaChain.containsKey(tempName)) {
                // 如果包含，则在对应的 value 中添加 formulaNode
                //添加后置依赖之前，先检查当前结点是否已经是它的后置依赖
                if (!isLatterDependenciesAdded(presentCellNodeName, tempName)) {
                    formulaChain.get(tempName).add(formulaNode);
                }
//                logger.debug("presentCellNodeName:" + presentCellNodeName + " tempName:" + tempName);
                if (formulaChain.getPresentNodeIsBackendCalculate(tempName)) {
                    isBackendCalculate = true;
                }
            } else {
                // 如果不包含，则在 formulaChain 中新增一对键值对 <tempName, HashSet<FormulaNode>>
//                formulaChain.put(tempName, formulaNodes);
                FormulaNode node = formulaChain.getFormulaNode(tempName);
//                logger.debug("node = " + node + " tempName = " + tempName);
                if (node == null) {
                    node = (new FormulaNode(tempName, false, false, sheetIndex));
                }
                //如果前置依赖不存在公式链当中，且isBackendCalculate||isBackendFormula为真，则当前单元格的isBackendCalculate也应为T
                if (node.is_isBackendCalculate() || node.is_isBackendFormula()) {
                    isBackendCalculate = true;
                }
                HashSet<FormulaNode> formulaNodes = new HashSet<>();
                //这里的formulaNode是所要添加的后置依赖，也就是当前单元格，添加为后置依赖前需要对其isBackendCalculate进行更新
                formulaNode.set_isBackendCalculate(isBackendCalculate);
                formulaNodes.add(formulaNode);
                formulaChain.getFormulaNodeMap().put(node,1);
                formulaChain.put(node, formulaNodes);
            }
        }
        //如果前置依赖中有某个依赖的isBackendCalculate为true，则要将当前单元格的isBackendCalculate同样设置为T
        FormulaNode presentNode = formulaChain.getFormulaNode(presentCellNodeName);
        if (presentNode != null) {
//            logger.debug("presentNode != null  " + presentNode);
            formulaChain.getFormulaNode(presentCellNodeName).set_isBackendCalculate(isBackendCalculate);
        }
//        getFormulaChain();

        return isBackendCalculate;
    }

    //检查当前结点是否已经是它的后置依赖
    public boolean isLatterDependenciesAdded(String presentCellNodeName, String tempName) {
        HashSet<FormulaNode> formulaNodes = formulaChain.get(tempName);
        for (FormulaNode node : formulaNodes) {
            if (node.getCellNodeName().equals(presentCellNodeName)) {
                return true;
            }
        }
        return false;
    }

    public List<String> extractFormulaNames(String input) {
        Set<String> cellNames = new HashSet<>(); // 使用Set来实现去重

        Pattern pattern = Pattern.compile("[A-Za-z]+\\d+(:[A-Za-z]+\\d+)?");
        Matcher matcher = pattern.matcher(input);

        while (matcher.find()) {
            String match = matcher.group();
            if (match.contains(":")) {
                String[] range = match.split(":");
                String startCell = range[0];
                String endCell = range[1];

                String[] startParts = splitCellName(startCell);
                String[] endParts = splitCellName(endCell);

                int startRow = Integer.parseInt(startParts[1]);
                int endRow = Integer.parseInt(endParts[1]);
                char startColumn = startParts[0].charAt(0);
                char endColumn = endParts[0].charAt(0);

                for (char column = startColumn; column <= endColumn; column++) {
                    for (int row = startRow; row <= endRow; row++) {
                        cellNames.add(Character.toString(column) + row);
                    }
                }
            } else {
                cellNames.add(match);
            }
        }
        return new ArrayList<>(cellNames); // 将Set转换回List返回
    }

    private String[] splitCellName(String input) {
        Pattern pattern = Pattern.compile("([A-Za-z]+)(\\d+)");
        Matcher matcher = pattern.matcher(input);
        if (matcher.find()) {
            String column = matcher.group(1);
            String row = matcher.group(2);
            return new String[]{column.toUpperCase(), row}; // 将列名转换为大写
        } else {
            return new String[0];
        }
    }

    public void updateFormulaChainNodeName(String oldSheetName, String newSheetName) {
//        System.out.println("更新公式链名称之前:");
//        getFormulaChain();

        // 遍历 formulaChain 中的所有键值对
        for (Map.Entry<FormulaNode, HashSet<FormulaNode>> entry : formulaChain.entrySet()) {
            // 获取当前的键（FormulaNode）
            FormulaNode keyNode = entry.getKey();
            // 检查并更新键节点
            updateNodeIfRequired(keyNode, oldSheetName, newSheetName);

            // 获取当前键对应的值（HashSet<FormulaNode>）
            HashSet<FormulaNode> valueSet = entry.getValue();
            // 遍历并更新值集合中的每个节点
            for (FormulaNode node : valueSet) {
                updateNodeIfRequired(node, oldSheetName, newSheetName);
            }
        }

        for (FormulaNode node : formulaChain.getFormulaNodeMap().keySet()) {
            updateNodeIfRequired(node, oldSheetName, newSheetName);
        }

        System.out.println("修改sheetName，打印新的公式链");
//        getFormulaChain();
    }

    private void updateNodeIfRequired(FormulaNode node, String oldSheetName, String newSheetName) {
        if (node.getSheetName().equals(oldSheetName)) {
            node.setNewCellNodeNameByNewSheetName(newSheetName);
//            System.out.println("node.getCellNodeName() = " + node.getCellNodeName());
        }
    }
}
