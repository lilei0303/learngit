package org.geely.pms_server.backend.core.model.univer.en;

import lombok.Getter;

@Getter
public enum LocaleType {
    EN_US("enUS"),
    ZH_CN("zhCN"),
    RU_RU("ruRU"),
    ZH_TW("zhTW"),
    VI_VN("viVN");

    private final String value;

    LocaleType(String value) {
        this.value = value;
    }

    // Optional: Method to convert string to enum
    public static LocaleType fromString(String text) {
        for (LocaleType b : LocaleType.values()) {
            if (b.value.equalsIgnoreCase(text)) {
                return b;
            }
        }
        return null; // Or throw an exception
    }
}