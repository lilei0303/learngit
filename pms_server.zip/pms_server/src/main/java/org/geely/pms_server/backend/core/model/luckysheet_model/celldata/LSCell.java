package org.geely.pms_server.backend.core.model.luckysheet_model.celldata;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.calcChain.CalcNode;

import java.io.Serializable;
import java.util.Objects;

/**
 * 该类详细配置LSSheet类的celldata字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSCell implements Serializable, Cloneable {
    /**
     * 行
     */
    private Integer r;

    /**
     * 列
     */
    private Integer c;


    //自定义 当前单元格所属Sheet的Index
    @JsonIgnore
    private String sheetIndex;

    /**
     * 单元格值
     */
    @JsonProperty(required = true)
    private LSCellValue v;

    public LSCell(Integer r, Integer c, LSCellValue v) {
        this.r = r;
        this.c = c;
        this.v = v;
    }

    public LSCell(int r, int c) {
        this.r = r;
        this.c = c;
    }

    public LSCell(int r, int c, double v) {
        this.r = r;
        this.c = c;
        if (this.v == null) {
            this.v = new LSCellValue();
        }
        this.v.setV(String.valueOf(v));
    }

    public LSCell(int r, int c, String formula) {
        this.r = r;
        this.c = c;
        if (this.v == null) {
            this.v = new LSCellValue();
        }
        this.v.setF(formula);
    }

    public LSCell(int r, int c, double numberValue, String formula) {
        this.r = r;
        this.c = c;
        if (this.v == null) {
            this.v = new LSCellValue();
        }
        this.v.setV(String.valueOf(numberValue));
        this.v.setF(formula);
    }

    public LSCell(int r, int c, String stringValue, String formula) {
        this.r = r;
        this.c = c;
        if (this.v == null) {
            this.v = new LSCellValue();
        }
        this.v.setV(stringValue);
        this.v.setF(formula);
    }

    @Override
    public LSCell clone() {
        try {
            LSCell cloned = (LSCell) super.clone();
            cloned.r = this.r;
            cloned.c = this.c;
            cloned.v = this.v;
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    // 重写equals方法
    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || getClass() != object.getClass()) {
            return false;
        }
        LSCell other = (LSCell) object;
        return r == other.r && c == other.c && Objects.equals(sheetIndex, other.getSheetIndex());
    }

    @Override
    public int hashCode() {
        return Objects.hash(r, c, sheetIndex);
    }
}
