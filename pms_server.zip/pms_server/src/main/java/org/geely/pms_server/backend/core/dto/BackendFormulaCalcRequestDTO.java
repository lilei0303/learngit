package org.geely.pms_server.backend.core.dto;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;
import org.geely.pms_server.backend.core.model.luckysheet_model.celldata.LSCell;

@Data
public class BackendFormulaCalcRequestDTO {
    @JSONField(required = true)
    private String userId;
    @JSONField(required = true)
    private String gridKey;
    @JSONField(required = true)
    private String index;
    @JSONField(required = true)
    private Integer r;
    @JSONField(required = true)
    private Integer c;
}
