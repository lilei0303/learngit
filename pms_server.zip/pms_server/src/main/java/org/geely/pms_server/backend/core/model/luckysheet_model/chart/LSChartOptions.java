package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import com.alibaba.fastjson2.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.geely.pms_server.backend.core.model.luckysheet_model.conditionformat.LSCellRangeItem;

import java.io.Serializable;

/**
 * 该类详细配置Chart类的chartOptions字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSChartOptions implements Serializable {

    private String chart_id;

    private String chartAllType;

    private LSCellRangeItem rangeArray;

    private LSRangeCheck rangeColCheck;

    private LSRangeCheck rangeRowCheck;

    private Boolean rangeConfigCheck;

    //    private DefaultOption defaultOption;
    private JSONObject defaultOption;
}
