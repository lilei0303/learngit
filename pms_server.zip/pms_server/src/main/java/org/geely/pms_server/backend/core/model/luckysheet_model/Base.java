package org.geely.pms_server.backend.core.model.luckysheet_model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Base implements Serializable {
    /**
     * 表格唯一标识符
     */
    private String gridKey;

    /**
     * 工作簿名称
     */
    private String title;

    /**
     * 国际化设置，允许设置表格的语言，支持简体中文("zh")、英文("en")、繁体中文("zh_tw")和西班牙文("es")
     */
    private String lang = "zh";

    /**
     * 文档内所有工作表
     */
    private List<LSSheet> sheets = new ArrayList<>();
}
