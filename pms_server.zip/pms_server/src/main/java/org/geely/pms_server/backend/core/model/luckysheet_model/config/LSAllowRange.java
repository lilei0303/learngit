package org.geely.pms_server.backend.core.model.luckysheet_model.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 区域保护
 * 该类详细配置Authority的allowRangeList字段
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSAllowRange implements Serializable {
    /**
     * 名称
     */
    private String name;

    /**
     * 密码
     */
    private String password;

    /**
     * 提示文字
     */
    private String hintText;

    /**
     * 加密方案：MD2,MD4,MD5,RIPEMD-128,RIPEMD-160,SHA-1,SHA-256,SHA-384,SHA-512,WHIRLPOOL
     */
    private String algorithmName;

    /**
     * 密码解密的盐参数，为一个自己定的随机数值
     */
    private String saltValue;

    /**
     * 区域范围
     */
    private String sqref;
}
