package org.geely.pms_server.backend.core.model.luckysheet_operation.universalstorage;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 修改工作表名称
 * t:name
 */
@Data
public class LSOperationSetSheetName {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 新的工作簿名称
     */
    @JSONField(name = "v")
    private String value;
}
