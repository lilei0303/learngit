package org.geely.pms_server.backend.core.model.univer;

public class Shading {
    ColorStyle backgroundColor;
}
