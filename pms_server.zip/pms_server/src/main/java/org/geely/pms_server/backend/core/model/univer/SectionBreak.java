package org.geely.pms_server.backend.core.model.univer;

public class SectionBreak extends DocStyleBase{
    private Double startIndex;
}
