package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.CustomRangeType;

public class CustomRange {
    private int startIndex;
    private int endIndex;
    private String rangeId;
    private CustomRangeType rangeType;
    private Boolean wholeEntity; // Nullable boolean t
}
