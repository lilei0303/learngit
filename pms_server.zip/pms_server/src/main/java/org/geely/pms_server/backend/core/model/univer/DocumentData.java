package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.LocaleType;

import java.util.List;

public class DocumentData extends ReferenceSource{
    /**
     * unit ID
     */
    private String id;
    /**
     * Revision of this document. Would be used in collaborated editing. Starts with zero.
     */
    private Double rev;
    private LocaleType locale;
    private String title;
    private DocumentBody body;
    private DocumentStyle documentStyle;
    private DocumentSettings settings;
    // The type of data depends on how the plug-in is defined
    private List<MyOptions> resources;
    private boolean disabled;

    private Boolean shouldStartRenderingImmediately;
    private String container;
}
