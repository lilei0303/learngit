package org.geely.pms_server.backend.core.controller;

import jakarta.annotation.Resource;
import org.geely.pms_server.backend.core.dto.ResponseWrapper;
import org.geely.pms_server.backend.core.dto.manage_template.LoadTemplateParam;
import org.geely.pms_server.backend.core.dto.manage_workbook.TemplateInfo;
import org.geely.pms_server.backend.core.dto.manage_workbook.WorkbookDeletionResult;
import org.geely.pms_server.backend.core.model.template_model.Template;
import org.geely.pms_server.backend.core.service.IDbTemplateProcessor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping(value = "/api/v1/template")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE})
public class TemplateManageController {
    @Resource
    IDbTemplateProcessor templateDbProcessor;

    @PostMapping(value = "/loadTemplate", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseWrapper<Template> loadTemplate(
            LoadTemplateParam param
    ) {
        try {
            Template template = templateDbProcessor.loadTemplate(param.getGridKey());
            return ResponseWrapper.success(template);
        } catch (Exception error) {
            return ResponseWrapper.failure(error.getLocalizedMessage());
        }
    }

    @PostMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public ResponseWrapper<String> saveTemplate(@RequestBody Template template) {
        try {
            String templateId = templateDbProcessor.saveTemplate(template);
            return ResponseWrapper.success(templateId);
        } catch (Exception error) {
            return ResponseWrapper.failure(error.getLocalizedMessage());
        }
    }

    @DeleteMapping(value = "/delete")
    public ResponseWrapper<List<WorkbookDeletionResult>> deleteWorkbooks(
            @RequestBody List<String> templateIdList
    ) {
        List<WorkbookDeletionResult> result = templateIdList.stream().map(id -> {
            if (templateDbProcessor.templateExists(id)) {
                try {
                    templateDbProcessor.deleteTemplate(id);
                } catch (Exception err) {
                    return WorkbookDeletionResult.failure(id, err.getLocalizedMessage());
                }
                return WorkbookDeletionResult.success(id);
            } else {
                return WorkbookDeletionResult.failure(id, "No such template.");
            }
        }).collect(Collectors.toList());

        return ResponseWrapper.success(result);
    }

    @GetMapping(value = "list")
    public ResponseWrapper<List<TemplateInfo>> listTemplates() {
        return ResponseWrapper.success(templateDbProcessor.getAllTemplateInfo());
    }
}
