package org.geely.pms_server.backend.core.model.luckysheet_operation.sheet;

import com.alibaba.fastjson2.annotation.JSONField;
import lombok.Data;

/**
 * 切换到指定sheet
 * t:shs
 */
@Data
public class LSOperationSwitchSheet {
    /**
     * 操作类型表示符号
     * <p>
     */
    @JSONField(name = "t")
    private String type;

    /**
     * 当前 sheet 的 index 值
     * <p>
     */
    @JSONField(name = "i")
    private String index;

    /**
     * 详细信息
     */
    @JSONField(name = "v")
    private String value;
}
