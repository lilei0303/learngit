package org.geely.pms_server.backend.core.model.formulaChain;

import java.util.HashMap;

public class FormulaNodeMap extends HashMap<FormulaNode, Integer> {
    @Override
    public Integer get(Object key) {
        if (key instanceof String tempName) {
            for (Entry<FormulaNode, Integer> entry : this.entrySet()) {
                FormulaNode node = entry.getKey();
                if (node.getCellNodeName().equals(tempName)) {
                    return entry.getValue();
                }
            }
            return null;
        }
        return super.get(key);
    }

    @Override
    public boolean containsKey(Object key) {
        if (key instanceof String tempName) {
            for (FormulaNode node : this.keySet()) {
                if (node.getCellNodeName().equals(tempName)) {
                    return true;
                }
            }
            return false;
        }
        return super.containsKey(key);
    }

    public Integer putValue(FormulaNode key, Integer value) {
        if (containsKey(key.getCellNodeName()) && get(key.getCellNodeName()) > 0) {
//            System.out.println("get(key.getCellNodeName()) = " + get(key.getCellNodeName()));
            return super.put(key, get(key.getCellNodeName()) + value);
        } else if (value > 0) {
            //如果formulaNodeMap中不包含当前结点，此时用户又传来一个删除操作（value = -1），则应不做操作
            return super.put(key, value);
        } else {
            return 0;
        }
    }
}
