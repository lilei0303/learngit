package org.geely.pms_server.backend.core.model.luckysheet_model.chart;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LSGrid implements Serializable {

    private String value;

    private Integer top;

    private Integer left;

    private Integer right;

    private Integer bottom;
}
