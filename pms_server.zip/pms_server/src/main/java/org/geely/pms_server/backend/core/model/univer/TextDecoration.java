package org.geely.pms_server.backend.core.model.univer;

import org.geely.pms_server.backend.core.model.univer.en.BooleanNumber;
import org.geely.pms_server.backend.core.model.univer.en.ETextDecoration;

public class TextDecoration {
    private BooleanNumber s; // show
    private BooleanNumber c; // color is follow the font color. the default value is TRUE, it's also TRUE if it is undefined. the cl has no effect when `c` is TRUE.
    private ColorStyle cl; // color
    private ETextDecoration t; // lineType
}
